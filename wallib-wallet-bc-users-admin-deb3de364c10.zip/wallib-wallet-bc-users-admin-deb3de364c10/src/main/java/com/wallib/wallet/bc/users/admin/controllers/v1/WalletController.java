package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.GET_WALLET_PASSPHRASE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.GET_WALLET_SEED_WORDS;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.WalletControllersDocs;
import com.wallib.wallet.bc.users.admin.domain.WalletPassphrase;
import com.wallib.wallet.bc.users.admin.domain.WalletSeedWords;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponsePassphraseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseSeedWordsDTO;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.services.WalletService;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/v1/wallet")
public class WalletController implements WalletControllersDocs {

    private final WalletService walletService;
    private final ObjectMapper objectMapper;

    public WalletController(WalletService walletService, ObjectMapper objectMapper) {
        this.walletService = walletService;
        this.objectMapper = objectMapper;
    }

    @Override
    @GetMapping(value = "/{walletNumber}/user/{userId}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + GET_WALLET_PASSPHRASE + "')")
    public ResponseEntity<ApiResponseDTO<ResponsePassphraseDTO>> getPassphrase(
        @PathVariable String walletNumber,
        @PathVariable Long userId
    ) throws IOException, RSAKeyPairException {

        log.trace("Request received on wallet controller with walletNumber: {}", walletNumber);

        WalletPassphrase walletPassphrase = walletService.getPassphrase(walletNumber, userId);

        ResponsePassphraseDTO responsePassphraseDTO =
            objectMapper.convertValue(walletPassphrase, ResponsePassphraseDTO.class);

        log.trace("Creating ApiResponse from walletController [get passphrase]");
        ResponseEntity<ApiResponseDTO<ResponsePassphraseDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponsePassphraseDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("Wallet passphrase retrieved successfully.")
                .body(responsePassphraseDTO)
                .build());
        log.trace("Api response created from get passphrase successfully {}", response);

        return response;
    }

    @Override
    @GetMapping(value = "/{walletNumber}/user/{userId}/seed", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + GET_WALLET_SEED_WORDS + "')")
    public ResponseEntity<ApiResponseDTO<ResponseSeedWordsDTO>> getSeedWords(
        @PathVariable String walletNumber,
        @PathVariable Long userId
    ) throws IOException, RSAKeyPairException {

        log.trace("Request received on wallet controller to get seed words with walletNumber: {}",
            walletNumber);

        WalletSeedWords walletSeedWords = walletService.getSeedWords(walletNumber, userId);

        ResponseSeedWordsDTO responseSeedWordsDTO =
            objectMapper.convertValue(walletSeedWords, ResponseSeedWordsDTO.class);
        responseSeedWordsDTO.setSeedWords(walletSeedWords.getSeedWords());

        log.trace("Mapped response to get seed words from:{} to: {}", walletSeedWords,
            responseSeedWordsDTO);

        log.trace("Creating ApiResponse from walletController [get seed words]");
        ResponseEntity<ApiResponseDTO<ResponseSeedWordsDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseSeedWordsDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("Wallet seed words retrieved successfully.")
                .body(responseSeedWordsDTO)
                .build());
        log.trace("Api response created from get seed words successfully {}", response);

        return response;
    }

}
