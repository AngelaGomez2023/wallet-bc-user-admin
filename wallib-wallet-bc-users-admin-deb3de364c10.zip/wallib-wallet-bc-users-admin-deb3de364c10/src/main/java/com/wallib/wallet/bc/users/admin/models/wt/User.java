package com.wallib.wallet.bc.users.admin.models.wt;

import java.io.Serial;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.serializers.wt.UserSerializer;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users", schema = "wallet")
@JsonSerialize(using = UserSerializer.class)
public class User extends AbstractFoundationEntity {

    @Serial
    private static final long serialVersionUID = 1L;

    @Column(name = "firebase_id", nullable = false)
    private Long firebaseId;

    @Column(name = "nickname")
    private String nickname;

    @Column(name = "firstname", nullable = false)
    private String firstname;

    @Column(name = "lastname")
    private String lastname;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "phone")
    private String phone;

    @Column(name = "document_id")
    private String documentId;

    @Column(name = "document_type")
    private Integer documentType;

    @Column(name = "document_date_expiration")
    private LocalDate documentDateExpiration;

    @Column(name = "address")
    private String address;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country_id", nullable = false)
    private Long countryId;

    @Column(name = "language_id")
    private Long languageId;

    @Column(name = "type", nullable = false)
    @Convert(converter = UserTypeEnum.Converter.class)
    private UserTypeEnum type;

    @Column(name = "status")
    private Integer status;

    public User(Long id) {
        super(id);
    }
}
