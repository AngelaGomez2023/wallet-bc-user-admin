package com.wallib.wallet.bc.users.admin.models.wt;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.serializers.wt.FcmRegistrationTokenSerializer;
import java.io.Serial;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "fcm_registration_tokens", schema = "wallet")
@JsonSerialize(using = FcmRegistrationTokenSerializer.class)
public class FcmRegistrationToken extends AbstractFoundationEntity {

    @Serial
    private static final long serialVersionUID = 945113085450891518L;

    @Column(name = "firebase_id", nullable = false)
    private Long firebaseId;

    @Column(name = "token", nullable = false)
    private String token;

    @Column(name = "platform", nullable = false)
    @Convert(converter = PlatformEnum.Converter.class)
    private PlatformEnum platform;

    @Column(name = "status", nullable = false)
    private Integer status;

    public FcmRegistrationToken(Long id) {
       super(id);
    }

}
