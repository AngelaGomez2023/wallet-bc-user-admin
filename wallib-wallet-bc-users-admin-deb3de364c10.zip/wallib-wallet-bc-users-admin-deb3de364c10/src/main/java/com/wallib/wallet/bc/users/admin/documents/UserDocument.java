package com.wallib.wallet.bc.users.admin.documents;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.DynamicMapping;
import org.springframework.data.elasticsearch.annotations.DynamicMappingValue;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(indexName = "wallet_user")
public class UserDocument implements Serializable {

    @Serial
    private static final long serialVersionUID = 1648976513453048256L;

    @Id
    private Long id;

    @Field(type = FieldType.Long)
    private Long firebaseId;

    @Field(type = FieldType.Text)
    private String nickname;

    @Field(type = FieldType.Text)
    private String firstname;

    @Field(type = FieldType.Text)
    private String lastname;

    @Field(type = FieldType.Text)
    private String email;

    @Field(type = FieldType.Text)
    private String phone;

    @Field(type = FieldType.Text)
    private String documentId;

    @Field(type = FieldType.Integer)
    private Integer documentType;

    @Field(type = FieldType.Date, format = DateFormat.date)
    private LocalDate documentDateExpiration;

    @Field(type = FieldType.Text)
    private String address;

    @Field(type = FieldType.Text)
    private String city;

    @Field(type = FieldType.Text)
    private String state;

    @Field(type = FieldType.Text)
    private String type;

    @Field(type = FieldType.Object)
    @DynamicMapping(DynamicMappingValue.Strict)
    private SimpleField country;

    @Field(type = FieldType.Long)
    private Long languageId;

    @Field(type = FieldType.Integer)
    private Integer status;

    public UserDocument(Long id) {
        this.id = id;
    }

}