package com.wallib.wallet.bc.users.admin.serializers.wt;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import java.io.IOException;
import java.io.Serial;

public class FcmRegistrationTokenSerializer extends StdSerializer<FcmRegistrationToken> {

    @Serial
    private static final long serialVersionUID = -493371173061683787L;

    protected FcmRegistrationTokenSerializer(Class<FcmRegistrationToken> t) {
        super(t);
    }

    protected FcmRegistrationTokenSerializer() {
        this(null);
    }

    @Override
    public void serialize(FcmRegistrationToken fcmRegistrationToken, JsonGenerator jsonGenerator,
        SerializerProvider serializerProvider) throws IOException {

        jsonGenerator.writeStartObject();

        jsonGenerator.writeNumberField("id", fcmRegistrationToken.getId());
        jsonGenerator.writeNumberField("firebase_id", fcmRegistrationToken.getFirebaseId());
        jsonGenerator.writeStringField("token", fcmRegistrationToken.getToken());
        jsonGenerator.writeStringField("platform", fcmRegistrationToken.getPlatform().getValue());
        jsonGenerator.writeNumberField("status", fcmRegistrationToken.getStatus());

        if (fcmRegistrationToken.getCreatedAt() != null) {
            jsonGenerator.writeStringField("created_at",
                fcmRegistrationToken.getCreatedAt().toString());
        }
        if (fcmRegistrationToken.getUpdatedAt() != null) {
            jsonGenerator.writeStringField("updated_at",
                fcmRegistrationToken.getUpdatedAt().toString());
        }
        if (fcmRegistrationToken.getDeletedAt() != null) {
            jsonGenerator.writeStringField("deleted_at", fcmRegistrationToken.getDeletedAt().toString());
        } else {
            jsonGenerator.writeNullField("deleted_at");
        }

        jsonGenerator.writeEndObject();

    }
}
