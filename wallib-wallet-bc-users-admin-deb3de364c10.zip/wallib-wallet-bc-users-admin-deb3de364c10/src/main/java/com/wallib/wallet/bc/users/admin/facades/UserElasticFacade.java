package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;

public interface UserElasticFacade {

    void indexByUser(Long userId)
        throws JsonProcessingException, UserServiceException;

}
