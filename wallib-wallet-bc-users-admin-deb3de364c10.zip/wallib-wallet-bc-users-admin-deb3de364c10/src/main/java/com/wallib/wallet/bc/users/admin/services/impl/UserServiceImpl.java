package com.wallib.wallet.bc.users.admin.services.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.ACTIVE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.INACTIVE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.PENDING;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import com.wallib.wallet.bc.users.admin.services.AuditLogService;
import com.wallib.wallet.bc.users.admin.services.UserService;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final CountryRepository countryRepository;
    private final AuditLogService auditLogService;

    public UserServiceImpl(UserRepository userRepository, AuditLogService auditLogService,
        CountryRepository countryRepository) {
        this.userRepository = userRepository;
        this.countryRepository = countryRepository;
        this.auditLogService = auditLogService;
    }

    @BasicLog
    @Override
    public Page<User> list(Long countryId, String filter, Pageable pageable) {
        log.trace("Starting process on list users.");
        return userRepository.findByIdInCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull(
            countryId, filter, pageable);
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public User findById(Long id) {
        log.trace("Starting process to get user object {}", id);

        log.trace("Checking if user with id {} exists", id);
        User user = getUserById(id);
        log.trace("User with id {} found. {}", user.getId(), id);

        return user;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public User findByFirebaseId(String firebaseId) {
        log.trace("Starting process to get user object from firebase ID {}", firebaseId);

        log.trace("Checking if user with id {} exists", firebaseId);
        User user = getUserByFirebaseId(firebaseId);
        log.trace("User with firebase id {} found. {}", user.getId(), firebaseId);

        return user;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public User findByNickname(String nickname) {
        log.trace("Starting process to find user by nickname: {}", nickname);

        log.trace("Checking if user with nickname {} exists", nickname);
        User user = getUserByNickname(nickname);
        log.trace("User with nickname {} found. {}", nickname, user.getId());

        return user;
    }

    @BasicLog
    @Override
    public User create(User user) throws JsonProcessingException, UserServiceException {
        log.trace("Starting process on create user service with object {}", user);

        log.trace("Validate country with id {} ", user.getCountryId());
        validateCountryExists(user.getCountryId());
        log.trace("Country with id {} exists", user.getCountryId());

        log.trace("Validate user with documentId {}", user.getDocumentId());
        validateUserDocumentIdExists(user.getDocumentId(), user.getDocumentType());

        log.trace("Validate user with firebaseId {} ", user.getFirebaseId());
        validateFirebaseIdExists(user.getFirebaseId());

        int currentStatus = checkStatus(user.getStatus());
        log.trace("Check status {} ", currentStatus);
        user.setStatus(currentStatus);

        log.trace("Saving user. {}", user);
        User createdUser = userRepository.save(user);
        log.trace("User saved successfully. {}", createdUser);

        auditLogService.createAuditLog(createdUser);

        return createdUser;
    }

    @BasicLog
    @Override
    public User update(Long id, User userChanges)
        throws JsonProcessingException, UserServiceException {
        log.trace("Starting process on update user service with object {}", userChanges);

        log.trace("Validate if user id exists {} ", id);
        User userToUpdate = getUserById(id);
        log.trace("User id exists. {}", userToUpdate);

        log.trace("Validate country with id {} ", userChanges.getCountryId());
        validateCountryExists(userChanges.getCountryId());
        log.trace("Country with id {} exists", userChanges.getCountryId());

        log.trace("Validate user with documentId {} ", userChanges.getDocumentId());
        validateUserDocumentIdExistsAndIsNotSame(id, userChanges);

        log.trace("Validate user with firebaseId {} ", userChanges.getFirebaseId());
        validateFirebaseIdExistsAndIsNotSame(userChanges.getFirebaseId(), id);

        User beforeUpdate = userToUpdate.toBuilder().build();

        updateUserFields(userToUpdate, userChanges);

        log.trace("Updating user. {}", userToUpdate);
        User updatedUser = userRepository.saveAndFlush(userToUpdate);
        log.trace("User updated successfully. {}", updatedUser);

        auditLogService.updateAuditLog(beforeUpdate, updatedUser);

        return updatedUser;
    }

    @BasicLog
    @Override
    public void delete(Long id) throws JsonProcessingException {
        log.trace("Validating if User {} exists", id);
        User user = getUserById(id);
        log.trace("User with id {} found. {}", id, user);

        log.trace("Deleting User {}", id);
        userRepository.delete(user);
        log.trace("User {} deleted successfully", id);

        auditLogService.deleteAuditLog(user);
    }

    @BasicLog
    @Override
    public Integer countByCountryIdAndDeletedAtIsNull(Long countryId, String filter) {
        return userRepository
            .countByIdInAndCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull(
                countryId, filter);
    }

    private User getUserById(@NotNull Long id) {
        return userRepository.findById(id).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("User with id: %1$s not found", id)));
    }

    private User getUserByFirebaseId(@NotNull String firebaseId) {
        return userRepository.findByFirebaseIdAndDeletedAtIsNull(firebaseId).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("User with firebase id: %1$s not found", firebaseId)));
    }

    private User getUserByNickname(@NotNull String nickname) {
        return userRepository.findByNicknameAndStatusAndDeletedAtIsNull(nickname, 1).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("User with nickname: %1$s not found", nickname)));
    }

    private void validateCountryExists(@NotNull Long id) throws UserServiceException {
        boolean countryExists = countryRepository.existsById(id);
        if (!countryExists) {
            throw new UserServiceException(
                String.format("Country with id '%1$s' doesn't exist.", id));
        }
    }

    private void validateFirebaseIdExists(@NotNull Long firebaseId)
        throws UserServiceException {
        boolean firebaseIdExists = userRepository.existsByFirebaseIdAndDeletedAtIsNull(firebaseId);
        if (firebaseIdExists)
            throw new UserServiceException(
                String.format("User with firebaseId '%1$s' already exists.", firebaseId));
    }

    private void validateFirebaseIdExistsAndIsNotSame(@NotNull Long firebaseId, long id)
        throws UserServiceException {
        boolean firebaseIdExists = userRepository.existsByFirebaseIdAndIdAndDeletedAtIsNull(
            firebaseId, id);
        if (!firebaseIdExists)
            throw new UserServiceException(
                String.format("User with firebaseId '%1$s' already exists.", firebaseId));
    }

    private void validateUserDocumentIdExists(@NotNull String documentId, @NotNull Integer documentType)
        throws UserServiceException {
        if (documentId != null || documentType != null) {
            boolean documentIdExists = userRepository.existsByDocumentIdAndDocumentTypeAndDeletedAtIsNull(
                documentId, documentType);
            if (documentIdExists)
                throw new UserServiceException(
                    String.format("User with id '%1$s' and idType '%2$d' already exists.", documentId,
                        documentType));
        }
    }

    private void validateUserDocumentIdExistsAndIsNotSame(@NotNull long id, @NotNull User userToUpdate) 
        throws UserServiceException {

        if (userToUpdate.getDocumentId() == null || userToUpdate.getDocumentType() == null)
            return;

        log.trace("ID " + userToUpdate.getId());

        boolean documentIdExists = userRepository.existsByDocumentIdAndDocumentTypeAndIdNotAndDeletedAtIsNull(
            userToUpdate.getDocumentId(), 
            userToUpdate.getDocumentType(), 
            id
        );
        if(documentIdExists)
            throw new UserServiceException(String.format(
                "User with id '%1$s' and idType '%2$d' already exists.", 
                userToUpdate.getDocumentId(),
                userToUpdate.getDocumentType()
            ));
    }

    private void updateUserFields(@NotNull User userToUpdate,
        @NotNull User userChanges) {

        userToUpdate.setFirebaseId(userChanges.getFirebaseId());
        userToUpdate.setNickname(userChanges.getNickname());
        userToUpdate.setFirstname(userChanges.getFirstname());
        userToUpdate.setLastname(userChanges.getLastname());
        userToUpdate.setEmail(userChanges.getEmail());
        userToUpdate.setPhone(userChanges.getPhone());
        userToUpdate.setDocumentId(userChanges.getDocumentId());
        userToUpdate.setDocumentType(userChanges.getDocumentType());
        userToUpdate.setDocumentDateExpiration(userChanges.getDocumentDateExpiration());
        userToUpdate.setAddress(userChanges.getAddress());
        userToUpdate.setCity(userChanges.getCity());
        userToUpdate.setState(userChanges.getState());
        userToUpdate.setCountryId(userChanges.getCountryId());
        userToUpdate.setType(userChanges.getType());
        userToUpdate.setStatus(userChanges.getStatus());
    }

    private int checkStatus(@NotNull int status) {
        switch (status) {
            case 1 -> {
                return ACTIVE;
            }
            case 2 -> {
                return PENDING;
            }
            default -> {
                return INACTIVE;
            }
        }
    }
}
