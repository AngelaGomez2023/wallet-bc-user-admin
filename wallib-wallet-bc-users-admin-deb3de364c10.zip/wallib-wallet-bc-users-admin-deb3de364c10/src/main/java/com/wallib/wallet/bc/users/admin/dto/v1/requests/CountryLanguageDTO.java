package com.wallib.wallet.bc.users.admin.dto.v1.requests;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CountryLanguageDTO implements Serializable{
    
    @Serial
    private static final long serialVersionUID = -279416911292590179L;

    @JsonProperty(value = "es")
    private String es;

    @JsonProperty(value = "en")
    private String en;

    @JsonProperty(value = "pt")
    private String pt;
}
