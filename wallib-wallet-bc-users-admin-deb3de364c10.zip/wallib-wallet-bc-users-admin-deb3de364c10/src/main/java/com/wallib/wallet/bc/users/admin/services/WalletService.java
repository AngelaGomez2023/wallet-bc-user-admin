package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.domain.WalletPassphrase;
import com.wallib.wallet.bc.users.admin.domain.WalletSeedWords;
import com.wallib.wallet.bc.users.admin.dto.v1.SaveWalletCustodialInfoDTO;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import java.io.IOException;

public interface WalletService {

    boolean processCustodialKeys(SaveWalletCustodialInfoDTO saveWalletCustodialInfoDTO)
        throws IOException, RSAKeyPairException;

    WalletPassphrase getPassphrase(String walletNumber, Long userId)
        throws IOException, RSAKeyPairException;

    WalletSeedWords getSeedWords(String walletNumber, Long userId)
        throws IOException, RSAKeyPairException;

}
