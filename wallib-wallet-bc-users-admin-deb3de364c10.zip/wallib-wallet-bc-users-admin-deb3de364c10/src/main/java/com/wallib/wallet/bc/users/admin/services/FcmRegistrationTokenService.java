package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;

public interface FcmRegistrationTokenService {

    FcmRegistrationToken findById(Long id);

    FcmRegistrationToken findByFirebaseId(Long id);

    FcmRegistrationToken save(FcmRegistrationToken fcmRegistrationToken)
        throws JsonProcessingException, FcmRegistrationTokenException;

}
