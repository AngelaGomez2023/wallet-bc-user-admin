package com.wallib.wallet.bc.users.admin.services.impl;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.wallib.wallet.bc.users.admin.services.AuditLogService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import com.wallib.wallet.bc.users.admin.security.User;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.models.wt.AuditLog;
import com.wallib.wallet.bc.users.admin.repositories.wt.AuditLogRepository;
import com.wallib.wallet.bc.users.admin.utils.AuditLogsUtils;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.components.AuthenticationComponent;

@Service
@Slf4j
public class AuditLogServiceImpl implements AuditLogService {

    private final AuthenticationComponent authenticationComponent;
    private final AuditLogRepository auditLogRepository;
    private final ObjectMapper objectMapper;

    public AuditLogServiceImpl(AuthenticationComponent authenticationComponent, AuditLogRepository auditLogRepository,
            ObjectMapper objectMapper) {
        this.authenticationComponent = authenticationComponent;
        this.auditLogRepository = auditLogRepository;
        this.objectMapper = objectMapper;
    }

    @BasicLog
    @Override
    public void createAuditLog(@NotNull AbstractFoundationEntity entity) throws JsonProcessingException {

        Long userId = getUserId();

        log.trace("Generating create audit log with object {}", objectMapper.writeValueAsString(entity));
        AuditLog auditLog = AuditLogsUtils.getCreateAuditLog(entity, userId);
        log.trace("Create audit log generated successfully. {}", objectMapper.writeValueAsString(auditLog));

        log.trace("Saving create audit log {}", objectMapper.writeValueAsString(auditLog));
        auditLogRepository.save(auditLog);
        log.trace("Action create audit log saved successfully");

    }

    @BasicLog
    @Override
    public void updateAuditLog(@NotNull AbstractFoundationEntity oldEntity, @NotNull AbstractFoundationEntity newEntity)
            throws JsonProcessingException {
        Long userId = getUserId();

        log.trace("The oldEntity is {}", oldEntity);
        log.trace("The newEntity is {}", newEntity);

        newEntity.setUpdatedAt(LocalDateTime.now());
        String oldEntityToString = objectMapper.writeValueAsString(oldEntity);
        String newEntityToString = objectMapper.writeValueAsString(newEntity);

        log.trace("Generating update audit log with object {}", objectMapper.writeValueAsString(newEntity));
        AuditLog auditLog = AuditLogsUtils.getUpdateAuditLog(newEntity.getId(), oldEntityToString, newEntityToString,
                newEntity, userId);
        log.trace("Update audit log generated successfully. {}", objectMapper.writeValueAsString(auditLog));

        log.trace("Saving update audit log {}", objectMapper.writeValueAsString(auditLog));
        auditLogRepository.save(auditLog);
        log.trace("Action update audit log saved successfully");
    }

    @BasicLog
    @Override
    public void deleteAuditLog(@NotNull AbstractFoundationEntity entity) throws JsonProcessingException {
        Long userId = getUserId();
        LocalDateTime now = LocalDateTime.now();
        entity.setUpdatedAt(now);
        entity.setDeletedAt(now);

        log.trace("Generating delete audit log with object {}", v("data", objectMapper.writeValueAsString(entity)));
        AuditLog auditLog = AuditLogsUtils.getDeleteAuditLog(entity, userId);
        log.trace("Delete audit log generated successfully. {}", v("data", objectMapper.writeValueAsString(auditLog)));

        log.trace("Saving delete audit log {}", objectMapper.writeValueAsString(auditLog));
        auditLogRepository.save(auditLog);
        log.trace("Action delete audit log saved successfully");
    }

    private Long getUserId() {
        Authentication authentication = authenticationComponent.getAuthentication();
        log.trace("Acquiring the user id");
        Long userId = Long.valueOf(((User) authentication.getPrincipal()).getId());
        log.trace("User id acquired successfully: {}", userId);

        return userId;
    }
}
