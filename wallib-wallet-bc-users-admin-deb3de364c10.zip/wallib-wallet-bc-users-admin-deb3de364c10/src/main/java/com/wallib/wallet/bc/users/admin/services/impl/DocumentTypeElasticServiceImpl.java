package com.wallib.wallet.bc.users.admin.services.impl;

import java.util.Optional;
import javax.validation.constraints.NotNull;
import com.wallib.wallet.bc.users.admin.documents.DocumentTypeDocument;
import com.wallib.wallet.bc.users.admin.documents.SimpleField;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.repositories.es.DocumentTypeDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeElasticService;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DocumentTypeElasticServiceImpl implements DocumentTypeElasticService {
    
    private final DocumentTypeDocumentRepository documentTypeDocumentRepository;
    private final CountryRepository countryRepository;
    
    public DocumentTypeElasticServiceImpl(DocumentTypeDocumentRepository documentTypeDocumentRepository,
        CountryRepository countryRepository){
        this.documentTypeDocumentRepository = documentTypeDocumentRepository;
        this.countryRepository = countryRepository;
    }

    @Override
    public void index(DocumentType documentType) throws DocumentTypeServiceException {
        log.trace("Creating DocumentTypeDocument to index in ES with documentType {}.", documentType);
        DocumentTypeDocument documentTypeDocument = documentTypeDocumentCreate(documentType);
        log.trace("DocumentTypeDocument created and ready to be indexed in ES {}.", documentTypeDocument);

        log.info("Indexing CountryDocument in ES {}.", documentTypeDocument);
        documentTypeDocumentRepository.save(documentTypeDocument);
        log.info("DocumentTypeDocument indexed successfully in ES {}.", documentTypeDocument);
    }

    private DocumentTypeDocument documentTypeDocumentCreate(DocumentType documentType) throws DocumentTypeServiceException {

        @NotNull Optional<Country> country = countryRepository.findById(documentType.getCountryId());

        SimpleField simpleFieldCountry;

        if (country.orElse(null) != null) {
            simpleFieldCountry = SimpleField.builder()
                .id(country.orElse(null).getId())
                .name(country.orElse(null).getName())
                .build();
        } else {
            throw new DocumentTypeServiceException("Country does not exist");
        }

        return DocumentTypeDocument.builder()
            .id(documentType.getId())
            .type(documentType.getType())
            .country(simpleFieldCountry)
            .status(documentType.getStatus())
            .build();
    }
}
