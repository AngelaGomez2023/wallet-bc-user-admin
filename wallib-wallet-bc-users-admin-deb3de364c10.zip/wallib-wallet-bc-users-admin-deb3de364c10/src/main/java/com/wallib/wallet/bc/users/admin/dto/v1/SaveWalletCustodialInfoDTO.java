package com.wallib.wallet.bc.users.admin.dto.v1;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SaveWalletCustodialInfoDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = -2677265382598875454L;

    @JsonProperty(value = "user_id")
    private Long userId;

    @JsonProperty(value = "wallet_number")
    private String walletNumber;

    @JsonProperty(value = "passphrase")
    private String passphrase;

    @JsonProperty(value = "phrase")
    private String phrase;

}
