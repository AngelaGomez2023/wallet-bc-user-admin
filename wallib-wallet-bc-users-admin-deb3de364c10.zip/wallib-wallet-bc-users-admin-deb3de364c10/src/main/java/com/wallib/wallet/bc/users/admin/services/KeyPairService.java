package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.domain.PublicKey;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.KeyPairServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;

public interface KeyPairService {
    
    PublicKey create(Long userId) throws RSAKeyPairException, KeyPairServiceException;
}
