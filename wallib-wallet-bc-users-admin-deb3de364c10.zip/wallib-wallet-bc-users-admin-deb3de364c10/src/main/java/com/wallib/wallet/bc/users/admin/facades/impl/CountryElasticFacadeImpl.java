package com.wallib.wallet.bc.users.admin.facades.impl;

import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.facades.CountryElasticFacade;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.services.CountryElasticService;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CountryElasticFacadeImpl implements CountryElasticFacade {
    
    private final CountryService countryService;
    private final CountryElasticService countryElasticService;

    public CountryElasticFacadeImpl(@NotNull final CountryService countryService,
        @NotNull final CountryElasticService countryElasticService) {
        this.countryService = countryService;
        this.countryElasticService = countryElasticService;
    }

    @BasicLog
    @Override
    public void indexByCountry(Long countryId) throws JsonProcessingException,
        CountryServiceException {
        log.trace("Country ID received to index: {}.", countryId);
        Country country = countryService.findById(countryId);
        log.trace("Country found to index: {}.", country);
        countryElasticService.index(country);
    }
}
