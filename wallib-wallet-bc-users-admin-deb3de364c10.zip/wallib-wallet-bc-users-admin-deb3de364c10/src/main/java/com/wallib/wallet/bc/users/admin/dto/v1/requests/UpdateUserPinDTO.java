package com.wallib.wallet.bc.users.admin.dto.v1.requests;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateUserPinDTO {
    
    @Serial
    private static final long serialVersionUID = 1L;

    @NotNull
    @Schema(example = "1234")
    @JsonProperty(value = "pin")
    private String pin;

    @NotNull
    @Schema(example = "1234")
    @JsonProperty(value = "current_pin")
    private String currentPin;

    @NotNull
    @Schema(example = "123456789")
    @JsonProperty(value = "user_id")
    private Long userId;
}
