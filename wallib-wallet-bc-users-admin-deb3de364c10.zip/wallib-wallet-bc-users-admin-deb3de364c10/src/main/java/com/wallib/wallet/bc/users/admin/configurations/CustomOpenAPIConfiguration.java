package com.wallib.wallet.bc.users.admin.configurations;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.BEARER_AUTH;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomOpenAPIConfiguration {

    @Value("${swagger.server.url}")
    private String serverUrl;

    @Value("${project.name}")
    private String projectName;

    @Value("${project.version}")
    private String projectVersion;

    @Bean
    public OpenAPI customOpenAPI() {

        var server = new Server();
        server.setDescription("Server URL");
        server.setUrl(serverUrl);

        return new OpenAPI()
            .addSecurityItem(new SecurityRequirement().addList(BEARER_AUTH))
            .components(new Components().addSecuritySchemes(BEARER_AUTH,
                new SecurityScheme().name(BEARER_AUTH)
                    .type(SecurityScheme.Type.HTTP)
                    .scheme("bearer")
                    .bearerFormat("JWT")))
            .servers(Collections.singletonList(server))
            .info(new Info()
                .title(projectName)
                .version(projectVersion)
                .termsOfService("https://www.wallib.com/terms")
                .license(new License().name("Apache 2.0").url("https://www.wallib.com/license")));
    }

}
