package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.User;

public interface UserFacade {

    User create(User user) throws UserServiceException, JsonProcessingException;

    User update(Long id, User user) throws UserServiceException, JsonProcessingException;

    void delete(Long id) throws UserServiceException, JsonProcessingException;
}
