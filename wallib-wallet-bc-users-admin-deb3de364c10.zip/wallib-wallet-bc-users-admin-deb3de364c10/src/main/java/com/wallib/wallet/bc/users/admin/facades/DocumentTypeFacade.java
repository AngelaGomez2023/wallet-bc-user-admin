package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;

public interface DocumentTypeFacade {
    
    DocumentType create(DocumentType documentType) throws DocumentTypeServiceException, JsonProcessingException;

    DocumentType update(Long id, DocumentType documentType) throws DocumentTypeServiceException, JsonProcessingException;

    void delete(Long id) throws DocumentTypeServiceException, JsonProcessingException;
}
