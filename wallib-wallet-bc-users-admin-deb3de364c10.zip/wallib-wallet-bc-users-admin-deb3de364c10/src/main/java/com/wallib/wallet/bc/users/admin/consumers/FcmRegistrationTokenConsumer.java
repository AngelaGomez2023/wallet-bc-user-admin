package com.wallib.wallet.bc.users.admin.consumers;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FCM_REGISTRATION_TOKEN_ENTITY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenElasticFacade;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class FcmRegistrationTokenConsumer {

    private final FcmRegistrationTokenElasticFacade fcmRegistrationTokenElasticFacade;

    @Value("${activemq.wallet.bc.users.admin.queue}")
    private String sourceQueue;

    public FcmRegistrationTokenConsumer(
        @NotNull final FcmRegistrationTokenElasticFacade fcmRegistrationTokenElasticFacade) {
        this.fcmRegistrationTokenElasticFacade = fcmRegistrationTokenElasticFacade;
    }

    @BasicLog
    @JmsListener(destination = "${activemq.wallet.bc.users.admin.queue}",
        selector = "(action = '" + EVENT_INSERT
            + "' OR action = '" + EVENT_UPDATE
            + "' OR action = '" + EVENT_DELETE
            + "') AND entity = '" + FCM_REGISTRATION_TOKEN_ENTITY + "'")
    public void receiveFcmRegistrationTokenMessage(@Payload @NotNull IndexEventDTO indexEvent)
        throws JsonProcessingException, FcmRegistrationTokenException {
        try {
            log.info(
                "FcmRegistrationToken: message received from the ActiveMQ queue {} to create/update index. {}",
                sourceQueue, indexEvent);
            fcmRegistrationTokenElasticFacade.indexByFcmRegistrationToken(indexEvent.getEntityId());
        } catch (EntityNotFoundException ex) {
            log.error(ex.getMessage());
            throw ex;
        } catch (RuntimeException | JsonProcessingException | FcmRegistrationTokenException ex) {
            log.error("Document not indexed by FcmRegistrationToken, object has errors: "
                + ex.getMessage(), ex);
            throw ex;
        }
    }

}
