package com.wallib.wallet.bc.users.admin.facades.impl;

import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.facades.DocumentTypeElasticFacade;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeElasticService;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DocumentTypeElasticFacadeImpl implements DocumentTypeElasticFacade {
    
    private final DocumentTypeService documentTypeService;
    private final DocumentTypeElasticService documentTypeElasticService;

    public DocumentTypeElasticFacadeImpl(@NotNull final DocumentTypeService documentTypeService,
        @NotNull final DocumentTypeElasticService documentTypeElasticService){
        this.documentTypeElasticService = documentTypeElasticService;
        this.documentTypeService = documentTypeService;
    }

    @BasicLog
    @Override
    public void indexByDocumentType(Long documentTypeId) throws JsonProcessingException, DocumentTypeServiceException {
        log.trace("DocumentType ID received to index: {}.", documentTypeId);
        DocumentType documentType = documentTypeService.findById(documentTypeId);
        log.trace("DocumentType found to index: {}.", documentType);
        documentTypeElasticService.index(documentType);
    }
}
