package com.wallib.wallet.bc.users.admin.documents;

import java.io.Serial;
import java.io.Serializable;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(indexName = "wallet_fcm_registration_token")
public class FcmRegistrationTokenDocument implements Serializable{

    @Serial
    private static final long serialVersionUID = 510757527119859284L;

    @Id
    private Long id;

    @Field(type = FieldType.Long)
    private Long firebaseId;

    @Field(type = FieldType.Text)
    private String token;

    @Field(type = FieldType.Text)
    private String platform;

    @Field(type = FieldType.Integer)
    private int status;

    public FcmRegistrationTokenDocument(Long id){
        this.id = id;
    }
}
