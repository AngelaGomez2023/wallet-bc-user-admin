package com.wallib.wallet.bc.users.admin.dto.v1.requests;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateUserDTO implements Serializable{
    
    @Serial
    private static final long serialVersionUID = 1L;

    @NotNull
    @Schema(example = "1")
    @JsonProperty(value = "firebase_id")
    private Long firebaseId;

    @NotBlank
    @NotNull
    @Schema(example = "nickname")
    @JsonProperty(value = "nickname")
    private String nickname;

    @NotBlank
    @NotNull
    @Schema(example = "firstname")
    @JsonProperty(value = "firstname")
    private String firstname;

    @NotBlank
    @NotNull
    @Schema(example = "lastname")
    @JsonProperty(value = "lastname")
    private String lastname;

    @NotBlank
    @NotNull
    @Schema(example = "email@example.com")
    @JsonProperty(value = "email")
    private String email;

    @NotBlank
    @NotNull
    @Schema(example = "123456789")
    @JsonProperty(value = "phone")
    private String phone;

    @Schema(example = "1")
    @JsonProperty(value = "document_id")
    private String documentId;

    @Schema(example = "1")
    @JsonProperty(value = "document_type")
    private Integer documentType;

    @Schema(example = "2017-01-13T17:09:42.411")
    @JsonProperty(value = "document_date_expiration")
    private LocalDate documentDateExpiration;

    @Schema(example = "Baker St.")
    @JsonProperty(value = "address")
    private String address;

    @Schema(example = "BOG")
    @JsonProperty(value = "city")
    private String city;

    @Schema(example = "CUN")
    @JsonProperty(value = "state")
    private String state;

    @Schema(example = "1")
    @NotNull
    @JsonProperty(value = "country_id")
    private Long countryId;

    @Schema(example = "1")
    @JsonProperty(value = "language_id")
    private Long languageId;

    @JsonProperty(value = "type")
    private UserTypeEnum type;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
