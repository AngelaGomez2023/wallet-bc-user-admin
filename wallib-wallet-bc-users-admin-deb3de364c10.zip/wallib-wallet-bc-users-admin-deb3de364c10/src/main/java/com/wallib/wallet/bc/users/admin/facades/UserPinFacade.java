package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;

public interface UserPinFacade {
    
    UserPin findByUserId(Long userId) throws JsonProcessingException, UserPinServiceException;

    UserPin create(UserPin user) throws UserPinServiceException, JsonProcessingException;

    UserPin update(Long id, String currentPin, UserPin user) throws UserPinServiceException, JsonProcessingException;

    void delete(Long id) throws UserPinServiceException, JsonProcessingException;
}
