package com.wallib.wallet.bc.users.admin.utils;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.ALGORITHM;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.MGF1;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.SHA_256;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.PSource.PSpecified;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class KeyPairUtils {
    
    public static KeyPair generateRSAKeyPair(String keyPairAlgorithm) throws RSAKeyPairException {

        try{
            KeyPairGenerator generator = KeyPairGenerator.getInstance(keyPairAlgorithm);
            generator.initialize(2048);
            return generator.generateKeyPair();
        }
        catch(NoSuchAlgorithmException e){
            throw new RSAKeyPairException(String.format("Algorithm specified does not exist: '%1$s'.", keyPairAlgorithm));
        }
    }

    public static InputStream generatePublicKeyInputStream(final long userId, final PublicKey publicKey) throws RSAKeyPairException {

        try{
            StringWriter stringWriter = new StringWriter();
            PemWriter pemWriter = new PemWriter(stringWriter);
            pemWriter.writeObject(new PemObject("PUBLIC KEY", publicKey.getEncoded()));
            pemWriter.flush();

            return new ByteArrayInputStream(stringWriter.toString().getBytes());
        }
        catch(IOException e){
            throw new RSAKeyPairException(String.format("Could not generate InputStream for public key of user with id: %1$d.", userId));
        }
    }

    public static InputStream generatePrivateKeyInputStream(final long userId, final PrivateKey key) throws RSAKeyPairException {

        try{
            StringWriter stringWriter = new StringWriter();
            PemWriter pemWriter = new PemWriter(stringWriter);
            pemWriter.writeObject(new PemObject("PRIVATE KEY", key.getEncoded()));
            pemWriter.flush();

            return new ByteArrayInputStream(stringWriter.toString().getBytes());
        }
        catch(IOException e){
            throw new RSAKeyPairException(String.format("Could not generate InputStream for public key of user with id: %1$d.", userId));
        }
    }

    public static String generatePublicKeyString(final long userId, final PublicKey publicKey) throws RSAKeyPairException {

        try{
            StringWriter stringWriter = new StringWriter();
            PemWriter pemWriter = new PemWriter(stringWriter);
            pemWriter.writeObject(new PemObject("PUBLIC KEY", publicKey.getEncoded()));
            pemWriter.flush();
            
            return stringWriter.toString();
        }
        catch(IOException e){
            throw new RSAKeyPairException(String.format("Could not generate String for public key of user with id: %1$d.", userId));
        }
    }

    private static PublicKey getPublicKey(String publicKey)
        throws NoSuchAlgorithmException, InvalidKeySpecException {

        KeyFactory kf = KeyFactory.getInstance("RSA");

        String publicKeyContent = publicKey
            .replace("\n", "")
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "");

        log.trace("Get public key: {}", publicKeyContent);

        X509EncodedKeySpec keySpecX509 = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyContent));
        RSAPublicKey pubKey = (RSAPublicKey) kf.generatePublic(keySpecX509);
        log.trace("Get public key: {}", pubKey);

        return pubKey;
    }

    private static PrivateKey getPrivateKey(String privateKey)
        throws NoSuchAlgorithmException, InvalidKeySpecException {

        KeyFactory kf = KeyFactory.getInstance("RSA");

        String privateKeyContent = privateKey
            .replace("\n", "")
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "");

        log.trace("Get private key: {}", privateKeyContent);

        PKCS8EncodedKeySpec keySpecPKCS8 = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyContent));
        PrivateKey privKey = kf.generatePrivate(keySpecPKCS8);
        log.trace("Get private key: {}", privKey);

        return privKey;
    }

    public static String encryptString(String publicKeyString, String stringToEncrypt)
        throws RSAKeyPairException {

        PublicKey publicKey;
        try {
            publicKey = getPublicKey(publicKeyString);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException ex) {
            throw new RSAKeyPairException("Public Key exception when encrypt string", ex);
        }

        Cipher encryptCipher;
        try {
            encryptCipher = Cipher.getInstance(ALGORITHM);
            encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey, new OAEPParameterSpec(SHA_256, MGF1,
                new MGF1ParameterSpec(SHA_256), PSource.PSpecified.DEFAULT));
        } catch (InvalidAlgorithmParameterException | NoSuchAlgorithmException |
                 NoSuchPaddingException ex) {
            throw new RSAKeyPairException("Encrypt cypher exception when encrypt string", ex);
        } catch (InvalidKeyException ex) {
            throw new RSAKeyPairException("Init encrypt cypher exception when encrypt string", ex);
        }

        byte[] secretMessageBytes = stringToEncrypt.getBytes(StandardCharsets.UTF_8);

        byte[] encryptedMessageBytes;
        try {
            encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);
        } catch (IllegalBlockSizeException | BadPaddingException ex) {
            throw new RSAKeyPairException("Init encrypt cypher exception when encrypt string", ex);
        }
        String encryptedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);

        log.trace("Encrypted message: {}.", encryptedMessage);

        return encryptedMessage;
    }

    public static String decryptString(String privateKeyString, String stringToDecrypt)
        throws RSAKeyPairException {

        PrivateKey privateKey;
        try {
            privateKey = getPrivateKey(privateKeyString);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException ex) {
            throw new RSAKeyPairException("Get private key exception when decrypt string", ex);
        }

        byte[] stringToDecryptByte = Base64.getDecoder().decode(stringToDecrypt);

        byte[] decryptedMessageBytes;
        try {
            Cipher decryptCipher = Cipher.getInstance(ALGORITHM);
            decryptCipher.init(Cipher.DECRYPT_MODE, privateKey, new OAEPParameterSpec(SHA_256, MGF1,
                new MGF1ParameterSpec(SHA_256), PSpecified.DEFAULT));
            decryptedMessageBytes = decryptCipher.doFinal(stringToDecryptByte);
        } catch (InvalidAlgorithmParameterException | IllegalBlockSizeException |
                 NoSuchAlgorithmException | BadPaddingException | InvalidKeyException |
                 NoSuchPaddingException ex) {
            throw new RSAKeyPairException("Decrypt cypher exception when decrypt string", ex);
        }

        String decryptedMessage = new String(decryptedMessageBytes, StandardCharsets.UTF_8);

        log.trace("Decrypted message: {}.", decryptedMessage);

        return decryptedMessage;
    }

    private KeyPairUtils() {}
}
