package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;

public interface DocumentTypeElasticService {
    
    void index(DocumentType documentType) throws DocumentTypeServiceException;
}
