package com.wallib.wallet.bc.users.admin.services.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FORMAT_STRING;
import static com.wallib.wallet.bc.users.admin.utils.KeyPairUtils.decryptString;
import static com.wallib.wallet.bc.users.admin.utils.KeyPairUtils.encryptString;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.domain.WalletPassphrase;
import com.wallib.wallet.bc.users.admin.domain.WalletSeedWords;
import com.wallib.wallet.bc.users.admin.dto.v1.SaveWalletCustodialInfoDTO;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.repositories.am.AmazonS3Repository;
import com.wallib.wallet.bc.users.admin.services.WalletService;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class WalletServiceImpl implements WalletService {

    private final AmazonS3Repository amazonS3Repository;

    public WalletServiceImpl(AmazonS3Repository amazonS3Repository) {
        this.amazonS3Repository = amazonS3Repository;
    }

    @Override
    @BasicLog
    public boolean processCustodialKeys(SaveWalletCustodialInfoDTO saveWalletCustodialInfoDTO)
        throws IOException, RSAKeyPairException {
        log.trace("Starting process to custodial keys with object {}", saveWalletCustodialInfoDTO);

        log.trace("Get RSA public keys to user.");
        String publicKey = amazonS3Repository.getPublicKeyFromS3Bucket(
            saveWalletCustodialInfoDTO.getUserId());
        log.trace("RSA public key obtained to user: {} {}.", saveWalletCustodialInfoDTO.getUserId(),
            publicKey);

        String encryptedSeedWords = encryptString(publicKey,
            saveWalletCustodialInfoDTO.getPhrase());
        String encryptedPassphrase = encryptString(publicKey,
            saveWalletCustodialInfoDTO.getPassphrase());

        String seedWordsFileName = String.format(FORMAT_STRING,
            saveWalletCustodialInfoDTO.getWalletNumber() + "_seed_words", "enc");
        log.trace("Seed words filename: {}.", seedWordsFileName);
        String passphraseFileName = String.format(FORMAT_STRING,
            saveWalletCustodialInfoDTO.getWalletNumber() + "_passphrase", "enc");
        log.trace("WalletPassphrase filename: {}.", passphraseFileName);

        InputStream inputSeedWords = getInputStream(encryptedSeedWords);
        InputStream inputPassphrase = getInputStream(encryptedPassphrase);

        String saveSeedWordsFileName = amazonS3Repository.uploadFileToS3Bucket(seedWordsFileName,
            inputSeedWords, encryptedSeedWords.length());
        log.trace("File to seed words saved into S3 Bucket: {}.", saveSeedWordsFileName);
        String saveSeedPassphraseFileName = amazonS3Repository.uploadFileToS3Bucket(
            passphraseFileName, inputPassphrase, encryptedPassphrase.length());
        log.trace("File to passphrase saved into S3 Bucket: {}.", saveSeedPassphraseFileName);

        return true;
    }

    @Override
    public WalletPassphrase getPassphrase(String walletNumber, Long userId)
        throws IOException, RSAKeyPairException {
        log.info("Starting process to get passphrase with walletNumber {}", walletNumber);

        String passphraseFileName = String.format(FORMAT_STRING,
            walletNumber + "_passphrase", "enc");
        log.trace("WalletPassphrase filename: {}.", passphraseFileName);

        log.trace("Get passphrase to wallet.");
        String passphrase = amazonS3Repository.getPassphraseFromS3Bucket(passphraseFileName);
        log.trace("WalletPassphrase retrieved to wallet: {} {}.", walletNumber, passphrase);

        log.trace("Get RSA private keys to user.");
        String privateKey = amazonS3Repository.getPrivateKeyFromS3Bucket(userId);
        log.trace("RSA private key obtained to user: {} {}.", userId, privateKey);

        String decryptedPassphrase = decryptString(privateKey, passphrase);
        log.trace("Wallet passphrase decrypted.");

        WalletPassphrase walletPassphrase = WalletPassphrase.builder()
            .wallet(walletNumber)
            .passphrase(decryptedPassphrase)
            .build();
        log.trace("WalletPassphrase obtained to wallet: {}.", walletPassphrase);

        return walletPassphrase;
    }

    @Override
    public WalletSeedWords getSeedWords(String walletNumber, Long userId)
        throws IOException, RSAKeyPairException {
        log.info("Starting process to get seed words with walletNumber {}", walletNumber);

        String seedWordsFileName = String.format(FORMAT_STRING,
            walletNumber + "_seed_words", "enc");
        log.trace("Seed words filename: {}.", seedWordsFileName);

        log.trace("Get seed words to wallet.");
        String seedWords = amazonS3Repository.getSeedWordsFromS3Bucket(seedWordsFileName);
        log.trace("Seed words retrieved to wallet: {} {}.", walletNumber, seedWords);

        log.trace("Get RSA private keys to user.");
        String privateKey = amazonS3Repository.getPrivateKeyFromS3Bucket(userId);
        log.trace("RSA private key obtained to user: {} {}.", userId, privateKey);

        String decryptedSeedWords = decryptString(privateKey, seedWords);
        log.trace("Wallet seedWords decrypted.");

        WalletSeedWords walletSeedWords = WalletSeedWords.builder()
            .wallet(walletNumber)
            .seedWords(decryptedSeedWords)
            .build();
        log.trace("Wallet seedWords obtained to wallet: {}.", walletSeedWords);

        return walletSeedWords;
    }

    private InputStream getInputStream(String str) {
        return new ByteArrayInputStream(str.getBytes(StandardCharsets.UTF_8));
    }

}
