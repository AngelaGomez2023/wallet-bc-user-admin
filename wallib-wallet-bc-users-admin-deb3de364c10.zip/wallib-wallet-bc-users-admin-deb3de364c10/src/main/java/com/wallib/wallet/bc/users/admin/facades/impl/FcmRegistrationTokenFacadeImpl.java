package com.wallib.wallet.bc.users.admin.facades.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FCM_REGISTRATION_TOKEN_ENTITY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenFacade;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.services.EventService;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenService;
import javax.validation.constraints.NotNull;
import org.springframework.stereotype.Component;

@Component
public class FcmRegistrationTokenFacadeImpl implements FcmRegistrationTokenFacade {

    private final FcmRegistrationTokenService fcmRegistrationTokenService;
    private final EventService eventService;

    public FcmRegistrationTokenFacadeImpl(FcmRegistrationTokenService fcmRegistrationTokenService,
        EventService eventService) {
        this.fcmRegistrationTokenService = fcmRegistrationTokenService;
        this.eventService = eventService;
    }

    @BasicLog
    @Override
    public FcmRegistrationToken save(@NotNull final FcmRegistrationToken createFcmRegistrationToken)
        throws JsonProcessingException, FcmRegistrationTokenException {
        FcmRegistrationToken fcmRegistrationToken = fcmRegistrationTokenService.save(
            createFcmRegistrationToken);
        eventService.sendEventToQueue(EVENT_INSERT, FCM_REGISTRATION_TOKEN_ENTITY,
            fcmRegistrationToken.getId());
        return fcmRegistrationToken;
    }

}
