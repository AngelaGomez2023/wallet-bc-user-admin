package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_DOCUMENT_TYPES;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_DOCUMENT_TYPE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_DOCUMENT_TYPE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_DOCUMENT_TYPE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_DOCUMENT_TYPE;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.DocumentTypeControllerDocs;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.facades.DocumentTypeFacade;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/v1/documentTypes")
public class DocumentTypeController implements DocumentTypeControllerDocs {
    
    private final DocumentTypeService documentTypeService;
    private final DocumentTypeFacade documentTypeFacade;
    private final ModelMapper modelMapper;

    public DocumentTypeController(
        DocumentTypeService documentTypeService, 
        DocumentTypeFacade documentTypeFacade, 
        ModelMapper modelMapper) {
        this.documentTypeService = documentTypeService;
        this.documentTypeFacade = documentTypeFacade;
        this.modelMapper = modelMapper;
    }

    @BasicLog
    @Override
    @GetMapping(value = "", produces = APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + LIST_DOCUMENT_TYPES + "')")
    public ResponseEntity<ApiResponseDTO<List<ResponseDocumentTypeDTO>>> list()
        throws JsonProcessingException {
        List<DocumentType> documentTypes = documentTypeService.list();

        log.trace("Generating DTO from documentTypes. {}", documentTypes);

        List<ResponseDocumentTypeDTO> documentTypeDTOList = new ArrayList<>();

        for (DocumentType documentType : documentTypes) {
            documentTypeDTOList.add(getMappedResponseDocumentType(documentType));
        }

        log.trace("List of DocumentTypeDTOs generated successfully. {}", documentTypeDTOList);

        return ResponseEntity.ok(ApiResponseDTO.<List<ResponseDocumentTypeDTO>>builder()
            .statusCode(HttpStatus.OK.value())
            .message("Countries retrieved successfully")
            .body(documentTypeDTOList)
            .build());
    }

    @BasicLog
    @GetMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_DOCUMENT_TYPE_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> findById(
        @PathVariable Long id
    )
        throws JsonProcessingException {

        log.trace("Request received on documentType controller with id {}", id);

        DocumentType documentType = documentTypeService.findById(id);

        log.trace("Generating documentType DTO from get documentType. {}", documentType);
        ResponseDocumentTypeDTO getMappedDocumentType = generateDocumentTypeDTOFromDocumentType(documentType);
        log.trace("ResponseDocumentTypeDTO generated successfully in findById method. {}", getMappedDocumentType);

        log.trace("Creating ApiResponse from documentTypeController [FINDBYID]");
        ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseDocumentTypeDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("DocumentType retrieved successfully")
                .body(getMappedDocumentType)
                .build());
        log.trace("Api response created from get documentType successfully {}", response);

        return response;
    }

    @BasicLog
    @PostMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + CREATE_DOCUMENT_TYPE + "')")
    public ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> create(
        @Valid @RequestBody CreateDocumentTypeDTO createDocumentTypeDTO)
        throws JsonProcessingException, DocumentTypeServiceException {

        log.trace("Request received on documentType controller with body {}", createDocumentTypeDTO);

        log.trace("Generating documentType object");
        DocumentType documentTypeObject = generateDocumentTypeFromCreateDocumentTypeDTO(createDocumentTypeDTO);
        log.trace("DocumentType generated successfully {}", documentTypeObject);

        DocumentType createdDocumentType = documentTypeFacade.create(documentTypeObject);

        log.trace("Generating documentType DTO from created hall. {}", createdDocumentType);
        ResponseDocumentTypeDTO mappedDocumentType = generateDocumentTypeDTOFromDocumentType(createdDocumentType);
        log.trace("ResponseDocumentTypeDTO generated successfully in create method. {}", mappedDocumentType);

        log.trace("Creating ApiResponse from documentTypeController [CREATE]");
        ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> response = ResponseEntity
            .status(HttpStatus.CREATED)
            .body(ApiResponseDTO.<ResponseDocumentTypeDTO>builder()
                .statusCode(HttpStatus.CREATED.value())
                .message("DocumentType created successfully")
                .body(mappedDocumentType)
                .build());
        log.trace("Api response created from create documentType successfully {}", response);

        return response;
    }

    @BasicLog
    @PutMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + UPDATE_DOCUMENT_TYPE + "')")
    public ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> update(
        @PathVariable Long id,
        @Valid @RequestBody UpdateDocumentTypeDTO updateDocumentTypeDTO
    )
        throws JsonProcessingException, DocumentTypeServiceException {

        log.trace("Request received on documentType controller with body {}", updateDocumentTypeDTO);

        log.trace("Generating documentType update object");
        DocumentType documentTypeObject = generateDocumentTypeFromUpdateDocumentTypeDTO(updateDocumentTypeDTO);
        log.trace("DocumentType update generated successfully {}", documentTypeObject);

        DocumentType updatedDocumentType = documentTypeFacade.update(id, documentTypeObject);

        log.trace("Generating documentType DTO from updated hall. {}", updatedDocumentType);
        ResponseDocumentTypeDTO mappedDocumentType = generateDocumentTypeDTOFromDocumentType(updatedDocumentType);
        log.trace("ResponseDocumentTypeDTO generated successfully in update method. {}", mappedDocumentType);

        log.trace("Creating ApiResponse from documentTypeController [UPDATE].");
        ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> response = ResponseEntity
            .status(HttpStatus.ACCEPTED)
            .body(ApiResponseDTO.<ResponseDocumentTypeDTO>builder()
                .statusCode(HttpStatus.ACCEPTED.value())
                .message("DocumentType updated successfully")
                .body(mappedDocumentType)
                .build());
        log.trace("Api response updated from update documentType successfully {}", response);

        return response;
    }

    @BasicLog
    @DeleteMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + DELETE_DOCUMENT_TYPE + "')")
    public ResponseEntity<ApiResponseDTO<String>> delete(@PathVariable Long id)
        throws DocumentTypeServiceException, JsonProcessingException {

        log.trace("Request received to delete documentType by id {}", id);
        documentTypeFacade.delete(id);
        log.trace("DocumentType with id {} successfully removed", id);

        log.trace("Creating ApiResponse from documentTypeController [DELETE]");

        return ResponseEntity.status(HttpStatus.NO_CONTENT)
            .body(ApiResponseDTO.<String>builder()
                .statusCode(HttpStatus.NO_CONTENT.value())
                .message("DocumentType deleted successfully")
                .build());

    }

    private DocumentType generateDocumentTypeFromCreateDocumentTypeDTO(
        @NotNull CreateDocumentTypeDTO createDocumentTypeDTO) {
        return DocumentType.builder()
            .type(createDocumentTypeDTO.getType())
            .countryId(createDocumentTypeDTO.getCountryId())
            .build();
    }

    private DocumentType generateDocumentTypeFromUpdateDocumentTypeDTO(
        @NotNull UpdateDocumentTypeDTO updateDocumentTypeDTO) {
        return DocumentType.builder()
            .type(updateDocumentTypeDTO.getType())
            .countryId(updateDocumentTypeDTO.getCountryId())
            .build();
    }

    private ResponseDocumentTypeDTO generateDocumentTypeDTOFromDocumentType(DocumentType documentType) {
        log.trace("generateDocumentTypeDTOFromDocumentType ResponseDocumentTypeDTO: {}", documentType.getType());
        ResponseDocumentTypeDTO mappedDocumentType = modelMapper.map(documentType, ResponseDocumentTypeDTO.class);
        mappedDocumentType.setType(documentType.getType());
        mappedDocumentType.setCountryId(documentType.getCountryId());

        log.trace("mappedDocumentType: {}", mappedDocumentType);
        return mappedDocumentType;
    }

    private ResponseDocumentTypeDTO getMappedResponseDocumentType(DocumentType documentType) {
        ResponseDocumentTypeDTO mappedDocumentType = modelMapper.map(documentType, ResponseDocumentTypeDTO.class);
        mappedDocumentType.setType(documentType.getType());
        mappedDocumentType.setCountryId(documentType.getCountryId());

        return mappedDocumentType;
    }
}
