package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import java.util.List;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.model.DocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseDocumentTypeDTO;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.WalletUserRestException;

@Tag(name = "DocumentTypes")
public interface DocumentTypeControllerDocs {
    
    @Operation(summary = "List documentTypes")
    @ApiResponse(
        responseCode = "200",
        description = "List documentTypes",
        content = {
            @Content(mediaType = APPLICATION_JSON_VALUE,
                array = @ArraySchema(
                    schema = @Schema(implementation = DocumentTypeDTO.class)
                )
            )
        }
    )
    ResponseEntity<ApiResponseDTO<List<ResponseDocumentTypeDTO>>> list()
        throws WalletUserRestException, JsonProcessingException;

    @Operation(summary = "Find DocumentType By Id")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Find DocumentType By Id",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = DocumentTypeDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> findById(
        @Parameter(
            name = "id",
            description = "DocumentType id to find by.",
            required = true
        ) Long id) throws JsonProcessingException;


    @Operation(summary = "Create documentType")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "DocumentType created successfully",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = DocumentTypeDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> create(
        @Parameter(
            name = "documentType",
            description = "DocumentType to create.",
            required = true
        ) CreateDocumentTypeDTO createDocumentTypeDTO
    ) throws JsonProcessingException, DocumentTypeServiceException;

    @Operation(summary = "Update a documentType",
        description = "Allows to update a documentType only if documentType id exists.")
    @ApiResponse(
        responseCode = "202",
        description = "DocumentType updated successfully.",
        content = {
            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = CreateDocumentTypeDTO.class))
        }
    )
    ResponseEntity<ApiResponseDTO<ResponseDocumentTypeDTO>> update(
        @Parameter(
            name = "id",
            description = "DocumentType Id to be updated.",
            required = true
        ) Long id,
        @Parameter(
            name = "DocumentType",
            description = "DocumentType to update.",
            required = true
        ) UpdateDocumentTypeDTO updateDocumentTypeDTO
    ) throws JsonProcessingException, DocumentTypeServiceException;

    @Operation(summary = "Delete a documentType",
        description = "Allows to delete a documentType only if documentType has no relations with other data.")
    @ApiResponse(
        responseCode = "200",
        description = "DocumentType deleted successfully.",
        content = {
            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ApiResponseDTO.class))
        }
    )
    ResponseEntity<ApiResponseDTO<String>> delete(
        @Parameter(
            name = "id",
            description = "DocumentType to delete.",
            required = true
        ) Long id
    ) throws JsonProcessingException, DocumentTypeServiceException;
}
