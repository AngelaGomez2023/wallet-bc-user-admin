package com.wallib.wallet.bc.users.admin.serializers.wt;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wallib.wallet.bc.users.admin.models.wt.FirebaseAccount;

import java.io.IOException;
import java.io.Serial;

public class FirebaseAccountSerializer extends StdSerializer<FirebaseAccount>  {

    @Serial
    private static final long serialVersionUID = -1151213138603906365L;

    protected FirebaseAccountSerializer(Class<FirebaseAccount> t) {
        super(t);
    }

    protected FirebaseAccountSerializer() {
        this(null);
    }

    @Override
    public void serialize(FirebaseAccount firebaseAccount, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {

        jsonGenerator.writeStartObject();

        jsonGenerator.writeNumberField("id", firebaseAccount.getId());
        jsonGenerator.writeStringField("firebase_id", firebaseAccount.getFirebaseId());
        jsonGenerator.writeStringField("email", firebaseAccount.getEmail());
        jsonGenerator.writeStringField("phone_number", firebaseAccount.getPhoneNumber());
        jsonGenerator.writeStringField("display_name", firebaseAccount.getDisplayName());
        jsonGenerator.writeBooleanField("email_verified", firebaseAccount.getEmailVerified());
        jsonGenerator.writeBooleanField("disabled", firebaseAccount.getDisabled());
        jsonGenerator.writeStringField("provider_user_info", firebaseAccount.getProviderUserInfo());
        jsonGenerator.writeStringField("mfa_info", firebaseAccount.getMfaInfo());
        jsonGenerator.writeNumberField("last_login_at", firebaseAccount.getLastLoginAt());
        jsonGenerator.writeNumberField("firebase_created_at", firebaseAccount.getFirebaseCreatedAt());

        jsonGenerator.writeStringField("created_at", firebaseAccount.getCreatedAt().toString());
        jsonGenerator.writeStringField("updated_at", firebaseAccount.getUpdatedAt().toString());

        if (firebaseAccount.getDeletedAt() != null) {
            jsonGenerator.writeStringField("deleted_at", firebaseAccount.getDeletedAt().toString());
        } else {
            jsonGenerator.writeNullField("deleted_at");
        }

        jsonGenerator.writeEndObject();

    }

}
