package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.documents.SimpleField;
import com.wallib.wallet.bc.users.admin.documents.UserDocument;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.es.UserDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.services.UserElasticService;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UserElasticServiceImpl implements UserElasticService {

    private final UserDocumentRepository userDocumentRepository;
    private final CountryRepository countryRepository;

    public UserElasticServiceImpl(UserDocumentRepository userDocumentRepository,
        CountryRepository countryRepository) {
        this.userDocumentRepository = userDocumentRepository;
        this.countryRepository = countryRepository;
    }

    @Override
    public void index(User user) throws UserServiceException {
        log.trace("Creating UserDocument to index in ES with user {}.", user);
        UserDocument userDocument = userDocumentCreate(user);
        log.trace("UserDocument created and ready to be indexed in ES {}.", userDocument);

        log.info("Indexing UserDocument in ES {}.", userDocument);
        userDocumentRepository.save(userDocument);
        log.info("UserDocument indexed successfully in ES {}.", userDocument);

    }

    private UserDocument userDocumentCreate(User user) throws UserServiceException {

        @NotNull Optional<Country> country = countryRepository.findById(user.getCountryId());

        SimpleField simpleFieldCountry;

        if (country.orElse(null) != null) {
            simpleFieldCountry = SimpleField.builder()
                .id(country.orElse(null).getId())
                .name(country.orElse(null).getName())
                .build();
        } else {
            throw new UserServiceException("Country does not exist");
        }

        return UserDocument.builder()
            .id(user.getId())
            .firebaseId(user.getFirebaseId())
            .nickname(user.getNickname())
            .firstname(user.getFirstname())
            .lastname(user.getLastname())
            .email(user.getEmail())
            .phone(user.getPhone())
            .documentId(user.getDocumentId())
            .documentType(user.getDocumentType())
            .address(user.getAddress())
            .city(user.getCity())
            .state(user.getState())
            .type(user.getType().toString())
            .documentDateExpiration(user.getDocumentDateExpiration())
            .country(simpleFieldCountry)
            .languageId(user.getLanguageId())
            .status(user.getStatus())
            .build();

    }
}
