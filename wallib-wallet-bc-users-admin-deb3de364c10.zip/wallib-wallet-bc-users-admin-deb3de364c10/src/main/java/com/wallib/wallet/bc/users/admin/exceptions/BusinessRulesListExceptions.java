package com.wallib.wallet.bc.users.admin.exceptions;

import java.io.Serial;

public class BusinessRulesListExceptions {

    private BusinessRulesListExceptions() {
    }

    public static class InvalidParameter extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public InvalidParameter(String msg, Throwable err) {
            super(msg, err);
        }

        public InvalidParameter(String msg) {
            super(msg);
        }

    }

    public static class UserServiceException extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public UserServiceException(String msg, Throwable err) {
            super(msg, err);
        }

        public UserServiceException(String msg) {
            super(msg);
        }

    }

    public static class CountryServiceException extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public CountryServiceException(String msg, Throwable err) {
            super(msg, err);
        }

        public CountryServiceException(String msg) {
            super(msg);
        }

    }

    public static class DocumentTypeServiceException extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public DocumentTypeServiceException(String msg, Throwable err) {
            super(msg, err);
        }

        public DocumentTypeServiceException(String msg) {
            super(msg);
        }

    }

    public static class UserPinServiceException extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public UserPinServiceException(String msg, Throwable err) {
            super(msg, err);
        }

        public UserPinServiceException(String msg) {
            super(msg);
        }
    }

    public static class KeyPairServiceException extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public KeyPairServiceException(String msg, Throwable err) {
            super(msg, err);
        }

        public KeyPairServiceException(String msg) {
            super(msg);
        }
    }

    public static class FcmRegistrationTokenException extends BaseException {

        @Serial
        private static final long serialVersionUID = 1L;

        public FcmRegistrationTokenException(String msg, Throwable err) {
            super(msg, err);
        }

        public FcmRegistrationTokenException(String msg) {
            super(msg);
        }

    }
}
