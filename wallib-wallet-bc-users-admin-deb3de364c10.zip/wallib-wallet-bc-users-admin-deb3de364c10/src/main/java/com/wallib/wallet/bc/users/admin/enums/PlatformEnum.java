package com.wallib.wallet.bc.users.admin.enums;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.converters.AbstractEnumConverter;
import javax.validation.constraints.NotNull;

public enum PlatformEnum implements PersistableEnum<String> {

    @JsonProperty("android")
    PLATFORM_ANDROID("android"),
    @JsonProperty("ios")
    PLATFORM_IOS("ios"),;

    private final String platform;

    PlatformEnum(@NotNull final String platform) {
        this.platform = platform;
    }

    @Override
    public String getValue(){
        return platform;
    }

    @Override
    public String toString(){
        return platform;
    }

    public String getPlatform() {
        return platform;
    }

    public static class Converter extends AbstractEnumConverter<PlatformEnum, String> {
        public Converter() {
            super(PlatformEnum.class);
        }
    }
}
