package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.documents.CountryDocument;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.repositories.es.CountryDocumentRepository;
import com.wallib.wallet.bc.users.admin.services.CountryElasticService;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CountryElasticServiceImpl implements CountryElasticService {
    
    private final CountryDocumentRepository countryDocumentRepository;

    public CountryElasticServiceImpl(CountryDocumentRepository countryDocumentRepository) {
        this.countryDocumentRepository = countryDocumentRepository;
    }

    @Override
    public void index(Country country) throws CountryServiceException {
        log.trace("Creating CountryDocument to index in ES with country {}.", country);
        CountryDocument countryDocument = countryDocumentCreate(country);
        log.trace("CountryDocument created and ready to be indexed in ES {}.", countryDocument);

        log.info("Indexing CountryDocument in ES {}.", countryDocument);
        countryDocumentRepository.save(countryDocument);
        log.info("CountryDocument indexed successfully in ES {}.", countryDocument);
    }

    private CountryDocument countryDocumentCreate(Country country) {

        return CountryDocument.builder()
            .id(country.getId())
            .name(country.getName())
            .isoCode(country.getIsoCode())
            .phoneCode(country.getPhoneCode())
            .status(country.getStatus())
            .build();
    }
}
