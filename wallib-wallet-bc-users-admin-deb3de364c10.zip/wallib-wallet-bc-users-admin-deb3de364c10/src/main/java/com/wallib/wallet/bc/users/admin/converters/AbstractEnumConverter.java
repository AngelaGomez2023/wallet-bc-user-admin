package com.wallib.wallet.bc.users.admin.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import com.wallib.wallet.bc.users.admin.enums.PersistableEnum;

@Converter
public abstract class AbstractEnumConverter<T extends Enum<T> & PersistableEnum<E>, E> implements AttributeConverter<T, E> {
    
    private final Class<T> clazz;

    protected AbstractEnumConverter(Class<T> clazz) {
        this.clazz = clazz;
    }

    @Override
    public E convertToDatabaseColumn(T attribute) {
        return attribute != null ? attribute.getValue() : null;
    }

    @Override
    public T convertToEntityAttribute(E dbData) {
        T[] enums = clazz.getEnumConstants();

        for (T e : enums) {
            if (e.getValue().toString().toLowerCase().equals(dbData)) {
                return e;
            }
        }

        throw new UnsupportedOperationException(clazz.getSimpleName() + " does not contain a member: " + dbData.toString());
    }
}
