package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.model.CountryDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateCountryDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateCountryDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseCountryDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.WalletUserRestException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Tag(name = "Countries")
public interface CountryControllerDocs {
    
    @Operation(summary = "List countries")
    @ApiResponse(
        responseCode = "200",
        description = "List countries",
        content = {
            @Content(mediaType = APPLICATION_JSON_VALUE,
                array = @ArraySchema(
                    schema = @Schema(implementation = CountryDTO.class)
                )
            )
        }
    )
    ResponseEntity<ApiResponseDTO<List<ResponseCountryDTO>>> list()
        throws WalletUserRestException, JsonProcessingException;

    @Operation(summary = "Find Country By Id")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Find Country By Id",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = CountryDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> findById(
        @Parameter(
            name = "id",
            description = "Country id to find by.",
            required = true
        ) Long id) throws JsonProcessingException;

    @Operation(summary = "Find Country By Iso Code")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Find Country By Iso Code",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = CountryDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> findByIsoCode(
        @Parameter(
            name = "iso code",
            description = "Country iso code to find by.",
            required = true
        ) String isoCode) throws JsonProcessingException;


    @Operation(summary = "Create country")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Country created successfully",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = CountryDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> create(
        @Parameter(
            name = "country",
            description = "Country to create.",
            required = true
        ) CreateCountryDTO createCountryDTO
    ) throws JsonProcessingException, CountryServiceException;

    @Operation(summary = "Update a country",
        description = "Allows to update a country only if country id exists.")
    @ApiResponse(
        responseCode = "202",
        description = "Country updated successfully.",
        content = {
            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = CreateCountryDTO.class))
        }
    )
    ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> update(
        @Parameter(
            name = "id",
            description = "Country Id to be updated.",
            required = true
        ) Long id,
        @Parameter(
            name = "Country",
            description = "Country to update.",
            required = true
        ) UpdateCountryDTO updateCountryDTO
    ) throws JsonProcessingException, CountryServiceException;

    @Operation(summary = "Delete a country",
        description = "Allows to delete a country only if country has no relations with other data.")
    @ApiResponse(
        responseCode = "200",
        description = "Country deleted successfully.",
        content = {
            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ApiResponseDTO.class))
        }
    )
    ResponseEntity<ApiResponseDTO<String>> delete(
        @Parameter(
            name = "id",
            description = "Country to delete.",
            required = true
        ) Long id
    ) throws JsonProcessingException, CountryServiceException;
}
