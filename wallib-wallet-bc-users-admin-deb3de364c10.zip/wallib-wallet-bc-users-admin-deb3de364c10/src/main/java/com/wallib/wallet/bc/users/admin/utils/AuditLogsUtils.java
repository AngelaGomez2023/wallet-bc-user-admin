package com.wallib.wallet.bc.users.admin.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.validation.constraints.NotNull;

import com.wallib.wallet.bc.users.admin.enums.AuditLogsActionsEnum;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.models.wt.AuditLog;

public class AuditLogsUtils {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private AuditLogsUtils() {
    }

    public static AuditLog getCreateAuditLog(AbstractFoundationEntity entity, Long userId)
            throws JsonProcessingException {

        String modifications = objectMapper.writeValueAsString(entity);

        return AuditLog.builder().action(AuditLogsActionsEnum.AUDIT_LOGS_CREATED.getAuditLogsAction()).userId(userId)
                .modelId(entity.getId()).modelName(entity.getClass().getSimpleName())
                .modification(String.format("{} => %s", modifications)).build();
    }

    public static AuditLog getUpdateAuditLog(Long id, @NotNull String oldEntity, @NotNull String newEntity,
            AbstractFoundationEntity entity, Long userId) {

        return AuditLog.builder().action(AuditLogsActionsEnum.AUDIT_LOGS_UPDATE.getAuditLogsAction()).userId(userId)
                .modelId(id).modelName(entity.getClass().getSimpleName())
                .modification(String.format("%s => %s", oldEntity, newEntity)).build();
    }

    public static AuditLog getDeleteAuditLog(AbstractFoundationEntity entity, Long userId)
            throws JsonProcessingException {

        String modifications = objectMapper.writeValueAsString(entity);

        return AuditLog.builder().action(AuditLogsActionsEnum.AUDIT_LOGS_DELETE.getAuditLogsAction()).userId(userId)
                .modelId(entity.getId()).modelName(entity.getClass().getSimpleName())
                .modification(String.format("%s => {}", modifications)).build();
    }
}
