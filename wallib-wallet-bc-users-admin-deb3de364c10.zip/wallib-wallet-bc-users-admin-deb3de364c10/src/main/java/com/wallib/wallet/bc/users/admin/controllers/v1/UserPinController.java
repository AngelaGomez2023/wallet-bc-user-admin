package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_USER_PIN;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_USER_PIN_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_USER_PIN;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_USER_PIN;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.UserPinControllerDocs;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateUserPinDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserPinDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseUserPinDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserPinFacade;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.core.JsonProcessingException;

@Slf4j
@RestController
@RequestMapping(value = "/v1/pins")
public class UserPinController implements UserPinControllerDocs {

    private final UserPinFacade userPinFacade;
    private final ModelMapper modelMapper;

    public UserPinController(UserPinFacade userPinFacade, ModelMapper modelMapper) {
        this.userPinFacade = userPinFacade;
        this.modelMapper = modelMapper;
    }

    @BasicLog
    @GetMapping(value = "{userId}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_USER_PIN_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> findByUserId(
        @PathVariable Long userId
    )
        throws JsonProcessingException, UserPinServiceException {

        log.trace("Request received on user pin controller with id {}", userId);

        UserPin userPin = userPinFacade.findByUserId(userId);

        log.trace("Generating UserPinDTO from get user pin. {}", userPin);
        ResponseUserPinDTO getMappedUserPin = generateUserPinDTOFromUser(userPin);
        log.trace("ResponseUserPinDTO generated successfully in findByUserId method. {}", getMappedUserPin);

        log.trace("Creating ApiResponse from userPinController [FINDBYID]");
        ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseUserPinDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("User retrieved successfully")
                .body(getMappedUserPin)
                .build());
        log.trace("Api response created from get user successfully {}", response);

        return response;
    }

    @BasicLog
    @PostMapping(value = "{userId}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + CREATE_USER_PIN + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> create(
        @PathVariable Long userId,
        @Valid @RequestBody CreateUserPinDTO createUserPinDTO)
            throws JsonProcessingException, UserPinServiceException {

        log.trace("Request received on user pin controller with body {}", createUserPinDTO);

        log.trace("Generating user pin object");
        UserPin userPinObject = generateUserPinFromCreateUserPinDTO(createUserPinDTO, userId);
        log.trace("User pin generated successfully {}", userPinObject);

        UserPin createdUserPin = userPinFacade.create(userPinObject);

        log.trace("Generating IserPinDTO from created hall. {}", createdUserPin);
        ResponseUserPinDTO mappedUserPin = generateUserPinDTOFromUser(createdUserPin);
        log.trace("ResponseUserPinDTO generated successfully in create method. {}", mappedUserPin);

        log.trace("Creating ApiResponse from userPinController [CREATE]");
        ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> response = ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponseDTO.<ResponseUserPinDTO>builder().statusCode(HttpStatus.CREATED.value())
                        .message("User pin created successfully").body(mappedUserPin).build());
        log.trace("Api response created from create user pin successfully {}", response);

        return response;
    }

    @BasicLog
    @PutMapping(value = "{userId}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + UPDATE_USER_PIN + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> update(
        @PathVariable Long userId,
        @Valid @RequestBody UpdateUserPinDTO updateUserPinDTO
    )
        throws JsonProcessingException, UserPinServiceException {

        log.trace("Request received on user pin controller with body {}", updateUserPinDTO);

        log.trace("Generating user pin update object");
        UserPin userPinObject = generateUserPinFromUpdateUserPinDTO(updateUserPinDTO);
        log.trace("User pin update generated successfully {}", userPinObject);

        UserPin updatedUserPin = userPinFacade.update(userId, updateUserPinDTO.getCurrentPin(), userPinObject);

        log.trace("Generating UserPinDTO from updated hall. {}", updatedUserPin);
        ResponseUserPinDTO mappedUserPin = generateUserPinDTOFromUser(updatedUserPin);
        log.trace("ResponseUserPinDTO generated successfully in update method. {}", mappedUserPin);

        log.trace("Creating ApiResponse from userPinController [UPDATE].");
        ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> response = ResponseEntity
            .status(HttpStatus.ACCEPTED)
            .body(ApiResponseDTO.<ResponseUserPinDTO>builder()
                .statusCode(HttpStatus.ACCEPTED.value())
                .message("User updated successfully")
                .body(mappedUserPin)
                .build());
        log.trace("Api response updated from update user pin successfully {}", response);

        return response;
    }

    @BasicLog
    @DeleteMapping(value = "{userId}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + DELETE_USER_PIN + "')")
    public ResponseEntity<ApiResponseDTO<String>> delete(@PathVariable Long userId)
        throws JsonProcessingException, UserPinServiceException {

        log.trace("Request received to delete user pin by user id {}", userId);
        userPinFacade.delete(userId);
        log.trace("User pin for user id {} successfully removed", userId);

        log.trace("Creating ApiResponse from userPinController [DELETE]");

        return ResponseEntity.status(HttpStatus.NO_CONTENT)
            .body(ApiResponseDTO.<String>builder()
                .statusCode(HttpStatus.NO_CONTENT.value())
                .message("User pin deleted successfully")
                .build());
    }

    private UserPin generateUserPinFromCreateUserPinDTO(@NotNull CreateUserPinDTO createUserPinDTO, @NotNull Long userId) {
        return UserPin.builder()
            .pin(createUserPinDTO.getPin())
            .userId(userId)
            .build();
    }

    private UserPin generateUserPinFromUpdateUserPinDTO(@NotNull UpdateUserPinDTO updateUserPinDTO) {
        return UserPin.builder()
            .pin(updateUserPinDTO.getPin())
            .userId(updateUserPinDTO.getUserId())
            .build();
    }

    private ResponseUserPinDTO generateUserPinDTOFromUser(UserPin userPin) {
        log.trace("generate UserPinDTO from ResponseUserPinDTO: {}", userPin.getUserId());
        ResponseUserPinDTO mappedUserPin = modelMapper.map(userPin, ResponseUserPinDTO.class);

        log.trace("mappedUserPin: {}", mappedUserPin);
        return mappedUserPin;
    }
}
