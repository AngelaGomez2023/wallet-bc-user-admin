package com.wallib.wallet.bc.users.admin.repositories.es;

import com.wallib.wallet.bc.users.admin.documents.UserDocument;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDocumentRepository extends
    ElasticsearchRepository<UserDocument, Long> {

}

