package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_USER;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_USER;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_FIREBASE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_NICKNAME;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_USER_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_USERS_BY_COUNTRY_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.MIN_CHARACTERS_TO_SEARCH;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UNSORTED;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_USER;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.UserControllerDocs;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.pageable.PageResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.pageable.PageableDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.pageable.SortDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateUserDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseUserDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserFacade;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.services.UserService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/v1/users")
public class UserController implements UserControllerDocs {

    private final UserService userService;
    private final UserFacade userFacade;
    private final ModelMapper modelMapper;

    public UserController(UserService userService, UserFacade userFacade, ModelMapper modelMapper) {
        this.userService = userService;
        this.userFacade = userFacade;
        this.modelMapper = modelMapper;
    }

    @BasicLog
    @Override
    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize(
        "hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + LIST_USERS_BY_COUNTRY_ID + "')")
    public ResponseEntity<ApiResponseDTO<PageResponseDTO<ResponseUserDTO>>> list(
        @RequestParam(value = "country_id") Long countryId,
        @RequestParam(value = "filter", required = false) String filter,
        @RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
        @RequestParam(value = "size", required = false) Integer size, Sort sort) {

        String finalFilter = "";

        if (filter != null && filter.length() >= MIN_CHARACTERS_TO_SEARCH) {
            finalFilter = filter;
        }

        Integer pageSize = size;

        if (pageSize == null) {
            pageSize = userService.countByCountryIdAndDeletedAtIsNull(countryId, filter);

            if (pageSize == 0) {
                PageResponseDTO<ResponseUserDTO> pageResponse = createEmptyPageResponse(sort);

                log.trace("Creating ApiResponse from DTO list.");
                return ResponseEntity.ok(ApiResponseDTO.<PageResponseDTO<ResponseUserDTO>>builder()
                    .statusCode(HttpStatus.OK.value()).message("Empty response").body(pageResponse)
                    .build());
            }
        }

        Pageable pageable = PageRequest.of(page, pageSize, sort);

        Page<User> userList = userService.list(countryId, finalFilter, pageable);

        log.trace("Generating DTO from users list. {}", userList);
        Page<ResponseUserDTO> userDTOList = userList.map(this::generateUserDTOFromUser);
        log.trace("ResponseUserDTO generated successfully. {}", userDTOList);

        log.trace("DTO list generated successfully {}.", userDTOList);

        List<ResponseUserDTO> usersSorted = new ArrayList<>(userDTOList.getContent());

        PageResponseDTO<ResponseUserDTO> pageResponse = createPageResponse(userDTOList, usersSorted,
            sort);

        log.trace("Creating ApiResponse from DTO list.");
        return ResponseEntity.ok(ApiResponseDTO.<PageResponseDTO<ResponseUserDTO>>builder()
            .statusCode(HttpStatus.OK.value()).message("Users retrieved successfully")
            .body(pageResponse).build());
    }

    @BasicLog
    @GetMapping(value = "{id}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_USER_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserDTO>> findById(@PathVariable Long id)
        throws JsonProcessingException {

        log.trace("Request received on user controller with id {}", id);

        User user = userService.findById(id);

        log.trace("Generating user DTO from get user. {}", user);
        ResponseUserDTO getMappedUser = generateUserDTOFromUser(user);
        log.trace("ResponseUserDTO generated successfully in findById method. {}", getMappedUser);

        log.trace("Creating ApiResponse from userController [FIND BY ID]");
        ResponseEntity<ApiResponseDTO<ResponseUserDTO>> response = ResponseEntity.status(
            HttpStatus.OK).body(
            ApiResponseDTO.<ResponseUserDTO>builder().statusCode(HttpStatus.OK.value())
                .message("User retrieved successfully").body(getMappedUser).build());
        log.trace("Api response created from get user successfully {}", response);

        return response;
    }

    @BasicLog
    @GetMapping(value = "/firebase", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_FIREBASE_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserDTO>> findByFirebaseId(
        @RequestParam(value = "firebase_id") String firebaseId) throws JsonProcessingException {

        log.trace("Request received on user controller with id {}", firebaseId);

        User user = userService.findByFirebaseId(firebaseId);

        log.trace("Generating user DTO from get user. {}", user);
        ResponseUserDTO getMappedUser = generateUserDTOFromUser(user);
        log.trace("ResponseUserDTO generated successfully in findByFirebaseId method. {}",
            getMappedUser);

        log.trace("Creating ApiResponse from userController [findByFirebaseId]");
        ResponseEntity<ApiResponseDTO<ResponseUserDTO>> response = ResponseEntity.status(
            HttpStatus.OK).body(
            ApiResponseDTO.<ResponseUserDTO>builder().statusCode(HttpStatus.OK.value())
                .message("User retrieved successfully").body(getMappedUser).build());
        log.trace("Api response created from get user from firebaseId successfully {}", response);

        return response;
    }

    @BasicLog
    @GetMapping(value = "", produces = APPLICATION_JSON_VALUE, params = "nickname")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_NICKNAME + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserDTO>> findByNickname(
        @RequestParam(name = "nickname") String nickname) throws JsonProcessingException {

        log.trace("Request received on user controller to find user by {}", nickname);

        User user = userService.findByNickname(nickname);

        log.trace("Generating user DTO from find user by nickname. {}", user);
        ResponseUserDTO getMappedUser = generateUserDTOFromUser(user);
        log.trace("ResponseUserDTO generated successfully in find user by nickname method. {}", getMappedUser);

        log.trace("Creating ApiResponse from userController [FIND BY NICKNAME]");
        ResponseEntity<ApiResponseDTO<ResponseUserDTO>> response = ResponseEntity.status(
            HttpStatus.OK).body(
            ApiResponseDTO.<ResponseUserDTO>builder().statusCode(HttpStatus.OK.value())
                .message("User by nickname retrieved successfully").body(getMappedUser).build());
        log.trace("Api response created from find user by nickname successfully {}", response);

        return response;
    }

    @BasicLog
    @PostMapping(value = "", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + CREATE_USER + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserDTO>> create(
        @Valid @RequestBody CreateUserDTO createUserDTO)
        throws JsonProcessingException, UserServiceException {

        log.trace("Request received on user controller with body {}", createUserDTO);

        log.trace("Generating user object");
        User userObject = generateUserFromCreateUserDTO(createUserDTO);
        log.trace("User generated successfully {}", userObject);

        User createdUser = userFacade.create(userObject);

        log.trace("Generating user DTO from created user. {}", createdUser);
        ResponseUserDTO mappedUser = generateUserDTOFromUser(createdUser);
        log.trace("ResponseUserDTO generated successfully in create method. {}", mappedUser);

        log.trace("Creating ApiResponse from userController [CREATE]");
        ResponseEntity<ApiResponseDTO<ResponseUserDTO>> response = ResponseEntity.status(
            HttpStatus.CREATED).body(
            ApiResponseDTO.<ResponseUserDTO>builder().statusCode(HttpStatus.CREATED.value())
                .message("User created successfully").body(mappedUser).build());
        log.trace("Api response created from create user successfully {}", response);

        return response;
    }

    @BasicLog
    @PutMapping(value = "{id}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + UPDATE_USER + "')")
    public ResponseEntity<ApiResponseDTO<ResponseUserDTO>> update(@PathVariable Long id,
        @Valid @RequestBody UpdateUserDTO updateUserDTO)
        throws JsonProcessingException, UserServiceException {

        log.trace("Request received on user controller with body {}", updateUserDTO);

        log.trace("Generating user update object");
        User userObject = generateUserFromUpdateUserDTO(updateUserDTO);
        log.trace("User update generated successfully {}", userObject);

        User updatedUser = userFacade.update(id, userObject);

        log.trace("Generating user DTO from updated user. {}", updatedUser);
        ResponseUserDTO mappedUser = generateUserDTOFromUser(updatedUser);
        log.trace("ResponseUserDTO generated successfully in update method. {}", mappedUser);

        log.trace("Creating ApiResponse from userController [UPDATE].");
        ResponseEntity<ApiResponseDTO<ResponseUserDTO>> response = ResponseEntity.status(
            HttpStatus.ACCEPTED).body(
            ApiResponseDTO.<ResponseUserDTO>builder().statusCode(HttpStatus.ACCEPTED.value())
                .message("User updated successfully").body(mappedUser).build());
        log.trace("Api response updated from update user successfully {}", response);

        return response;
    }

    @BasicLog
    @DeleteMapping(value = "{id}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + DELETE_USER + "')")
    public ResponseEntity<ApiResponseDTO<String>> delete(@PathVariable Long id)
        throws JsonProcessingException, UserServiceException {

        log.trace("Request received to delete user by id {}", id);
        userFacade.delete(id);
        log.trace("User with id {} successfully removed", id);

        log.trace("Creating ApiResponse from userController [DELETE]");

        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(
            ApiResponseDTO.<String>builder().statusCode(HttpStatus.NO_CONTENT.value())
                .message("User deleted successfully").build());

    }

    private User generateUserFromCreateUserDTO(@NotNull CreateUserDTO createUserDTO) {
        return User.builder()
            .firebaseId(createUserDTO.getFirebaseId())
            .nickname(createUserDTO.getNickname())
            .firstname(createUserDTO.getFirstname().trim())
            .lastname(createUserDTO.getLastname().trim())
            .email(createUserDTO.getEmail().trim())
            .phone(createUserDTO.getPhone() != null ? createUserDTO.getPhone().trim(): null)
            .documentId(createUserDTO.getDocumentId())
            .documentType(createUserDTO.getDocumentType())
            .documentDateExpiration(createUserDTO.getDocumentDateExpiration())
            .address(createUserDTO.getAddress())
            .city(createUserDTO.getCity())
            .state(createUserDTO.getState())
            .countryId(createUserDTO.getCountryId())
            .languageId(createUserDTO.getLanguageId())
            .type(createUserDTO.getType())
            .status(createUserDTO.getStatus()).build();
    }

    private User generateUserFromUpdateUserDTO(@NotNull UpdateUserDTO updateUserDTO) {
        return User.builder()
            .firebaseId(updateUserDTO.getFirebaseId())
            .nickname(updateUserDTO.getNickname())
            .firstname(updateUserDTO.getFirstname().trim())
            .lastname(updateUserDTO.getLastname().trim())
            .email(updateUserDTO.getEmail().trim())
            .phone(updateUserDTO.getPhone().trim())
            .documentId(updateUserDTO.getDocumentId())
            .documentType(updateUserDTO.getDocumentType())
            .documentDateExpiration(updateUserDTO.getDocumentDateExpiration())
            .address(updateUserDTO.getAddress())
            .city(updateUserDTO.getCity())
            .state(updateUserDTO.getState())
            .countryId(updateUserDTO.getCountryId())
            .languageId(updateUserDTO.getLanguageId())
            .type(updateUserDTO.getType())
            .status(updateUserDTO.getStatus()).build();
    }

    private ResponseUserDTO generateUserDTOFromUser(User user) {
        log.trace("generateUserDTOFromUser ResponseUserDTO: {}", user.getFirstname());
        ResponseUserDTO mappedUser = modelMapper.map(user, ResponseUserDTO.class);
        mappedUser.setId(user.getId());
        log.trace("mappedUser: {}", mappedUser);
        return mappedUser;
    }

    private PageResponseDTO<ResponseUserDTO> createPageResponse(Page<ResponseUserDTO> userPage,
        List<ResponseUserDTO> sortedList, Sort sort) {
        return PageResponseDTO.<ResponseUserDTO>builder().content(sortedList).pageable(
                PageableDTO.builder().sort(SortDTO.builder().sorted(!sort.toString().equals(UNSORTED))
                        .unsorted(sort.toString().equals(UNSORTED))
                        .empty(userPage.getPageable().getSort().isEmpty()).build())
                    .offset(userPage.getPageable().getOffset())
                    .pageNumber(userPage.getPageable().getPageNumber())
                    .paged(userPage.getPageable().isPaged()).unpaged(userPage.getPageable().isUnpaged())
                    .build()).totalPages(userPage.getTotalPages())
            .totalElements(userPage.getTotalElements()).last(userPage.isLast())
            .numberOfElements(userPage.getNumberOfElements()).number(userPage.getNumber())
            .size(userPage.getSize()).sort(
                SortDTO.builder().sorted(!sort.toString().equals(UNSORTED))
                    .unsorted(sort.toString().equals(UNSORTED)).empty(userPage.getSort().isEmpty())
                    .build()).first(userPage.isFirst()).empty(userPage.isEmpty()).build();
    }

    private PageResponseDTO<ResponseUserDTO> createEmptyPageResponse(Sort sort) {
        return PageResponseDTO.<ResponseUserDTO>builder().content(Collections.emptyList()).pageable(
                PageableDTO.builder().sort(SortDTO.builder().sorted(!sort.toString().equals(UNSORTED))
                        .unsorted(sort.toString().equals(UNSORTED)).empty(true).build()).offset(0)
                    .pageNumber(0).paged(false).unpaged(true).build()).totalPages(0).totalElements(0)
            .last(false).numberOfElements(0).number(0).size(1).sort(
                SortDTO.builder().sorted(!sort.toString().equals(UNSORTED))
                    .unsorted(sort.toString().equals(UNSORTED)).empty(true).build()).first(false)
            .empty(true).build();
    }
}
