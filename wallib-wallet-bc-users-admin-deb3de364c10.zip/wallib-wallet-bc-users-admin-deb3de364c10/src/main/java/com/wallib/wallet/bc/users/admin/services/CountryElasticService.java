package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;

public interface CountryElasticService {
    
    void index(Country country) throws CountryServiceException;
}
