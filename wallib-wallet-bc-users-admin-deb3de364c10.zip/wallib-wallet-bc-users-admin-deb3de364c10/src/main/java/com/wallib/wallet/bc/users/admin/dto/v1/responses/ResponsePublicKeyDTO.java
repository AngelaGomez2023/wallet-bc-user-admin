package com.wallib.wallet.bc.users.admin.dto.v1.responses;

import java.io.Serializable;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponsePublicKeyDTO implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(example = "2")
    @JsonProperty(value = "user_id")
    private Long userId;

    @Schema(example = "RSA")
    @JsonProperty(value = "algorithm")
    private String algorithm;

    @Schema(example = "")
    @JsonProperty(value = "public_key")
    private String publicKey;
}
