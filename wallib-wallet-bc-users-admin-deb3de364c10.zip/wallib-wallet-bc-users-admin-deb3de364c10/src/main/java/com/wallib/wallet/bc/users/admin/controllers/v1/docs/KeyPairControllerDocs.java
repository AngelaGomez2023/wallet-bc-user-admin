package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponsePublicKeyDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.KeyPairServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Tag(name = "Key pairs")
public interface KeyPairControllerDocs {
    
    @Operation(summary = "Create Key pair")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Key pair created successfully", content = {
		@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
            schema = @Schema(implementation = ApiResponseDTO.class))
	})})
	ResponseEntity<ApiResponseDTO<ResponsePublicKeyDTO>> create(
		@Parameter(
			name = "userId", 
			description = "Id of user for which key pair will be created.", 
			required = true
		) Long userId)
		throws JsonProcessingException, KeyPairServiceException, RSAKeyPairException;
}
