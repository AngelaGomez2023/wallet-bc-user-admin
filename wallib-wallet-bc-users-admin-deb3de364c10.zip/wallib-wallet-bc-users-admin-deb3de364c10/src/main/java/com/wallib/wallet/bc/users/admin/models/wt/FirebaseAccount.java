package com.wallib.wallet.bc.users.admin.models.wt;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.serializers.wt.FirebaseAccountSerializer;
import java.io.Serial;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@Table(name = "firebase_accounts", schema = "wallet")
@JsonSerialize(using = FirebaseAccountSerializer.class)
public class FirebaseAccount extends AbstractFoundationEntity {

    @Serial
    private static final long serialVersionUID = 1L;

    @Column(name = "firebase_id", nullable = false)
    private String firebaseId;

    @Column(name = "email")
    private String email;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "email_verified")
    private Boolean emailVerified;

    @Column(name = "disabled", nullable = false)
    private Boolean disabled;

    @Column(name = "provider_user_info")
    @JsonRawValue
    private String providerUserInfo;

    @Column(name = "mfa_info")
    @JsonRawValue
    private String mfaInfo;

    @Column(name = "last_login_at", nullable = false)
    private Long lastLoginAt;

    @Column(name = "firebase_created_at", nullable = false)
    private Long firebaseCreatedAt;
}
