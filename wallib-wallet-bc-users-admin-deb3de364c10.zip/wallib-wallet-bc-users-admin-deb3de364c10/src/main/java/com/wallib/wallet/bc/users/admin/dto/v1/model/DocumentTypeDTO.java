package com.wallib.wallet.bc.users.admin.dto.v1.model;

import com.wallib.wallet.bc.users.admin.dto.v1.AbstractFoundationDTO;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class DocumentTypeDTO extends AbstractFoundationDTO {
    
    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(example = "CC")
    @JsonProperty(value = "type")
    private String type;

    @Schema(example = "1")
    @JsonProperty(value = "country_id")
    private Long countryId;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
