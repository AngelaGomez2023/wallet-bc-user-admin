package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;

public interface DocumentTypeElasticFacade {
    
    void indexByDocumentType(Long documentTypeId) throws JsonProcessingException,
        DocumentTypeServiceException;
}
