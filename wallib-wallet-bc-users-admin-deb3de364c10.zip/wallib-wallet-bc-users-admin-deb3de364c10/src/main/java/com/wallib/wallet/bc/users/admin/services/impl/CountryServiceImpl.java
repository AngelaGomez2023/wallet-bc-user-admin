package com.wallib.wallet.bc.users.admin.services.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.ACTIVE;

import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.services.AuditLogService;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class CountryServiceImpl implements CountryService{
    
    private final CountryRepository countryRepository;
    private final AuditLogService auditLogService;

    public CountryServiceImpl(AuditLogService auditLogService,
            CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
        this.auditLogService = auditLogService;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public List<Country> list() {
        return countryRepository.findAll();
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public Country findById(Long id){
        log.trace("Starting process to get country object {}", id);

        log.trace("Checking if country with id {} exists", id);
        Country country = getCountry(id);
        log.trace("Country with id {} found. {}", country.getId(), id);

        return country;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public Country findByIsoCode(String isoCode){
        log.trace("Starting process to get country object by isoCode {}", isoCode);

        log.trace("Checking if country with isoCode {} exists", isoCode);
        Country country = getCountryByIsoCode(isoCode);
        log.trace("Country with iso code {} found. {}", country.getIsoCode(), country);

        return country;
    }

    @BasicLog
    @Override
    public Country create(Country country)
        throws JsonProcessingException, CountryServiceException {
        log.trace("Starting process on create country service with object {}", country);

        log.trace("Validate unique iso_code {} ", country.getIsoCode());
        validateIsoCodeUniqueByCountry(country.getIsoCode());
        log.trace("ISO Code is unique");

        country.setStatus(ACTIVE);

        log.trace("Saving country. {}", country);
        Country createdCountry = countryRepository.save(country);
        log.trace("Country saved successfully. {}", createdCountry);

        auditLogService.createAuditLog(createdCountry);

        return createdCountry;
    }

    @BasicLog
    @Override
    public Country update(Long id, Country countryChanges)
        throws JsonProcessingException, CountryServiceException {
        log.trace("Starting process on update country service with object {}", countryChanges);

        log.trace("Validate if country id exists {} ", id);
        Country countryToUpdate = getCountry(id);
        log.trace("Country id exists. {}", countryToUpdate);

        log.trace("Validate unique iso_code {} ", countryChanges.getIsoCode());
        validateIsoCodeUniqueByCountryAndNotId(id, countryChanges.getIsoCode());
        log.trace("ISO Code is unique");
        
        Country beforeUpdate = countryToUpdate.toBuilder().build();
        
        updateCountryFields(countryToUpdate, countryChanges);
        log.trace("Country fields updated {}", countryToUpdate);

        log.trace("Updating country. {}", countryToUpdate);
        Country updatedCountry = countryRepository.saveAndFlush(countryToUpdate);
        log.trace("Country updated successfully. {}", updatedCountry);

        auditLogService.updateAuditLog(beforeUpdate, updatedCountry);

        return updatedCountry;
    }

    @BasicLog
    @Override
    public void delete(Long id) throws JsonProcessingException {
        log.trace("Validating if Country {} exists", id);
        Country country = getCountry(id);
        log.trace("Country with id {} found. {}", id, country);

        log.trace("Deleting Country {}", id);
        countryRepository.delete(country);
        log.trace("Country {} deleted successfully", id);

        auditLogService.deleteAuditLog(country);

    }

    private Country getCountry(@NotNull Long id) {
        return countryRepository.findById(id).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("Country with id: %1$s not found", id)));
    }

    private Country getCountryByIsoCode(@NotNull String isoCode) {
        return countryRepository.findByIsoCodeAndDeletedAtIsNull(isoCode).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("Country with iso code: %1$s not found", isoCode)));
    }

    private void validateIsoCodeUniqueByCountry(@NotNull String isoCode)
        throws CountryServiceException {
        boolean isoCodeExist =
            countryRepository.existsByIsoCodeAndDeletedAtIsNull(isoCode);
        if (isoCodeExist) {
            throw new CountryServiceException(
                String.format("ISO Code '%1$s' is not unique in database", isoCode));
        }
    }

    private void validateIsoCodeUniqueByCountryAndNotId(
        @NotNull Long id,
        @NotNull String isoCode
    )
        throws CountryServiceException {
        boolean isoCodeExist =
            countryRepository.existsByIsoCodeAndIdNotAndDeletedAtIsNull(isoCode, id);
        if (isoCodeExist) {
            throw new CountryServiceException(
                String.format("ISO Code '%1$s' is not unique in database", isoCode));
        }
    }

    private void updateCountryFields(@NotNull Country countryToUpdate,
        @NotNull Country countryChanges)
        throws CountryServiceException {

        log.trace("Checking if Country with name {} exists", countryChanges.getName());
        boolean countryNameExist = countryRepository.existsByNameAndIdNotAndDeletedAtIsNull(
            countryChanges.getName(), countryToUpdate.getId());
        if (countryNameExist) {
            throw new CountryServiceException(
                String.format("Country with name %s already exists", countryChanges.getName()));
        }
        countryToUpdate.setName(countryChanges.getName());
        countryToUpdate.setIsoCode(countryChanges.getIsoCode());
        countryToUpdate.setPhoneCode(countryChanges.getPhoneCode());
    }
}
