package com.wallib.wallet.bc.users.admin.producers;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import javax.jms.Message;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MessageProducer {

    private final JmsTemplate jmsTemplate;

    @Value("${activemq.wallet.bc.users.admin.queue}")
    private String destination;

    public MessageProducer(@NotNull final JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    @BasicLog
    public void sendToUserEvent(IndexEventDTO indexEventDTO) {
        log.info("Sending message to ActiveMQ queue {}.", destination);
        jmsTemplate.convertAndSend(destination, indexEventDTO,
            (Message message) -> {
                message.setStringProperty("action", indexEventDTO.getAction());
                message.setStringProperty("entity", indexEventDTO.getEntity());
                return message;
            });
        log.info("Message sent to queue {}.", destination);
    }

}
