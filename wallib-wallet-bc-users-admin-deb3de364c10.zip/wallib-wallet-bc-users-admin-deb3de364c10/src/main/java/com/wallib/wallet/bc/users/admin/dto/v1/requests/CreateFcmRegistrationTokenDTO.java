package com.wallib.wallet.bc.users.admin.dto.v1.requests;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateFcmRegistrationTokenDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 885810427085239638L;

    @NotNull
    @Schema(example = "1")
    @JsonProperty(value = "firebase_id")
    private Long firebaseId;

    @NotBlank
    @Size(min = 1, max = 165)
    @Schema(example = "dl0H754sRxaOpzKHfsjA32:APA91bEH6R73ixG0C_Xoxz8XXp4HBn_nKIYPGJPkvXnesWUdw6nd1PgHGMNS3GtVrVHb3kSq59FDpw-h69nawxkqCyNca8NoyWPoMAmp4O7Oa-CIev-adHSjjoAiXjVTWWjwXeUt4alA")
    @JsonProperty(value = "token")
    private String token;

    @NotNull
    @Schema(example = "android")
    @JsonProperty(value = "platform")
    private PlatformEnum platform;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;

}
