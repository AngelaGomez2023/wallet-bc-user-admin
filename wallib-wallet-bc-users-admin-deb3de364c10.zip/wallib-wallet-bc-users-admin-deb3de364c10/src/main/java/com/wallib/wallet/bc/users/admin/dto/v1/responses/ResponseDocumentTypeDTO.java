package com.wallib.wallet.bc.users.admin.dto.v1.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponseDocumentTypeDTO {
    
    @Schema(example = "Id")
    @JsonProperty(value = "id")
    private Long id;

    @Schema(example = "CC")
    @JsonProperty(value = "type")
    private String type;

    @Schema(example = "1")
    @JsonProperty(value = "country_id")
    private Long countryId;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
