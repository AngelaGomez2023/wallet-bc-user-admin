package com.wallib.wallet.bc.users.admin.consumers;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DOCUMENT_TYPE_ENTITY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.facades.DocumentTypeElasticFacade;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import org.springframework.messaging.handler.annotation.Payload;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DocumentTypeMessageConsumer {
    
    private final DocumentTypeElasticFacade documentTypeElasticFacade;

    @Value("${activemq.wallet.bc.users.admin.queue}")
    private String sourceQueue;

    public DocumentTypeMessageConsumer(@NotNull final DocumentTypeElasticFacade documentTypeElasticFacade) {
        this.documentTypeElasticFacade = documentTypeElasticFacade;
    }

    @BasicLog
    @JmsListener(destination = "${activemq.wallet.bc.users.admin.queue}",
        selector = "(action = '" + EVENT_INSERT 
                + "' OR action = '" + EVENT_UPDATE 
                + "' OR action = '" + EVENT_DELETE 
                + "') AND entity = '" + DOCUMENT_TYPE_ENTITY + "'")
    public void receiveUserMessage(@Payload @NotNull IndexEventDTO indexEvent)
        throws JsonProcessingException, DocumentTypeServiceException {
        try {
            log.info("User: message received from the ActiveMQ queue {} to create/update index. {}",
                sourceQueue, indexEvent);
                documentTypeElasticFacade.indexByDocumentType(indexEvent.getEntityId());
        } catch (EntityNotFoundException ex) {
            log.error(ex.getMessage());
            throw ex;
        } catch (RuntimeException | JsonProcessingException ex) {
            log.error("Document not indexed by DocumentType, object has errors: " + ex.getMessage(), ex);
            throw ex;
        } catch (DocumentTypeServiceException ex) {
            log.error(ex.getMessage());
            throw new DocumentTypeServiceException(ex.getMessage());
        }
    }
}
