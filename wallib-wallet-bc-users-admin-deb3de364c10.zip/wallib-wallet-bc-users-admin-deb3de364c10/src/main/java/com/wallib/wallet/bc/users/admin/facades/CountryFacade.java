package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;

public interface CountryFacade {
    
    Country create(Country country) throws CountryServiceException, JsonProcessingException;

    Country update(Long id, Country country) throws CountryServiceException, JsonProcessingException;
    
    void delete(Long id) throws CountryServiceException, JsonProcessingException;
}
