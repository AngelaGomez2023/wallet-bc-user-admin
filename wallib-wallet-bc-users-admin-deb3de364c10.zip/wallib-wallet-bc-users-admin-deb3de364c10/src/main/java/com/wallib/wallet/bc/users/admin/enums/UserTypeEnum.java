package com.wallib.wallet.bc.users.admin.enums;

import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.converters.AbstractEnumConverter;

public enum UserTypeEnum implements PersistableEnum<String> {

    @JsonProperty("user")
    USER_TYPE_USER("user"),
    @JsonProperty("anonymous")
    USER_TYPE_ANONYMOUS("anonymous"),
    @JsonProperty("merchant")
    USER_TYPE_MERCHANT("merchant");

    private final String userType;

    UserTypeEnum(@NotNull final String userType) {
        this.userType = userType;
    }

    @Override
    public String getValue(){
        return userType;
    }

    @Override
    public String toString(){
        return userType;
    }

    public String getUserType() {
        return userType;
    }

    public static class Converter extends AbstractEnumConverter<UserTypeEnum, String> {
        public Converter() {
            super(UserTypeEnum.class);
        }
    }
}
