package com.wallib.wallet.bc.users.admin.repositories.wt;

import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentTypeRepository extends WallibRepository<DocumentType, Long>{

    public boolean existsByTypeAndCountryIdAndDeletedAtIsNull(String type, Long countryId);

    public boolean existsByTypeAndCountryIdAndIdNotAndDeletedAtIsNull(String type, Long countryId, Long id);
}
