package com.wallib.wallet.bc.users.admin.facades.impl;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.documents.FcmRegistrationTokenDocument;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenElasticFacade;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenElasticService;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenService;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class FcmRegistrationTokenElasticFacadeImpl implements FcmRegistrationTokenElasticFacade {

    private final FcmRegistrationTokenService fcmRegistrationTokenService;
    private final FcmRegistrationTokenElasticService fcmRegistrationTokenElasticService;
    private final ModelMapper modelMapper;

    public FcmRegistrationTokenElasticFacadeImpl(
        @NotNull final FcmRegistrationTokenService fcmRegistrationTokenService,
        @NotNull final FcmRegistrationTokenElasticService fcmRegistrationTokenElasticService,
        ModelMapper modelMapper) {
        this.fcmRegistrationTokenService = fcmRegistrationTokenService;
        this.fcmRegistrationTokenElasticService = fcmRegistrationTokenElasticService;
        this.modelMapper = modelMapper;
    }

    @BasicLog
    @Override
    public FcmRegistrationToken findByFirebaseId(Long firebaseId)
        throws FcmRegistrationTokenException {
        log.trace("FirebaseId received to find FCM registration token: {}.", firebaseId);

        FcmRegistrationToken fcmRegistrationToken;

        log.trace("Find by FCM registration token from Elastic.");
        Optional<FcmRegistrationTokenDocument> fcmRegistrationTokenDocument =
            fcmRegistrationTokenElasticService.findByFirebaseId(firebaseId);

        if (fcmRegistrationTokenDocument.isEmpty()) {
            fcmRegistrationToken = fcmRegistrationTokenService.findByFirebaseId(firebaseId);
            log.trace("FCM registration token with firebaseId {} found from JPA: {}.", firebaseId,
                fcmRegistrationToken);
        } else {
            fcmRegistrationToken = FcmRegistrationToken.builder()
                .id(fcmRegistrationTokenDocument.get().getId())
                .token(fcmRegistrationTokenDocument.get().getToken())
                .firebaseId(fcmRegistrationTokenDocument.get().getFirebaseId())
                .platform(PlatformEnum.valueOf("PLATFORM_" +
                    fcmRegistrationTokenDocument.get().getPlatform().toUpperCase()))
                .status(fcmRegistrationTokenDocument.get().getStatus())
                .build();
            log.trace("FCM registration token with firebaseId {} found in ES: {}.", firebaseId,
                fcmRegistrationToken);
        }

        return fcmRegistrationToken;
    }

    @BasicLog
    @Override
    public void indexByFcmRegistrationToken(Long id) throws FcmRegistrationTokenException {
        log.trace("FCM registration token received to index: {}.", id);
        FcmRegistrationToken fcmRegistrationToken = fcmRegistrationTokenService.findById(id);
        log.trace("FCM registration token found to index: {}.", fcmRegistrationToken);
        fcmRegistrationTokenElasticService.index(fcmRegistrationToken);
    }
}
