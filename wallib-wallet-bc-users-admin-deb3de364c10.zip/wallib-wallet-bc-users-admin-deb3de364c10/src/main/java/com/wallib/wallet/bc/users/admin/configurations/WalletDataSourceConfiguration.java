package com.wallib.wallet.bc.users.admin.configurations;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableTransactionManagement
@EnableJpaAuditing
@EnableJpaRepositories(
        entityManagerFactoryRef = "walletEntityManagerFactory",
        transactionManagerRef = "walletTransactionManager",
        basePackages = {
            "com.wallib.wallet.bc.users.admin.repositories.wt"
        }
)
public class WalletDataSourceConfiguration {

    @Primary
    @Bean(name = "walletDataSource")
    @ConfigurationProperties(prefix = "spring.datasource-ct")
    public DataSource walletDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "walletEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean walletEntityManagerFactory(
            EntityManagerFactoryBuilder builder,
            @Qualifier("walletDataSource") DataSource dataSource) {
        Map<String, String> jpaProperties = new HashMap<>();
        jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        return builder.dataSource(dataSource)
                .packages(
                    "com.wallib.wallet.bc.users.admin.models.wt"
                )
                .persistenceUnit("walletPersistenceUnit")
                .properties(jpaProperties)
                .build();
    }

    @Primary
    @Bean(name = "walletTransactionManager")
    public PlatformTransactionManager walletTransactionManager(
            @Qualifier("walletEntityManagerFactory") EntityManagerFactory walletEntityManagerFactory) {
        return new JpaTransactionManager(walletEntityManagerFactory);
    }

}
