package com.wallib.wallet.bc.users.admin.enums;

public interface PersistableEnum<T> {
    public T getValue();
}
