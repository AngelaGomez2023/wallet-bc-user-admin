package com.wallib.wallet.bc.users.admin.repositories.wt;

import java.util.Optional;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import org.springframework.stereotype.Repository;

@Repository
public interface CountryRepository extends WallibRepository<Country, Long> {

    Optional<Country> findByIsoCodeAndDeletedAtIsNull(String isoCode);

    Boolean existsByIsoCodeAndDeletedAtIsNull(String isoCode);

    Boolean existsByIsoCodeAndIdNotAndDeletedAtIsNull(String isoCode, Long id);

    Boolean existsByNameAndIdNotAndDeletedAtIsNull(String name, Long id);

}
