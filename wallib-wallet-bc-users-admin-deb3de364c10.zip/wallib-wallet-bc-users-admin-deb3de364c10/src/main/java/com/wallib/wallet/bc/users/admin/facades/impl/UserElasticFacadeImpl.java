package com.wallib.wallet.bc.users.admin.facades.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserElasticFacade;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.services.UserElasticService;
import com.wallib.wallet.bc.users.admin.services.UserService;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserElasticFacadeImpl implements UserElasticFacade {

    private final UserService userService;
    private final UserElasticService userElasticService;

    public UserElasticFacadeImpl(@NotNull final UserService userService,
        @NotNull final UserElasticService userElasticService) {
        this.userService = userService;
        this.userElasticService = userElasticService;
    }

    @BasicLog
    @Override
    public void indexByUser(Long userId) throws JsonProcessingException, UserServiceException {
        log.trace("User ID received to index: {}.", userId);
        User user = userService.findById(userId);
        log.trace("User found to index: {}.", user);
        userElasticService.index(user);
    }
}
