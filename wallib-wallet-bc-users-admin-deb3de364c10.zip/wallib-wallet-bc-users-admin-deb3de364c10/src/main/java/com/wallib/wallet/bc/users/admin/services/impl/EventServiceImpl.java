package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.producers.MessageProducer;
import com.wallib.wallet.bc.users.admin.services.EventService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EventServiceImpl implements EventService {

    private final MessageProducer messageProducer;

    public EventServiceImpl(MessageProducer messageProducer) {
        this.messageProducer = messageProducer;
    }

    @BasicLog
    @Override
    public void sendEventToQueue(String event, String entity, Long id) {

        log.info(String.format("Sending action %1$s to ActiveMQ for save %2$s.", event, entity));
        messageProducer.sendToUserEvent(new IndexEventDTO(event, entity, id));
        log.info(
            String.format("Event %1$s sent successfully to ActiveMQ for %2$s.", event, entity));

    }
}

