package com.wallib.wallet.bc.users.admin.repositories.wt;

import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface WallibRepository<T extends AbstractFoundationEntity, I extends Long> extends JpaRepository<T, I> {

    @Override
    @Transactional
    @Query("select e from #{#entityName} e where e.deletedAt is null")
    @NotNull
    List<T> findAll();

    @Override
    @Transactional
    @Query("select e from #{#entityName} e where e.id = ?1 and e.deletedAt is null")
    @NotNull
    Optional<T> findById(@NotNull Long id);

    @Override
    @Transactional
    default boolean existsById(@NotNull Long id) {
        return findById(id).isPresent();
    }

    @Query("update #{#entityName} e set e.deletedAt = ?2 where e.id = ?1")
    @Transactional
    @Modifying
    void deleteByIdAndDeletedAt(Long id, LocalDateTime deleteAt);

    @Override
    @Transactional
    @Modifying
    default void deleteById(@NotNull Long id) {
        deleteByIdAndDeletedAt(id, LocalDateTime.now());
    }

    @Override
    @Transactional
    @Modifying
    default void delete(T entity) {
        deleteById(entity.getId());
    }

    @Override
    @Transactional
    @Query("select count(e) from #{#entityName} e where e.deletedAt is null")
    long count();
}
