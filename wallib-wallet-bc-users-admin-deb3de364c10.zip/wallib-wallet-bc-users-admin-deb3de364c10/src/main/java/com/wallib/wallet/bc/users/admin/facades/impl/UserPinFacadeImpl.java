package com.wallib.wallet.bc.users.admin.facades.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.USER_PIN_ENTITY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.EventService;
import com.wallib.wallet.bc.users.admin.services.UserPinRedisService;
import com.wallib.wallet.bc.users.admin.services.UserPinService;
import javax.validation.constraints.NotNull;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;
import com.wallib.wallet.bc.users.admin.facades.UserPinFacade;

@Component
@Slf4j
public class UserPinFacadeImpl implements UserPinFacade {
    
    private final UserPinService userPinService;
    private final UserPinRedisService userPinRedisService;
    private final EventService eventService;

    public UserPinFacadeImpl(UserPinService userPinService,
        EventService eventService,
        UserPinRedisService userPinRedisService) {
        this.userPinService = userPinService;
        this.eventService = eventService;
        this.userPinRedisService = userPinRedisService;
    }

    @BasicLog
    @Override
    public UserPin findByUserId(@NotNull final Long userId)
        throws JsonProcessingException, UserPinServiceException {
        userPinRedisService.get(userId);
        log.trace("User pin for user with id {} was not found in Redis. Attempting to fetch it from DB.",
            userId);
        UserPin userPin = userPinService.findByUserId(userId);
        log.trace("User pin for user with id {} was found in DB, Caching in Redis.", userId);
        userPinRedisService.cache(userPin);

        return userPin;
    }

    @BasicLog
    @Override
    public UserPin create(@NotNull final UserPin createUserPin)
        throws UserPinServiceException, JsonProcessingException {
        UserPin userPin = userPinService.create(createUserPin);
        eventService.sendEventToQueue(EVENT_INSERT, USER_PIN_ENTITY, userPin.getUserId());
        return userPin;
    }

    @BasicLog
    @Override
    public UserPin update(@NotNull final Long id, @NotNull String currentPin, @NotNull final UserPin updateUserPin)
        throws UserPinServiceException, JsonProcessingException {
        UserPin userPin = userPinService.update(id, currentPin, updateUserPin);
        eventService.sendEventToQueue(EVENT_UPDATE, USER_PIN_ENTITY, userPin.getUserId());
        return userPin;
    }

    @BasicLog
    @Override
    public void delete(@NotNull final Long userId)
        throws UserPinServiceException, JsonProcessingException {
        userPinService.delete(userId);
        eventService.sendEventToQueue(EVENT_DELETE, USER_PIN_ENTITY, userId);
    }
}
