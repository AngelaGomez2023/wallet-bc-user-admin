package com.wallib.wallet.bc.users.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletBCUsersAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletBCUsersAdminApplication.class, args);
	}

}
