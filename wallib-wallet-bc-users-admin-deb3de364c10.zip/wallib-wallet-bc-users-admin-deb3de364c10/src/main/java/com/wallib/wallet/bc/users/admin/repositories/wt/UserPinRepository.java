package com.wallib.wallet.bc.users.admin.repositories.wt;

import java.util.Optional;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import org.springframework.stereotype.Repository;

@Repository
public interface UserPinRepository extends WallibRepository<UserPin, Long> {
    
    Optional<UserPin> findByUserIdAndDeletedAtIsNull(Long userId);

    boolean existsByUserIdAndPinNotAndDeletedAtIsNull(Long userId, String pin);

    boolean existsByUserIdAndDeletedAtIsNull(Long userId);
}
