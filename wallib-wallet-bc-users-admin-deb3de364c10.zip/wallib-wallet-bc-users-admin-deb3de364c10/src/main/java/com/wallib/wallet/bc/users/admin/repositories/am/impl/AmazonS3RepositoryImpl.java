package com.wallib.wallet.bc.users.admin.repositories.am.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FORMAT_INT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FORMAT_STRING;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.repositories.am.AmazonS3Repository;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AmazonS3RepositoryImpl implements AmazonS3Repository {

    @Value("${aws.s3.public.bucket.name}")
    private String publicKeysBucketName;
    @Value("${aws.s3.private.bucket.name}")
    private String privateKeysBucketName;
    @Value("${keypair.public-key-extension}")
    private String publicKeyExtension;
    @Value("${keypair.private-key-extension}")
    private String privateKeyExtension;
    private final AmazonS3 amazonS3;

    public AmazonS3RepositoryImpl(AmazonS3 amazonS3) {
        this.amazonS3 = amazonS3;
    }

    @BasicLog
    @Override
    public String uploadPublicKeyInputStreamToS3Bucket(final long userId,
        final InputStream inputStream)
        throws IOException {
        log.trace("Starting repository to upload public key to S3");

        String fileName = String.format(FORMAT_INT, userId, publicKeyExtension);

        ObjectMetadata objectMetadata = new ObjectMetadata();

        PutObjectRequest putObjectRequest = new PutObjectRequest(publicKeysBucketName, fileName,
            inputStream, objectMetadata);
        amazonS3.putObject(putObjectRequest);
        log.trace("File uploaded successfully to S3 bucket");

        return fileName;
    }

    @BasicLog
    @Override
    public String uploadPrivateKeyInputStreamToS3Bucket(final long userId,
        final InputStream inputStream) throws IOException {

        log.trace("Starting repository to upload private key to S3.");

        String fileName = String.format(FORMAT_INT, userId, privateKeyExtension);

        ObjectMetadata objectMetadata = new ObjectMetadata();

        PutObjectRequest putObjectRequest = new PutObjectRequest(privateKeysBucketName, fileName,
            inputStream, objectMetadata);
        amazonS3.putObject(putObjectRequest);
        log.trace("File uploaded successfully to S3 bucket.");

        return fileName;
    }

    @BasicLog
    @Override
    public String uploadFileToS3Bucket(String fileName, final InputStream inputStream, int length) {

        log.trace("Starting repository to upload file to S3: {}.", fileName);
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(length);
        PutObjectRequest putObjectRequest = new PutObjectRequest(privateKeysBucketName, fileName,
            inputStream, objectMetadata);
        amazonS3.putObject(putObjectRequest);

        log.trace("File uploaded successfully to S3 bucket.");

        return fileName;
    }

    @Override
    public String getPrivateKeyFromS3Bucket(final long userId) throws IOException {
        log.trace("Starting repository to download private key to S3.");
        String fileNamePrivateKey = String.format(FORMAT_INT, userId, privateKeyExtension);
        log.trace("Download private key from S3 with file: {}.", fileNamePrivateKey);

        S3Object objectPrivateKey = amazonS3.getObject(privateKeysBucketName, fileNamePrivateKey);
        S3ObjectInputStream finalObjectPrivateKey = objectPrivateKey.getObjectContent();

        InputStreamReader isReader = new InputStreamReader(finalObjectPrivateKey);
        BufferedReader reader = new BufferedReader(isReader);
        StringBuilder sb = new StringBuilder();
        String str;
        while((str = reader.readLine())!= null){
            sb.append(str);
        }
        return sb.toString();
    }

    @BasicLog
    @Override
    public String getPublicKeyFromS3Bucket(final long userId) throws IOException {
        log.trace("Starting repository to download public key to S3.");
        String fileNamePublicKey = String.format(FORMAT_INT, userId, publicKeyExtension);
        log.trace("Download public key from S3 with file: {}.", fileNamePublicKey);

        S3Object objectPublicKey = amazonS3.getObject(publicKeysBucketName, fileNamePublicKey);
        S3ObjectInputStream finalObjectPublicKey = objectPublicKey.getObjectContent();

        InputStreamReader isReader = new InputStreamReader(finalObjectPublicKey);
        BufferedReader reader = new BufferedReader(isReader);
        StringBuilder sb = new StringBuilder();
        String str;
        while((str = reader.readLine())!= null){
            sb.append(str);
        }
        return sb.toString();
    }


    @Override
    public String getPassphraseFromS3Bucket(String filename) throws IOException {

        S3Object objectPassphrase = amazonS3.getObject(privateKeysBucketName, filename);
        S3ObjectInputStream finalObjectPassphrase = objectPassphrase.getObjectContent();

        InputStreamReader isReader = new InputStreamReader(finalObjectPassphrase);
        BufferedReader reader = new BufferedReader(isReader);
        StringBuilder sb = new StringBuilder();
        String str;
        while((str = reader.readLine())!= null){
            sb.append(str);
        }
        return sb.toString();

    }

    @Override
    public String getSeedWordsFromS3Bucket(String filename) throws IOException {

        S3Object objectSeedWords = amazonS3.getObject(privateKeysBucketName, filename);
        S3ObjectInputStream finalObjectSeedWords = objectSeedWords.getObjectContent();

        InputStreamReader isReader = new InputStreamReader(finalObjectSeedWords);
        BufferedReader reader = new BufferedReader(isReader);
        StringBuilder sb = new StringBuilder();
        String str;
        while((str = reader.readLine())!= null){
            sb.append(str);
        }
        return sb.toString();

    }
}
