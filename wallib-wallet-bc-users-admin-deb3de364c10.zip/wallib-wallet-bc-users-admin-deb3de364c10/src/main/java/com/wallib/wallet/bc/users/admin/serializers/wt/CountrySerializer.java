package com.wallib.wallet.bc.users.admin.serializers.wt;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import java.io.IOException;
import java.io.Serial;

public class CountrySerializer extends StdSerializer<Country> {

    @Serial
    private static final long serialVersionUID = -1151213138603906365L;

    protected CountrySerializer(Class<Country> t) {
        super(t);
    }

    protected CountrySerializer() {
        this(null);
    }

    @Override
    public void serialize(Country country, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {

        jsonGenerator.writeStartObject();

        jsonGenerator.writeNumberField("id", country.getId());
        jsonGenerator.writeStringField("name", country.getName());
        if(country.getPhoneCode() != null){
            jsonGenerator.writeNumberField("phone_code", country.getPhoneCode());
        }
        jsonGenerator.writeNumberField("status", country.getStatus());

        jsonGenerator.writeStringField("created_at", country.getCreatedAt().toString());
        jsonGenerator.writeStringField("updated_at", country.getUpdatedAt().toString());

        if (country.getDeletedAt() != null) {
            jsonGenerator.writeStringField("deleted_at", country.getDeletedAt().toString());
        } else {
            jsonGenerator.writeNullField("deleted_at");
        }

        jsonGenerator.writeEndObject();

    }
}
