package com.wallib.wallet.bc.users.admin.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PublicKey {
    
    private Long userId;
    private String algorithm;
    private String publicKey;
}
