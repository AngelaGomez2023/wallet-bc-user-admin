package com.wallib.wallet.bc.users.admin.services.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.ACTIVE;

import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.DocumentTypeRepository;
import com.wallib.wallet.bc.users.admin.services.AuditLogService;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class DocumentTypeServiceImpl implements DocumentTypeService {
    
    private final DocumentTypeRepository documentTypeRepository;
    private final CountryRepository countryRepository;
    private final AuditLogService auditLogService;

    public DocumentTypeServiceImpl(AuditLogService auditLogService,
        CountryRepository countryRepository,
        DocumentTypeRepository documentTypeRepository) {
        this.documentTypeRepository = documentTypeRepository;
        this.auditLogService = auditLogService;
        this.countryRepository = countryRepository;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public List<DocumentType> list() {
        return documentTypeRepository.findAll();
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public DocumentType findById(Long id){
        log.trace("Starting process to get user object {}", id);

        log.trace("Checking if documentType with id {} exists", id);
        DocumentType documentType = getDocumentType(id);
        log.trace("DocumentType with id {} found. {}", documentType.getId(), id);

        return documentType;
    }

    @BasicLog
    @Override
    public DocumentType create(DocumentType documentType)
        throws JsonProcessingException, DocumentTypeServiceException {
        log.trace("Starting process on create documentType service with object {}", documentType);

        log.trace("Validate country with id {} ", documentType.getCountryId());
        validateCountryExists(documentType.getCountryId());
        log.trace("Country with id {} exists", documentType.getCountryId());

        log.trace("Validate unique document type {} ", documentType.getType());
        validateDocumentTypeUniqueByTypeAndCountry(documentType.getCountryId(), documentType.getType());
        log.trace("Document type is unique");

        documentType.setStatus(ACTIVE);

        log.trace("Saving documentType. {}", documentType);
        DocumentType createdDocumentType = documentTypeRepository.save(documentType);
        log.trace("DocumentType saved successfully. {}", createdDocumentType);

        auditLogService.createAuditLog(createdDocumentType);

        return createdDocumentType;
    }

    @BasicLog
    @Override
    public DocumentType update(Long id, DocumentType documentTypeChanges)
        throws JsonProcessingException, DocumentTypeServiceException {
        log.trace("Starting process on update documentType service with object {}", documentTypeChanges);

        log.trace("Validate if documentType id exists {} ", id);
        DocumentType documentTypeToUpdate = getDocumentType(id);
        log.trace("Country id exists. {}", documentTypeToUpdate);

        log.trace("Validate country with id {} ", documentTypeChanges.getCountryId());
        validateCountryExists(documentTypeChanges.getCountryId());
        log.trace("Country with id {} exists", documentTypeChanges.getCountryId());

        log.trace("Validate unique document type {} ", documentTypeChanges.getType());
        validateDocumentTypeUniqueByTypeAndCountryAndId(id, documentTypeChanges.getCountryId(), documentTypeChanges.getType());
        log.trace("Document type is unique");

        DocumentType beforeUpdate = documentTypeToUpdate.toBuilder().build();

        updateDocumentTypeFields(documentTypeToUpdate, documentTypeChanges);

        log.trace("Updating documentType. {}", documentTypeToUpdate);
        DocumentType updatedDocumentType = documentTypeRepository.saveAndFlush(documentTypeToUpdate);
        log.trace("DocumentType updated successfully. {}", updatedDocumentType);

        auditLogService.updateAuditLog(beforeUpdate, updatedDocumentType);

        return updatedDocumentType;
    }

    @BasicLog
    @Override
    public void delete(Long id) throws JsonProcessingException {
        log.trace("Validating if DocumentType {} exists", id);
        DocumentType documentType = getDocumentType(id);
        log.trace("DocumentType with id {} found. {}", id, documentType);

        log.trace("Deleting DocumentType {}", id);
        documentTypeRepository.delete(documentType);
        log.trace("DocumentType {} deleted successfully", id);

        auditLogService.deleteAuditLog(documentType);

    }

    private DocumentType getDocumentType(@NotNull Long id) {
        return documentTypeRepository.findById(id).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("DocumentType with id: %1$s not found", id)));
    }

    private void validateCountryExists(@NotNull Long id) throws DocumentTypeServiceException {
        boolean countryExists = countryRepository.existsById(id);
        log.trace("Country is: " + countryRepository.findById(id));
        if (!countryExists) {
            throw new DocumentTypeServiceException(String.format("Country with id '%1$s' doesn't exist.", id));
        }
    }

    private void validateDocumentTypeUniqueByTypeAndCountry(
        @NotNull Long countryId,
        @NotNull String type
    )
        throws DocumentTypeServiceException {
        boolean typeExists = 
            documentTypeRepository.existsByTypeAndCountryIdAndDeletedAtIsNull(type, countryId);
        if (typeExists) {
            throw new DocumentTypeServiceException(
                String.format("Document type '%1$s' is not unique for country with id '%2$s' in database", type, countryId));
        }
    }

    private void validateDocumentTypeUniqueByTypeAndCountryAndId(
        @NotNull Long id,
        @NotNull Long countryId,
        @NotNull String type
    )
        throws DocumentTypeServiceException {
        boolean typeExists = 
            documentTypeRepository.existsByTypeAndCountryIdAndIdNotAndDeletedAtIsNull(type, countryId, id);
        if (typeExists) {
            throw new DocumentTypeServiceException(
                String.format("Document type '%1$s' is not unique in for countryId '%2$s' database", type, countryId));
        }
    }

    private void updateDocumentTypeFields(@NotNull DocumentType documentTypeToUpdate,
        @NotNull DocumentType documentTypeChanges) {

        documentTypeToUpdate.setType(documentTypeChanges.getType());
        documentTypeToUpdate.setCountryId(documentTypeChanges.getCountryId());
    }
}
