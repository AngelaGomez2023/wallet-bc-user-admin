package com.wallib.wallet.bc.users.admin.handlers;

import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.WalletUserRestException;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Slf4j
public final class WebClientErrorHandler {

    private WebClientErrorHandler() {
    }

    public static Mono<WalletUserRestException> manageError(ClientResponse clientResponse) {
        return clientResponse
            .bodyToMono(Map.class).flatMap(WebClientErrorHandler::handleResponse);
    }

    private static Mono<WalletUserRestException> handleResponse(Map<String, Object> response) {
        log.info("Response received on Web Client Error Handler: {}", response);

        StringBuilder message = new StringBuilder();
        if (response.get("message") != null) {
            message.append(response.get("message"));
        }

        return Mono.error(new WalletUserRestException(message.toString()));
    }

}
