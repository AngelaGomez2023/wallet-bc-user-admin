package com.wallib.wallet.bc.users.admin.models.wt;

import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import lombok.Data;
import lombok.experimental.SuperBuilder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wallib.wallet.bc.users.admin.serializers.wt.UserPinSerializer;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.io.Serial;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@SuperBuilder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user_pins", schema = "wallet")
@JsonSerialize(using = UserPinSerializer.class)
public class UserPin extends AbstractFoundationEntity {
    
    @Serial
    private static final long serialVersionUID = 1L;

    @Column(name = "pin", nullable = false)
    private String pin;
    
    @Column(name = "user_id", nullable = false)
    private Long userId;

    public UserPin(Long id){
        super(id);
    }
}
