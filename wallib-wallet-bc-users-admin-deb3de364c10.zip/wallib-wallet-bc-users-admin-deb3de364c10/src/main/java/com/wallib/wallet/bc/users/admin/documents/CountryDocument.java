package com.wallib.wallet.bc.users.admin.documents;

import java.io.Serial;
import java.io.Serializable;
import org.springframework.data.elasticsearch.annotations.Document;
import lombok.AllArgsConstructor;
import javax.persistence.Id;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(indexName = "wallet_country")
public class CountryDocument implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    private Long id;

    @Field(type = FieldType.Text)
    private String name;

    @Field(type = FieldType.Text, fielddata = true)
    private String isoCode;

    @Field(type = FieldType.Integer)
    private Integer phoneCode;

    @Field(type = FieldType.Integer)
    private int status;

    public CountryDocument(Long id) {
        this.id = id;
    }
}
