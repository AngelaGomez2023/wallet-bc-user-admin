package com.wallib.wallet.bc.users.admin.facades.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.USER_ENTITY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserFacade;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.services.EventService;
import com.wallib.wallet.bc.users.admin.services.UserService;
import javax.validation.constraints.NotNull;
import org.springframework.stereotype.Component;

@Component
public class UserFacadeImpl implements UserFacade {

    private final UserService userService;
    private final EventService eventService;

    public UserFacadeImpl(UserService userService,
        EventService eventService) {
        this.userService = userService;
        this.eventService = eventService;
    }

    @BasicLog
    @Override
    public User create(@NotNull final User createUser)
        throws UserServiceException, JsonProcessingException {
        User user = userService.create(createUser);
        eventService.sendEventToQueue(EVENT_INSERT, USER_ENTITY, user.getId());
        return user;
    }

    @BasicLog
    @Override
    public User update(@NotNull final Long id, @NotNull final User updateUser)
        throws UserServiceException, JsonProcessingException {
        User user = userService.update(id, updateUser);
        eventService.sendEventToQueue(EVENT_UPDATE, USER_ENTITY, user.getId());
        return user;
    }

    @BasicLog
    @Override
    public void delete(@NotNull final Long id)
        throws UserServiceException, JsonProcessingException {
        userService.delete(id);
        eventService.sendEventToQueue(EVENT_DELETE, USER_ENTITY, id);
    }

}
