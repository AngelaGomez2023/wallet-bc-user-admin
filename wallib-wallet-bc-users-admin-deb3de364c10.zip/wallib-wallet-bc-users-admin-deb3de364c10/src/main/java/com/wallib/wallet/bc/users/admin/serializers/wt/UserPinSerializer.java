package com.wallib.wallet.bc.users.admin.serializers.wt;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import java.io.IOException;
import java.io.Serial;

public class UserPinSerializer extends StdSerializer<UserPin> {

    @Serial
    private static final long serialVersionUID = 1L;

    protected UserPinSerializer(Class<UserPin> t) {
        super(t);
    }

    protected UserPinSerializer() {
        this(null);
    }

    @Override
    public void serialize(UserPin user, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {

        jsonGenerator.writeStartObject();

        jsonGenerator.writeNumberField("id", user.getId());
        jsonGenerator.writeStringField("pin", user.getPin());
        jsonGenerator.writeNumberField("user_id", user.getUserId());

        jsonGenerator.writeStringField("created_at", user.getCreatedAt().toString());
        jsonGenerator.writeStringField("updated_at", user.getUpdatedAt().toString());

        if (user.getDeletedAt() != null) {
            jsonGenerator.writeStringField("deleted_at", user.getDeletedAt().toString());
        } else {
            jsonGenerator.writeNullField("deleted_at");
        }

        jsonGenerator.writeEndObject();

    }
}
