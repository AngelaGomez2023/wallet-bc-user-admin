package com.wallib.wallet.bc.users.admin.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserPinRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import com.wallib.wallet.bc.users.admin.services.AuditLogService;
import com.wallib.wallet.bc.users.admin.services.UserPinService;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class UserPinServiceImpl implements UserPinService {

    private final UserPinRepository userPinRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    public UserPinServiceImpl(UserPinRepository userPinRepository, AuditLogService auditLogService,
        UserRepository userRepository) {
        this.userPinRepository = userPinRepository;
        this.userRepository = userRepository;
        this.auditLogService = auditLogService;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public UserPin findByUserId(Long userId) {
        log.trace("Starting process to get pin object for user with id {}", userId);

        log.trace("Checking if pin for user with id {} exists", userId);
        UserPin user = getUserPinByUserId(userId);
        log.trace("Pin with id {} found. for user with id {}", user.getId(), userId);

        return user;
    }

    @BasicLog
    @Override
    public UserPin create(UserPin userPin) throws JsonProcessingException, UserPinServiceException {
        log.trace("Starting process on create user pin service with object {}", userPin);

        log.trace("Validate user with id {} ", userPin.getUserId());
        validateUserExists(userPin.getUserId());
        log.trace("User with id {} exists", userPin.getUserId());

        log.trace("Validate if user with id {} has an active pin", userPin.getUserId());
        validateUserHasNoActivePin(userPin.getUserId());
        log.trace("User with id {} has no active pin", userPin.getUserId());

        log.trace("Saving user pin. {}", userPin);
        UserPin createdUserPin = userPinRepository.save(userPin);
        log.trace("User pin saved successfully. {}", createdUserPin);

        auditLogService.createAuditLog(createdUserPin);

        return createdUserPin;
    }

    @BasicLog
    @Override
    public UserPin update(Long userId, String currentPin, UserPin userPinChanges)
        throws JsonProcessingException, UserPinServiceException {
        log.trace("Starting process on update user pin service with object {}", userPinChanges);

        log.trace("Validate if pin with user id exists {} ", userId);
        UserPin userPinToUpdate = getUserPinByUserId(userId);
        log.trace("Pin with user id exists. {}", userPinToUpdate);

        log.trace("Validate current pin matches provided pin {} ", currentPin);
        validateCurrentUserPinMatches(userPinChanges.getUserId(), currentPin);
        log.trace("Privided pin {} matches current pin", currentPin);

        UserPin beforeUpdate = userPinToUpdate.toBuilder().build();

        updateUserPinFields(userPinToUpdate, userPinChanges);

        log.trace("Updating user pin. {}", userPinToUpdate);
        UserPin updatedUserPin = userPinRepository.saveAndFlush(userPinToUpdate);
        log.trace("User pin updated successfully. {}", updatedUserPin);

        auditLogService.updateAuditLog(beforeUpdate, updatedUserPin);

        return updatedUserPin;
    }

    @BasicLog
    @Override
    public void delete(Long userId) throws JsonProcessingException {
        log.trace("Validating if user {} exists", userId);
        UserPin userPin = getUserPinByUserId(userId);
        log.trace("User with id {} found. {}", userId, userPin);

        log.trace("Deleting User pin {}", userPin.getId());
        userPinRepository.delete(userPin);
        log.trace("User pin {} deleted successfully", userId);

        auditLogService.deleteAuditLog(userPin);
    }

    private UserPin getUserPinByUserId(@NotNull Long userId) {
        return userPinRepository.findByUserIdAndDeletedAtIsNull(userId).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("Pin for user with id: %1$s not found", userId)));
    }

    private void validateUserHasNoActivePin(@NotNull Long userId) throws UserPinServiceException {
        boolean userHasPin = userPinRepository.existsByUserIdAndDeletedAtIsNull(userId);
        if (userHasPin) {
            throw new UserPinServiceException(
                String.format("User with id '%1$s' already has an active pin.", userId));
        }
    }

    private void validateUserExists(@NotNull Long userId) throws UserPinServiceException {
        boolean userExists = userRepository.existsById(userId);
        if (!userExists) {
            throw new UserPinServiceException(
                String.format("User with id '%1$s' doesn't exist.", userId));
        }
    }

    private void validateCurrentUserPinMatches(@NotNull Long userId, @NotNull String currentPin)
        throws UserPinServiceException {
        UserPin userPin = getUserPinByUserId(userId);
        if (!userPin.getPin().equals(currentPin)) {
            throw new UserPinServiceException(
                String.format("Provided pin '%1$s' does not match current pin.", currentPin));
        }
    }

    private void updateUserPinFields(@NotNull UserPin userPinToUpdate,
        @NotNull UserPin userPinChanges) {

        userPinToUpdate.setPin(userPinChanges.getPin());
    }
}
