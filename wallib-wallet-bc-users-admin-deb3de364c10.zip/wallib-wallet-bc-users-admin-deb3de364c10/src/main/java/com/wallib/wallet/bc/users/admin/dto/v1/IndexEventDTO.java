package com.wallib.wallet.bc.users.admin.dto.v1;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
@AllArgsConstructor
public class IndexEventDTO implements Serializable {

    private static final long serialVersionUID = 2598511438200009260L;

    @JsonProperty(value = "action")
    private String action;

    @JsonProperty(value = "entity")
    private String entity;

    @JsonProperty(value = "entity_id")
    private Long entityId;

    public IndexEventDTO(Long entityId) {
        this.entityId = entityId;
    }

    public IndexEventDTO() {

    }

}
