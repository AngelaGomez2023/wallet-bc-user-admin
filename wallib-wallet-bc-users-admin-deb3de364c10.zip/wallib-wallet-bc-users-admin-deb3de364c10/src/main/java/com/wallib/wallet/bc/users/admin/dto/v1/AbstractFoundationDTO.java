package com.wallib.wallet.bc.users.admin.dto.v1;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public abstract class AbstractFoundationDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 679265977594925011L;

    private Long id;

    @JsonIgnore
    private transient LocalDateTime createdAt;

    @JsonIgnore
    private transient LocalDateTime updatedAt;

    @JsonIgnore
    private transient LocalDateTime deletedAt;

}
