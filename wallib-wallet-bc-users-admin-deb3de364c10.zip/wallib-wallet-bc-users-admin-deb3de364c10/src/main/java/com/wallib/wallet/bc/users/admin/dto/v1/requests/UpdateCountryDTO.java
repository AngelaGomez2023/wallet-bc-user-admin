package com.wallib.wallet.bc.users.admin.dto.v1.requests;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateCountryDTO implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(example = "Country Name")
    @JsonProperty(value = "name")
    private CountryLanguageDTO name;

    @NotBlank
    @Size(min = 1, max = 2)
    @Schema(example = "CO")
    @JsonProperty(value = "iso_code")
    private String isoCode;

    @NotNull
    @Schema(example = "57")
    @JsonProperty(value = "phone_code")
    private Integer phoneCode;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
