package com.wallib.wallet.bc.users.admin.dto.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.dto.v1.AbstractFoundationDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LanguageDTO extends AbstractFoundationDTO {

    @Serial
    private static final long serialVersionUID = 2181154585445649668L;

    @Schema(example = "new language")
    @JsonProperty(value = "name")
    private String name;

    @Schema(example = "CO")
    @JsonProperty(value = "iso_code")
    private String isoCode;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
