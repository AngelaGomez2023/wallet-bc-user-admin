package com.wallib.wallet.bc.users.admin.security;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
public class JwtAuthorizationFilter extends OncePerRequestFilter {

    private static final String ROLE = "ROLE_";

    private final Environment environment;
    private final ObjectMapper objectMapper;

    public JwtAuthorizationFilter(
        @NotNull final Environment environment,
        ObjectMapper objectMapper) {
        this.environment = environment;
        this.objectMapper = objectMapper;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
        HttpServletResponse response, FilterChain filterChain)
        throws IOException, ServletException {

        if (!existJwtToken(request)) {
            log.trace("Token does not exist. {}",  System.getProperty("java.version"));
            denyRequest(response, "Token does not exist");
            return;
        }

        log.info("Starting authentication process...");

        log.trace("Getting JWT token from request.");
        String jwtToken = request.getHeader(HttpHeaders.AUTHORIZATION)
            .substring(BEARER.length());
        log.trace("Getting JWT token from request: {}", jwtToken);

        try {
            log.trace("Getting claims from JWT");
            Claims claims = getClaims(jwtToken);
            log.trace("Claims obtained successfully");

            if (!isValidClaims(claims)) {
                denyRequest(response, "Claims is not valid");
                return;
            }
            log.trace("Token is valid.");

            log.trace("Authenticating User");
            UsernamePasswordAuthenticationToken auth = authenticateUser(claims);
            auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(auth);
            log.trace("Authenticated user successfully. {}", auth);

        } catch (JwtException e) {
            log.error(e.getMessage(), e);
            denyRequest(response, e.getMessage());
            return;
        }

        filterChain.doFilter(request, response);
        log.info("Authentication process ended successfully.");

    }

    private Claims getClaims(String token) {
        String tokenSecret = environment.getRequiredProperty("jwt.token.secret");
        return Jwts.parser().setSigningKey(tokenSecret.getBytes(StandardCharsets.UTF_8))
            .parseClaimsJws(token).getBody();
    }

    private boolean isValidClaims(Claims claims) {

        log.trace("claims.getAudience(): {}", claims.getAudience());

        if (AUDIENCE_SERVICE.equals(claims.getAudience()) ||
            AUDIENCE_PUBLIC.equals(claims.getAudience())) {
            return isValidAudience(claims);
        } else {
            if (isValidUser(claims) && isValidModules(claims)) {
                return this.isValidAudience(claims);
            }
        }

        return false;
    }

    private boolean isValidAudience(Claims claims) {

        log.trace("Getting system audiences.");
        String tokenAudValues = environment.getRequiredProperty("jwt.token.aud");
        List<String> tokenAudValidValues = Arrays.asList(tokenAudValues.split(","));
        log.trace("Audiences obtained successfully: {}", tokenAudValues);

        log.trace("Getting token audience.");
        String tokenAud = claims.getAudience();
        log.trace("Token audience obtained successfully: {}", tokenAud);

        log.trace("Validating audience");
        if (tokenAud == null || !tokenAudValidValues.contains(tokenAud)) {
            log.trace("Audience no valid ");
            return false;
        }
        log.trace("Valid audience");
        return true;
    }

    private boolean isValidModules(Claims claims) {
        log.trace("Getting system modules.");
        String tokenModValidValue = environment.getRequiredProperty("jwt.token.mod");
        List<String> listMods = Arrays.asList(tokenModValidValue.split(","));
        log.trace("Modules obtained successfully: {}", tokenModValidValue);

        log.trace("Getting token modules.");
        List<String> tokenMods = claims.get("mod", ArrayList.class);
        log.trace("Token modules obtained successfully: {}", tokenMods);

        log.trace("Validating modules");
        if (tokenMods == null || tokenMods.stream().noneMatch(listMods::contains)) {
            log.trace("Modules no valid {}", listMods);
            return false;
        }
        log.trace("Valid modules");
        return true;
    }

    private boolean isValidUser(Claims claims) {
        log.trace("Getting token user.");
        Map<String, Object> user = claims.get("user", Map.class);
        log.trace("User got is: {}", user);
        if (user == null || user.get("user_id") == null) {
            log.trace("User objet no valid");
            return false;
        }
        log.trace("Token user obtained successfully: {}", user);
        return true;
    }

    private boolean existJwtToken(@NotNull final HttpServletRequest request) {
        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        return !(authHeader == null || !authHeader.startsWith(BEARER));
    }

    public UsernamePasswordAuthenticationToken authenticateUser(Claims claims) {
        Set<SimpleGrantedAuthority> grantedValues = getGrantedValues(claims);
        Map<String, Object> tokenUser = claims.get("user", Map.class);

        String userId = "0";
        if (tokenUser != null) {
            userId = tokenUser.get("user_id").toString();
        }

        User user = new com.wallib.wallet.bc.users.admin.security.User(userId, "", "", grantedValues);

        return new UsernamePasswordAuthenticationToken(user, "", grantedValues);
    }

    private static Set<SimpleGrantedAuthority> getGrantedValues(Claims claims) {
        String audience = claims.getAudience();

        log.trace("Audience to granted values: {}", audience);

        Set<SimpleGrantedAuthority> authorities = new HashSet<>();

        switch (audience) {
            case AUDIENCE_SERVICE -> authorities.add(new SimpleGrantedAuthority(
                ROLE + AUDIENCE_SERVICE.toUpperCase(Locale.getDefault())));
            case AUDIENCE_PUBLIC -> authorities.add(new SimpleGrantedAuthority(
                ROLE + PUBLIC.toUpperCase(Locale.getDefault())));
            case AUDIENCE_ADMIN -> {
                log.trace("Getting token permissions.");
                List<String> scopes = claims.get("per", ArrayList.class);
                log.trace("Token permissions obtained successfully: {}", scopes);

                if (scopes != null && !scopes.isEmpty()) {
                    scopes.forEach(
                        x -> authorities.add(
                            new SimpleGrantedAuthority(ROLE + x
                                .toUpperCase(Locale.getDefault()))));
                }
            }
            default -> throw new IllegalStateException("Unexpected value: " + audience);
        }

        log.trace("Authorities granted values: {}", authorities);

        return authorities;
    }

    private void denyRequest(@NotNull final HttpServletResponse response, @NotNull String reason) {
        try (PrintWriter writer = response.getWriter()) {
            ApiResponseDTO<Object> apiResponse = new ApiResponseDTO<>();
            apiResponse.setMessage(UNAUTHORIZED_REQUEST);
            apiResponse.setError(Collections.singletonList(reason));
            apiResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            String dataResponse = objectMapper.writeValueAsString(apiResponse);
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            writer.write(dataResponse);
            writer.flush();
        } catch (IOException e) {
            log.trace("Error while writing response to deny request.");
            log.error(e.getMessage(), e);
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

}
