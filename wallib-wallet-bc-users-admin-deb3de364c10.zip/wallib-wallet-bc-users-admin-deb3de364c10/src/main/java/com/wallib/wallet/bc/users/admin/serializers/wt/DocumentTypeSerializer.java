package com.wallib.wallet.bc.users.admin.serializers.wt;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import java.io.IOException;
import java.io.Serial;

public class DocumentTypeSerializer extends StdSerializer<DocumentType>{
    
    @Serial
    private static final long serialVersionUID = -1151213138603906365L;

    protected DocumentTypeSerializer(Class<DocumentType> t) {
        super(t);
    }

    protected DocumentTypeSerializer() {
        this(null);
    }

    @Override
    public void serialize(DocumentType documentType, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {

        jsonGenerator.writeStartObject();

        jsonGenerator.writeStringField("type", documentType.getType());
        jsonGenerator.writeNumberField("country_id", documentType.getCountryId());
        jsonGenerator.writeNumberField("status", documentType.getStatus());

        jsonGenerator.writeStringField("created_at", documentType.getCreatedAt().toString());
        jsonGenerator.writeStringField("updated_at", documentType.getUpdatedAt().toString());

        if (documentType.getDeletedAt() != null) {
            jsonGenerator.writeStringField("deleted_at", documentType.getDeletedAt().toString());
        } else {
            jsonGenerator.writeNullField("deleted_at");
        }

        jsonGenerator.writeEndObject();

    }
}
