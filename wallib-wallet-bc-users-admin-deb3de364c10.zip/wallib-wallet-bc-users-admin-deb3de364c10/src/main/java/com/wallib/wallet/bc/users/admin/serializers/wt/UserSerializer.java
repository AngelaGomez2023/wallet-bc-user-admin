package com.wallib.wallet.bc.users.admin.serializers.wt;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import java.io.IOException;
import java.io.Serial;

public class UserSerializer extends StdSerializer<User> {

    @Serial
    private static final long serialVersionUID = 1L;

    protected UserSerializer(Class<User> t) {
        super(t);
    }

    protected UserSerializer() {
        this(null);
    }

    @Override
    public void serialize(User user, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {

        jsonGenerator.writeStartObject();

        jsonGenerator.writeNumberField("id", user.getId());
        jsonGenerator.writeStringField("firebase_id", user.getFirebaseId().toString());
        jsonGenerator.writeStringField("nickname", user.getNickname());
        jsonGenerator.writeStringField("firstname", user.getFirstname());
        jsonGenerator.writeStringField("lastname", user.getLastname());
        jsonGenerator.writeStringField("email", user.getEmail());
        jsonGenerator.writeStringField("phone", user.getPhone());
        jsonGenerator.writeStringField("document_id", user.getDocumentId());
        if (user.getDocumentType() != null) {
            jsonGenerator.writeNumberField("document_type", user.getDocumentType());
        }
        if (user.getDocumentDateExpiration() != null) {
            jsonGenerator.writeStringField("document_date_expiration",
                user.getDocumentDateExpiration().toString());
        }
        jsonGenerator.writeStringField("address", user.getAddress());
        jsonGenerator.writeStringField("city", user.getCity());
        jsonGenerator.writeStringField("state", user.getState());
        jsonGenerator.writeNumberField("country_id", user.getCountryId());
        if (user.getLanguageId() != null) {
            jsonGenerator.writeNumberField("language_id", user.getLanguageId());
        }
        jsonGenerator.writeStringField("type", user.getType().toString());
        jsonGenerator.writeNumberField("status", user.getStatus());

        jsonGenerator.writeStringField("created_at", user.getCreatedAt().toString());
        jsonGenerator.writeStringField("updated_at", user.getUpdatedAt().toString());
        if (user.getDeletedAt() != null) {
            jsonGenerator.writeStringField("deleted_at", user.getDeletedAt().toString());
        } else {
            jsonGenerator.writeNullField("deleted_at");
        }

        jsonGenerator.writeEndObject();

    }
}
