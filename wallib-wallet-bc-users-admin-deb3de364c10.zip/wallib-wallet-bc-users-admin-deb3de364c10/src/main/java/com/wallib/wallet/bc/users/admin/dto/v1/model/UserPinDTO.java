package com.wallib.wallet.bc.users.admin.dto.v1.model;

import java.io.Serial;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.dto.v1.AbstractFoundationDTO;
import io.swagger.v3.oas.annotations.media.Schema;

public class UserPinDTO extends AbstractFoundationDTO {
    
    @Serial
    private static final long serialVersionUID = 1L;

    @NotNull
    @Schema(example = "1234")
    @JsonProperty(value = "pin")
    @Size(min = 4, max = 4)
    private String pin;

    @NotNull
    @Schema(example = "123456789")
    @JsonProperty(value = "user_id")
    private Long userId;
}
