package com.wallib.wallet.bc.users.admin.repositories.es;

import com.wallib.wallet.bc.users.admin.documents.FcmRegistrationTokenDocument;
import java.util.Optional;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FcmRegistrationTokenDocumentRepository extends
    ElasticsearchRepository<FcmRegistrationTokenDocument, Long> {

    Optional<FcmRegistrationTokenDocument> findByFirebaseIdAndStatus(Long firebaseId, Integer status);

    void deleteAllByFirebaseIdAndStatus(Long firebaseId, Integer status);

}
