package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateFcmRegistrationTokenDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseFcmRegistrationTokenDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;

@Tag(name = "Firebase Cloud Messaging")
public interface FcmRegistrationTokenControllerDocs {

    @Operation(summary = "Find FCM Registration token by Firebase Id")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Find FCM Registration token by Firebase Id",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ResponseFcmRegistrationTokenDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseFcmRegistrationTokenDTO>> findByFirebaseId(
        @Parameter(
            name = "firebaseId",
            description = "Firebase Id.",
            required = true
        ) Long firebaseId) throws JsonProcessingException, FcmRegistrationTokenException;


    @Operation(summary = "Create FCM Registration token")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "FCM Registration token created successfully",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ResponseFcmRegistrationTokenDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseFcmRegistrationTokenDTO>> save(
        @Parameter(
            name = "createFcmRegistrationTokenDTO",
            description = "FCM Registration token to create.",
            required = true
        ) CreateFcmRegistrationTokenDTO createFcmRegistrationTokenDTO
    ) throws JsonProcessingException, FcmRegistrationTokenException;

}
