package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;

public interface UserPinRedisFacade {
    
    void indexByUserPin(Long userPinId) throws JsonProcessingException, UserPinServiceException;
}
