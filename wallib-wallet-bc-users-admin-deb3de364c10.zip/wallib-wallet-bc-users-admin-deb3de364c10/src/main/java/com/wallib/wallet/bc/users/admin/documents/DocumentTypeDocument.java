package com.wallib.wallet.bc.users.admin.documents;

import java.io.Serial;
import java.io.Serializable;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.DynamicMapping;
import org.springframework.data.elasticsearch.annotations.DynamicMappingValue;
import lombok.AllArgsConstructor;
import javax.persistence.Id;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(indexName = "wallet_document_type")
public class DocumentTypeDocument implements Serializable{
    
    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    private Long id;

    @Field(type = FieldType.Text)
    private String type;

    @Field(type = FieldType.Object)
    @DynamicMapping(DynamicMappingValue.Strict)
    private SimpleField country;

    @Field(type = FieldType.Integer)
    private int status;

    public DocumentTypeDocument(Long id){
        this.id = id;
    }
}
