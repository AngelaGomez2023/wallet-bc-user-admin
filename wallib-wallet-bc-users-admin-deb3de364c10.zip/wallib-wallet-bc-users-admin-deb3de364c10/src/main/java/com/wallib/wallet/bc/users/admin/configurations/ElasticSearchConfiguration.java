package com.wallib.wallet.bc.users.admin.configurations;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.RestClients;
import org.springframework.data.elasticsearch.client.reactive.ReactiveRestClients;
import org.springframework.data.elasticsearch.config.AbstractElasticsearchConfiguration;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;
import org.springframework.http.HttpHeaders;


@Configuration
@EnableElasticsearchRepositories(basePackages = "com.wallib.wallet.bc.users.admin.repositories.es")
@ComponentScan(basePackages = "com.wallib.wallet.bc.users.admin.services")
public class ElasticSearchConfiguration extends AbstractElasticsearchConfiguration {

    @Value("${spring.elasticsearch.uris}")
    private String elasticSearchUri;

    @Value("${spring.elasticsearch.username}")
    private String elasticSearchUsername;

    @Value("${spring.elasticsearch.password}")
    private String elasticSearchPassword;

    @Bean
    public RestHighLevelClient elasticsearchClient() {

        final ClientConfiguration clientConfiguration = ClientConfiguration.builder()
            .connectedTo(elasticSearchUri)
            .usingSsl()
            .withBasicAuth(elasticSearchUsername, elasticSearchPassword)
            .withHeaders(() -> {
                HttpHeaders headers = new HttpHeaders();
                headers.add("currentTime", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                return headers;
            })
            .withClientConfigurer(
                ReactiveRestClients.WebClientConfigurationCallback.from(webClient -> webClient))
            .build();

        return RestClients.create(clientConfiguration).rest();

    }
}

