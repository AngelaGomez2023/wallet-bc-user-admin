package com.wallib.wallet.bc.users.admin.dto.v1.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CountryLanguageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponseLanguageDTO {
    
    @Schema(example = "Id")
    @JsonProperty(value = "id")
    private Long id;

    @Schema(example = "Language Name")
    @JsonProperty(value = "name")
    private CountryLanguageDTO name;

    @Schema(example = "es")
    @JsonProperty(value = "iso_code")
    private String isoCode;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
