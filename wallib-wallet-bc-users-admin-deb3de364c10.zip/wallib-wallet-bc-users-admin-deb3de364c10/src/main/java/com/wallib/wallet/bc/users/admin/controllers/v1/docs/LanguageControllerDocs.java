package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.model.LanguageDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseLanguageDTO;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.WalletUserRestException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.http.ResponseEntity;

@Tag(name = "Languages")
public interface LanguageControllerDocs {
    
    @Operation(summary = "List languages")
    @ApiResponse(
        responseCode = "200",
        description = "List languages",
        content = {
            @Content(mediaType = APPLICATION_JSON_VALUE,
                array = @ArraySchema(
                    schema = @Schema(implementation = LanguageDTO.class)
                )
            )
        }
    )
    ResponseEntity<ApiResponseDTO<List<ResponseLanguageDTO>>> list()
        throws WalletUserRestException, JsonProcessingException;

    @Operation(summary = "Find Language By Id")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Find Language By Id",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LanguageDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseLanguageDTO>> findById(
        @Parameter(
            name = "id",
            description = "Language id to find by.",
            required = true
        ) Long id) throws JsonProcessingException;

    @Operation(summary = "Find Language By Iso Code")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Find Language By Iso Code",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LanguageDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseLanguageDTO>> findByIsoCode(
        @Parameter(
            name = "iso code",
            description = "Language iso code to find by.",
            required = true
        ) String isoCode) throws JsonProcessingException;
    
}
