package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;

public interface FcmRegistrationTokenElasticFacade {

    FcmRegistrationToken findByFirebaseId(Long firebaseId) throws FcmRegistrationTokenException;

    void indexByFcmRegistrationToken(Long id) throws JsonProcessingException,
        FcmRegistrationTokenException;

}
