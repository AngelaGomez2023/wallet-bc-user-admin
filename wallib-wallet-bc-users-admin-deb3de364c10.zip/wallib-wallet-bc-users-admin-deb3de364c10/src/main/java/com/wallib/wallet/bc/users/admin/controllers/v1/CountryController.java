package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_COUNTRY;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_COUNTRY;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_COUNTRY_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_COUNTRY_ISO_CODE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_COUNTRIES;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_COUNTRY;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.CountryControllerDocs;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CountryLanguageDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateCountryDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateCountryDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseCountryDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.facades.CountryFacade;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/v1/countries")
public class CountryController implements CountryControllerDocs {

    private final CountryService countryService;
    private final CountryFacade countryFacade;
    private final ModelMapper modelMapper;
    private final ObjectMapper objectMapper;

    public CountryController(
        CountryService countryService, CountryFacade countryFacade, ModelMapper modelMapper, ObjectMapper objectMapper) {
        this.countryService = countryService;
        this.countryFacade = countryFacade;
        this.modelMapper = modelMapper;
        this.objectMapper = objectMapper;
    }

    @BasicLog
    @Override
    @GetMapping(value = "", produces = APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + LIST_COUNTRIES + "')")
    public ResponseEntity<ApiResponseDTO<List<ResponseCountryDTO>>> list()
        throws JsonProcessingException {
        List<Country> countries = countryService.list();

        log.trace("Generating DTO from countries. {}", countries);

        List<ResponseCountryDTO> countryDTOList = new ArrayList<>();

        for (Country country : countries) {
            countryDTOList.add(getMappedResponseCountry(country));
        }

        log.trace("List of CountryDTOs generated successfully. {}", countryDTOList);

        return ResponseEntity.ok(ApiResponseDTO.<List<ResponseCountryDTO>>builder()
            .statusCode(HttpStatus.OK.value())
            .message("Countries retrieved successfully")
            .body(countryDTOList)
            .build());
    }

    @BasicLog
    @GetMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_COUNTRY_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> findById(
        @PathVariable Long id
    )
        throws JsonProcessingException {

        log.trace("Request received on country controller with id {}", id);

        Country country = countryService.findById(id);

        log.trace("Generating country DTO from get country. {}", country);
        ResponseCountryDTO getMappedCountry = generateCountryDTOFromCountry(country);
        log.trace("ResponseCountryDTO generated successfully in findById method. {}", getMappedCountry);

        log.trace("Creating ApiResponse from countryController [FINDBYID]");
        ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseCountryDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("Country retrieved successfully")
                .body(getMappedCountry)
                .build());
        log.trace("Api response created from get country successfully {}", response);

        return response;
    }

    @BasicLog
    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE, params = {"iso_code"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_COUNTRY_ISO_CODE + "')")
    public ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> findByIsoCode(
        @RequestParam(name = "iso_code") String isoCode
    )
        throws JsonProcessingException {

        log.trace("Request received on country controller with iso code {}", isoCode);

        Country country = countryService.findByIsoCode(isoCode);

        log.trace("Generating country DTO from get country. {}", country);
        ResponseCountryDTO getMappedCountry = generateCountryDTOFromCountry(country);
        log.trace("ResponseCountryDTO generated successfully in findById method. {}", getMappedCountry);

        log.trace("Creating ApiResponse from countryController [FINDBYISOCODE]");
        ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseCountryDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("Country retrieved successfully")
                .body(getMappedCountry)
                .build());
        log.trace("Api response created from get country by iso code successfully {}", response);

        return response;
    }

    @BasicLog
    @PostMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + CREATE_COUNTRY + "')")
    public ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> create(
        @Valid @RequestBody CreateCountryDTO createCountryDTO)
        throws JsonProcessingException, CountryServiceException {

        log.trace("Request received on country controller with body {}", createCountryDTO);

        log.trace("Generating country object");
        Country countryObject = generateCountryFromCreateCountryDTO(createCountryDTO);
        log.trace("Country generated successfully {}", countryObject);

        Country createdCountry = countryFacade.create(countryObject);

        log.trace("Generating country DTO from created hall. {}", createdCountry);
        ResponseCountryDTO mappedCountry = generateCountryDTOFromCountry(createdCountry);
        log.trace("ResponseCountryDTO generated successfully in create method. {}", mappedCountry);

        log.trace("Creating ApiResponse from countryController [CREATE]");
        ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> response = ResponseEntity
            .status(HttpStatus.CREATED)
            .body(ApiResponseDTO.<ResponseCountryDTO>builder()
                .statusCode(HttpStatus.CREATED.value())
                .message("Country created successfully")
                .body(mappedCountry)
                .build());
        log.trace("Api response created from create country successfully {}", response);

        return response;
    }

    @BasicLog
    @PutMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + UPDATE_COUNTRY + "')")
    public ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> update(
        @PathVariable Long id,
        @Valid @RequestBody UpdateCountryDTO updateCountryDTO
    )
        throws JsonProcessingException, CountryServiceException {

        log.trace("Request received on country controller with body {}", updateCountryDTO);

        log.trace("Generating country update object");
        Country countryObject = generateCountryFromUpdateCountryDTO(updateCountryDTO);
        log.trace("Country update generated successfully {}", countryObject);

        Country updatedCountry = countryFacade.update(id, countryObject);

        log.trace("Generating country DTO from updated hall. {}", updatedCountry);
        ResponseCountryDTO mappedCountry = generateCountryDTOFromCountry(updatedCountry);
        log.trace("ResponseCountryDTO generated successfully in update method. {}", mappedCountry);

        log.trace("Creating ApiResponse from countryController [UPDATE].");
        ResponseEntity<ApiResponseDTO<ResponseCountryDTO>> response = ResponseEntity
            .status(HttpStatus.ACCEPTED)
            .body(ApiResponseDTO.<ResponseCountryDTO>builder()
                .statusCode(HttpStatus.ACCEPTED.value())
                .message("Country updated successfully")
                .body(mappedCountry)
                .build());
        log.trace("Api response updated from update country successfully {}", response);

        return response;
    }

    @BasicLog
    @DeleteMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + DELETE_COUNTRY + "')")
    public ResponseEntity<ApiResponseDTO<String>> delete(@PathVariable Long id)
        throws CountryServiceException, JsonProcessingException {

        log.trace("Request received to delete country by id {}", id);
        countryFacade.delete(id);
        log.trace("Country with id {} successfully removed", id);

        log.trace("Creating ApiResponse from countryController [DELETE]");

        return ResponseEntity.status(HttpStatus.NO_CONTENT)
            .body(ApiResponseDTO.<String>builder()
                .statusCode(HttpStatus.NO_CONTENT.value())
                .message("Country deleted successfully")
                .build());

    }

    private Country generateCountryFromCreateCountryDTO(
        @NotNull CreateCountryDTO createCountryDTO) throws JsonProcessingException {
        String countryLanguage = objectMapper.writeValueAsString(createCountryDTO.getName());
        return Country.builder()
            .name(countryLanguage)
            .status(createCountryDTO.getStatus())
            .phoneCode(createCountryDTO.getPhoneCode())
            .isoCode(createCountryDTO.getIsoCode())
            .build();
    }

    private Country generateCountryFromUpdateCountryDTO(
        @NotNull UpdateCountryDTO updateCountryDTO) throws JsonProcessingException {
        String countryLanguage = objectMapper.writeValueAsString(updateCountryDTO.getName());
        return Country.builder()
            .name(countryLanguage)
            .status(updateCountryDTO.getStatus())
            .phoneCode(updateCountryDTO.getPhoneCode())
            .isoCode(updateCountryDTO.getIsoCode())
            .build();
    }

    private ResponseCountryDTO generateCountryDTOFromCountry(Country country)
        throws JsonProcessingException {
        log.trace("generateCountryDTOFromCountry ResponseCountryDTO: {}", country.getName());
        ResponseCountryDTO mappedCountry = modelMapper.map(country, ResponseCountryDTO.class);
        mappedCountry.setName(objectMapper.readValue(country.getName(), CountryLanguageDTO.class));

        log.trace("mappedCountry: {}", mappedCountry);
        return mappedCountry;
    }

    private ResponseCountryDTO getMappedResponseCountry(Country country)
        throws JsonProcessingException {
        ResponseCountryDTO mappedCountry = modelMapper.map(country, ResponseCountryDTO.class);
        mappedCountry.setName(objectMapper.readValue(country.getName(), CountryLanguageDTO.class));

        return mappedCountry;
    }
}