package com.wallib.wallet.bc.users.admin.configurations;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AmazonS3Config {

    @Value("${aws.s3.region}")
    private String awsRegion;

    @Value("${aws.s3.access.key.id}")
    private String awsKey;

    @Value("${aws.s3.secret.key.id}")
    private String awsSecret;

    @Bean
    public AmazonS3 amazonS3Client() {
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(awsKey, awsSecret);
        return AmazonS3ClientBuilder
            .standard()
            .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
            .withRegion(getRegion(awsRegion))
            .build();
    }

    private Regions getRegion(String region) {

        switch (region) {
            case "us-east-1" -> {
                return Regions.US_EAST_1;
            }
            case "us-east-2" -> {
                return Regions.US_EAST_2;
            }
            case "us-west-1" -> {
                return Regions.US_WEST_1;
            }
            case "us-west-2" -> {
                return Regions.US_WEST_2;
            }
            default -> {
                return Regions.US_ISO_EAST_1;
            }
        }
    }

}

