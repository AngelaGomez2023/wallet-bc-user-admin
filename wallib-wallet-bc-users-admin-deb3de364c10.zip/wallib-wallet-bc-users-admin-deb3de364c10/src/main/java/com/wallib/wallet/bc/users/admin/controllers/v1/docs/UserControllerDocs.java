package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.model.UserDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.pageable.PageResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateUserDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseUserDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Tag(name = "Users")
public interface UserControllerDocs {

	@Operation(summary = "List users by country")
	@ApiResponses(value = {
		@ApiResponse(
			responseCode = "200",
			description = "Users listed",
			content = {
				@Content(mediaType = APPLICATION_JSON_VALUE,
					array = @ArraySchema(
						schema = @Schema(implementation = ResponseUserDTO.class)
					)
				)
			}
		)
	})
	ResponseEntity<ApiResponseDTO<PageResponseDTO<ResponseUserDTO>>> list(
		@Parameter(name = "country_id", description = "Country ID to filter users") Long countryId,
		@Parameter(name = "filter", description = "String to filter by users firstname.") String filter,
		@Parameter(name = "page", description = "Page to get data, starting with 0. "
			+ "Omit wit size to get all data.") Integer page,
		@Parameter(name = "size",
			description = "Page size to get data. Omit with page to get all data.") Integer size,
		@Parameter(name = "sort", description = "Criteria to sort users. All options support asc or"
			+ " desc order: firstname,asc") Sort sort
	);

	@Operation(summary = "Find User By Id")
	@ApiResponses(value = {
		@ApiResponse(
			responseCode = "200",
			description = "Find User By Id",
			content = {
				@Content(mediaType = APPLICATION_JSON_VALUE,
					schema = @Schema(implementation = UserDTO.class))
			}
		)
	})
	ResponseEntity<ApiResponseDTO<ResponseUserDTO>> findById(
		@Parameter(
			name = "id",
			description = "User id to find by.",
			required = true
		) Long id) throws JsonProcessingException;

	@Operation(summary = "Find User By Firebase Id")
	@ApiResponses(value = {
		@ApiResponse(
			responseCode = "200",
			description = "Find User By Firebase Id",
			content = {
				@Content(mediaType = APPLICATION_JSON_VALUE,
					schema = @Schema(implementation = UserDTO.class))
			}
		)
	})
	ResponseEntity<ApiResponseDTO<ResponseUserDTO>> findByFirebaseId(
		@Parameter(
			name = "firebase_id",
			description = "User firebsae id to find by.",
			required = true
		) String firebaseId) throws JsonProcessingException;

	@Operation(summary = "Create User")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "User created successfully", content = {
		@Content(
			mediaType = APPLICATION_JSON_VALUE, 
			schema = @Schema(implementation = UserDTO.class
		)) 
	})})
	ResponseEntity<ApiResponseDTO<ResponseUserDTO>> create(
		@Parameter(
			name = "user", 
			description = "User to create.", 
			required = true
		) 
		CreateUserDTO createUserDTO)
		throws JsonProcessingException, UserServiceException;

	@Operation(summary = "Update a user",
		description = "Allows to update a user only if user id exists.")
	@ApiResponse(
		responseCode = "202",
		description = "User updated successfully.",
		content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
				schema = @Schema(implementation = CreateUserDTO.class))
		}
	)
	ResponseEntity<ApiResponseDTO<ResponseUserDTO>> update(
		@Parameter(
			name = "id",
			description = "User Id to be updated.",
			required = true
		) Long id,
		@Parameter(
			name = "User",
			description = "User to update.",
			required = true
		) UpdateUserDTO updateUserDTO
	) throws JsonProcessingException, UserServiceException;

	@Operation(summary = "Delete a user",
		description = "Allows to delete a user only if user has no relations with other data.")
	@ApiResponse(
		responseCode = "200",
		description = "User deleted successfully.",
		content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
				schema = @Schema(implementation = ApiResponseDTO.class))
		}
	)
	ResponseEntity<ApiResponseDTO<String>> delete(
		@Parameter(
			name = "id",
			description = "User to delete.",
			required = true
		) Long id
	) throws JsonProcessingException, UserServiceException;
}
