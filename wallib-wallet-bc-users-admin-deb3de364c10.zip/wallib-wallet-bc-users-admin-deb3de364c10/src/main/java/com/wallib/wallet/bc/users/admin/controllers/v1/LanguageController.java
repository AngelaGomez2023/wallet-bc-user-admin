package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_LANGUAGE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_LANGUAGE_ISO_CODE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_LANGUAGES;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.LanguageControllerDocs;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CountryLanguageDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseLanguageDTO;
import com.wallib.wallet.bc.users.admin.models.wt.Language;
import com.wallib.wallet.bc.users.admin.services.LanguageService;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/v1/languages")
public class LanguageController implements LanguageControllerDocs {

    private final LanguageService languageService;
    private final ModelMapper modelMapper;
    private final ObjectMapper objectMapper;

    public LanguageController(
        LanguageService languageService, ModelMapper modelMapper, ObjectMapper objectMapper) {
        this.languageService = languageService;
        this.modelMapper = modelMapper;
        this.objectMapper = objectMapper;
    }

    @BasicLog
    @Override
    @GetMapping(value = "", produces = APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + LIST_LANGUAGES + "')")
    public ResponseEntity<ApiResponseDTO<List<ResponseLanguageDTO>>> list()
        throws JsonProcessingException {
        List<Language> countries = languageService.list();

        log.trace("Generating DTO from countries. {}", countries);

        List<ResponseLanguageDTO> languageDTOList = new ArrayList<>();

        for (Language language : countries) {
            languageDTOList.add(getMappedResponseLanguage(language));
        }

        log.trace("List of LanguageDTOs generated successfully. {}", languageDTOList);

        return ResponseEntity.ok(ApiResponseDTO.<List<ResponseLanguageDTO>>builder()
            .statusCode(HttpStatus.OK.value())
            .message("Countries retrieved successfully")
            .body(languageDTOList)
            .build());
    }

    @BasicLog
    @GetMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_LANGUAGE_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseLanguageDTO>> findById(
        @PathVariable Long id
    )
        throws JsonProcessingException {

        log.trace("Request received on language controller with id {}", id);

        Language language = languageService.findById(id);

        log.trace("Generating language DTO from get language. {}", language);
        ResponseLanguageDTO getMappedLanguage = generateLanguageDTOFromLanguage(language);
        log.trace("ResponseLanguageDTO generated successfully in findById method. {}", getMappedLanguage);

        log.trace("Creating ApiResponse from languageController [FINDBYID]");
        ResponseEntity<ApiResponseDTO<ResponseLanguageDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseLanguageDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("Language retrieved successfully")
                .body(getMappedLanguage)
                .build());
        log.trace("Api response created from get language successfully {}", response);

        return response;
    }

    @BasicLog
    @GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE, params = {"iso_code"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_BY_LANGUAGE_ISO_CODE + "')")
    public ResponseEntity<ApiResponseDTO<ResponseLanguageDTO>> findByIsoCode(
        @RequestParam(name = "iso_code") String isoCode
    )
        throws JsonProcessingException {

        log.trace("Request received on language controller with iso code {}", isoCode);

        Language language = languageService.findByIsoCode(isoCode);

        log.trace("Generating language DTO from get language. {}", language);
        ResponseLanguageDTO getMappedLanguage = generateLanguageDTOFromLanguage(language);
        log.trace("ResponseLanguageDTO generated successfully in findById method. {}", getMappedLanguage);

        log.trace("Creating ApiResponse from languageController [FINDBYISOCODE]");
        ResponseEntity<ApiResponseDTO<ResponseLanguageDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseLanguageDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("Language retrieved successfully")
                .body(getMappedLanguage)
                .build());
        log.trace("Api response created from get language by iso code successfully {}", response);

        return response;
    }

    private ResponseLanguageDTO generateLanguageDTOFromLanguage(Language language)
        throws JsonProcessingException {
        log.trace("generateLanguageDTOFromLanguage ResponseLanguageDTO: {}", language.getName());
        ResponseLanguageDTO mappedLanguage = modelMapper.map(language, ResponseLanguageDTO.class);
        mappedLanguage.setName(objectMapper.readValue(language.getName(), CountryLanguageDTO.class));

        log.trace("mappedLanguage: {}", mappedLanguage);
        return mappedLanguage;
    }

    private ResponseLanguageDTO getMappedResponseLanguage(Language language)
        throws JsonProcessingException {
        ResponseLanguageDTO mappedLanguage = modelMapper.map(language, ResponseLanguageDTO.class);
        mappedLanguage.setName(objectMapper.readValue(language.getName(), CountryLanguageDTO.class));

        return mappedLanguage;
    }
}