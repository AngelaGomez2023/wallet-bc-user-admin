package com.wallib.wallet.bc.users.admin.facades.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DOCUMENT_TYPE_ENTITY;

import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.facades.DocumentTypeFacade;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;
import com.wallib.wallet.bc.users.admin.services.EventService;
import org.springframework.stereotype.Component;

@Component
public class DocumentTypeFacadeImpl implements DocumentTypeFacade{

    private final DocumentTypeService documentTypeService;
    private final EventService eventService;

    public DocumentTypeFacadeImpl(DocumentTypeService documentTypeService,
        EventService eventService){
        this.documentTypeService = documentTypeService;
        this.eventService = eventService;
    }
    
    @BasicLog
    @Override
    public DocumentType create(@NotNull final DocumentType createDocumentType)
        throws DocumentTypeServiceException, JsonProcessingException{
        DocumentType documentType = documentTypeService.create(createDocumentType);
        eventService.sendEventToQueue(EVENT_INSERT, DOCUMENT_TYPE_ENTITY, documentType.getId());
        return documentType;
    }

    @BasicLog
    @Override
    public DocumentType update(@NotNull final Long id,
        @NotNull final DocumentType updateDocumentType)
        throws DocumentTypeServiceException, JsonProcessingException{
        DocumentType documentType = documentTypeService.update(id, updateDocumentType);
        eventService.sendEventToQueue(EVENT_UPDATE, DOCUMENT_TYPE_ENTITY, documentType.getId());
        return documentType;
    }

    @BasicLog
    @Override
    public void delete(@NotNull final Long id)
        throws DocumentTypeServiceException, JsonProcessingException{
        documentTypeService.delete(id);
        eventService.sendEventToQueue(EVENT_DELETE, DOCUMENT_TYPE_ENTITY, id);
    }
}
