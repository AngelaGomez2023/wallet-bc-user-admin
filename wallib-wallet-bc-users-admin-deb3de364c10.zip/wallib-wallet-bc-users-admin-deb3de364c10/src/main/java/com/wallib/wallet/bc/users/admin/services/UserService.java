package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {

    Page<User> list(Long countryId, String filter, Pageable pageable);

    User findById(Long id) throws JsonProcessingException;

    User findByFirebaseId(String firebaseId) throws JsonProcessingException;

    User findByNickname(String nickname) throws JsonProcessingException;

    User create(User user) throws JsonProcessingException, UserServiceException;

    User update(Long id, User user)
        throws JsonProcessingException, UserServiceException;

    void delete(Long id) throws JsonProcessingException;

    Integer countByCountryIdAndDeletedAtIsNull(Long countryId, String filter);
}
