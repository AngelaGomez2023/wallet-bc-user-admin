package com.wallib.wallet.bc.users.admin.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.repositories.es.FcmRegistrationTokenDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.FcmRegistrationTokenRepository;
import com.wallib.wallet.bc.users.admin.services.AuditLogService;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenService;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class FcmRegistrationTokenServiceImpl implements FcmRegistrationTokenService {

    private final FcmRegistrationTokenRepository fcmRegistrationTokenRepository;
    private final FcmRegistrationTokenDocumentRepository fcmRegistrationTokenDocumentRepository;
    private final AuditLogService auditLogService;

    public FcmRegistrationTokenServiceImpl(
        FcmRegistrationTokenRepository fcmRegistrationTokenRepository,
        FcmRegistrationTokenDocumentRepository fcmRegistrationTokenDocumentRepository,
        AuditLogService auditLogService) {
        this.fcmRegistrationTokenRepository = fcmRegistrationTokenRepository;
        this.fcmRegistrationTokenDocumentRepository = fcmRegistrationTokenDocumentRepository;
        this.auditLogService = auditLogService;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public FcmRegistrationToken findById(Long id) {
        log.trace("Starting process to get FcmRegistrationToken object {}", id);

        log.trace("Checking if FCM registration token with id {} exists", id);
        FcmRegistrationToken fcmRegistrationToken = getFcmRegistrationTokenById(id);
        log.trace("FCM registration token with id {} found. {}", fcmRegistrationToken.getId(), id);

        return fcmRegistrationToken;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public FcmRegistrationToken findByFirebaseId(Long firebaseId) {
        log.trace("Starting process to get FCM registration token with firebase id {}", firebaseId);

        log.trace("Checking if FCM registration token with firebase id {} exists", firebaseId);
        FcmRegistrationToken fcmRegistrationToken = getFcmRegistrationTokenByFirebaseId(firebaseId);
        log.trace("FCM registration token with firebase id {} found. {}", 
            fcmRegistrationToken.getId(), firebaseId);

        return fcmRegistrationToken;
    }

    @BasicLog
    @Override
    public FcmRegistrationToken save(FcmRegistrationToken fcmRegistrationToken)
        throws JsonProcessingException, FcmRegistrationTokenException {
        log.trace("Starting process on create fcm registration token with object {}",
            fcmRegistrationToken);

        log.trace("Verify FCM registration token.");
        Boolean verifyToken = fcmRegistrationTokenRepository.existsByTokenAndFirebaseIdAndStatusAndDeletedAtIsNull(
            fcmRegistrationToken.getToken(), fcmRegistrationToken.getFirebaseId(), 1);
        log.trace("Token verify: {}.", verifyToken);

        if (Boolean.FALSE.equals(verifyToken)) {

            updateAndDeleteFcmTokens(fcmRegistrationToken.getFirebaseId());

            log.info("Saving FCM registration token. {}", fcmRegistrationToken);
            FcmRegistrationToken createdFcmRegistrationToken = fcmRegistrationTokenRepository.save(
                fcmRegistrationToken);
            log.info("FCM registration token saved successfully. {}", createdFcmRegistrationToken);

            auditLogService.createAuditLog(createdFcmRegistrationToken);

            return createdFcmRegistrationToken;

        } else {
            throw new FcmRegistrationTokenException("FCM registration token was already saved.");
        }
    }

    private void updateAndDeleteFcmTokens(Long firebaseId) {

        log.trace("Update status to zero if exists other tokens to this firebase account.");
        fcmRegistrationTokenRepository.updateStatusByFirebaseIdAndDeletedAtIsNull(
            firebaseId);
        log.trace("Status updated to zero.");

        log.trace("Remove index if exists other tokens to this firebase account.");
        fcmRegistrationTokenDocumentRepository.deleteAllByFirebaseIdAndStatus(
            firebaseId, 1);
        log.trace("FCM removed.");

    }

    private FcmRegistrationToken getFcmRegistrationTokenById(@NotNull Long id) {
        return fcmRegistrationTokenRepository.findById(id).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("FCM registration token with id: %1$s not found", id)));
    }

    private FcmRegistrationToken getFcmRegistrationTokenByFirebaseId(@NotNull Long firebaseId) {
        return fcmRegistrationTokenRepository.findByFirebaseIdAndStatusAndDeletedAtIsNull(
            firebaseId, 1).orElseThrow(() -> new EntityNotFoundException(String
                .format("FCM registration token with firebase id: %1$s not found", firebaseId)));
    }
}
