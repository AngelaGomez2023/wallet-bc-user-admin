package com.wallib.wallet.bc.users.admin.consumers;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.USER_ENTITY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserElasticFacade;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserMessageConsumer {

    private final UserElasticFacade userElasticFacade;

    @Value("${activemq.wallet.bc.users.admin.queue}")
    private String sourceQueue;

    public UserMessageConsumer(@NotNull final UserElasticFacade userElasticFacade) {
        this.userElasticFacade = userElasticFacade;
    }

    @BasicLog
    @JmsListener(destination = "${activemq.wallet.bc.users.admin.queue}",
        selector = "(action = '" + EVENT_INSERT 
                + "' OR action = '" + EVENT_UPDATE 
                + "' OR action = '" + EVENT_DELETE 
                + "') AND entity = '" + USER_ENTITY + "'")
    public void receiveUserMessage(@Payload @NotNull IndexEventDTO indexEvent)
        throws JsonProcessingException, UserServiceException {
        try {
            log.info("User: message received from the ActiveMQ queue {} to create/update index. {}",
                sourceQueue, indexEvent);
            userElasticFacade.indexByUser(indexEvent.getEntityId());
        } catch (EntityNotFoundException ex) {
            log.error(ex.getMessage());
            throw ex;
        } catch (RuntimeException | JsonProcessingException ex) {
            log.error("Document not indexed by User, object has errors: " + ex.getMessage(), ex);
            throw ex;
        } catch (UserServiceException ex) {
            log.error(ex.getMessage());
            throw new UserServiceException(ex.getMessage());
        }
    }

}
