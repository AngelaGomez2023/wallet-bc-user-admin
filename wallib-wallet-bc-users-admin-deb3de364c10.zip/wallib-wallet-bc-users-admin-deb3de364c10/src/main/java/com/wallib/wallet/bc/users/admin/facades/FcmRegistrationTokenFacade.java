package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;

public interface FcmRegistrationTokenFacade {

    FcmRegistrationToken save(FcmRegistrationToken createFcmRegistrationToken)
        throws JsonProcessingException, FcmRegistrationTokenException;

}
