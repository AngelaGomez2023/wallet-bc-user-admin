package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import javax.validation.constraints.NotNull;

public interface AuditLogService {

    void createAuditLog(@NotNull AbstractFoundationEntity entity) throws JsonProcessingException;

    void updateAuditLog(@NotNull AbstractFoundationEntity oldEntity, @NotNull AbstractFoundationEntity newEntity)
            throws JsonProcessingException;

    void deleteAuditLog(@NotNull AbstractFoundationEntity entity) throws JsonProcessingException;

}
