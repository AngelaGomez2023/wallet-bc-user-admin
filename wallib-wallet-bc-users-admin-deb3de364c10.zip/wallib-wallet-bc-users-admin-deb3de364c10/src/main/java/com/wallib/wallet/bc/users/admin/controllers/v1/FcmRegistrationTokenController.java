package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_FCM_BY_FIREBASE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.SAVE_FCM_TOKEN;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.FcmRegistrationTokenControllerDocs;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateFcmRegistrationTokenDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseFcmRegistrationTokenDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenElasticFacade;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenFacade;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/v1/fcm")
public class FcmRegistrationTokenController implements FcmRegistrationTokenControllerDocs {

    private final FcmRegistrationTokenFacade fcmRegistrationTokenFacade;
    private final FcmRegistrationTokenElasticFacade fcmRegistrationTokenElasticFacade;
    private final ModelMapper modelMapper;

    public FcmRegistrationTokenController(FcmRegistrationTokenFacade fcmRegistrationTokenFacade,
        FcmRegistrationTokenElasticFacade fcmRegistrationTokenElasticFacade, ModelMapper modelMapper) {
        this.fcmRegistrationTokenFacade = fcmRegistrationTokenFacade;
        this.fcmRegistrationTokenElasticFacade = fcmRegistrationTokenElasticFacade;
        this.modelMapper = modelMapper;
    }

    @BasicLog
    @Override
    @GetMapping(value = "{firebaseId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + FIND_FCM_BY_FIREBASE_ID + "')")
    public ResponseEntity<ApiResponseDTO<ResponseFcmRegistrationTokenDTO>> findByFirebaseId(
        @PathVariable Long firebaseId
    )
        throws JsonProcessingException, FcmRegistrationTokenException {

        log.trace("Request received on FCM registration token controller with firebaseId {}", firebaseId);

        FcmRegistrationToken fcmRegistrationToken = fcmRegistrationTokenElasticFacade.
            findByFirebaseId(firebaseId);

        log.trace("Generating ResponseFcmRegistrationTokenDTO from find by firebase id. {}",
            fcmRegistrationToken);
        ResponseFcmRegistrationTokenDTO mappedFcmRegistrationToken =
            generateResponseFcmRegistrationTokenDTOFromFcmRegistrationToken(fcmRegistrationToken);
        log.trace("ResponseFcmRegistrationTokenDTO generated successfully. {}",
            mappedFcmRegistrationToken);

        log.trace("Creating ApiResponse from countryController [FIND BY FIREBASE ID]");
        ResponseEntity<ApiResponseDTO<ResponseFcmRegistrationTokenDTO>> response = ResponseEntity
            .status(HttpStatus.OK)
            .body(ApiResponseDTO.<ResponseFcmRegistrationTokenDTO>builder()
                .statusCode(HttpStatus.OK.value())
                .message("FCM registration token retrieved successfully")
                .body(mappedFcmRegistrationToken)
                .build());
        log.trace("Api response created from find FCM registration token successfully {}", response);

        return response;
    }

    @Override
    @BasicLog
    @PostMapping(value = "", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + SAVE_FCM_TOKEN + "')")
    public ResponseEntity<ApiResponseDTO<ResponseFcmRegistrationTokenDTO>> save(
        @Valid @RequestBody CreateFcmRegistrationTokenDTO createFcmRegistrationTokenDTO)
        throws JsonProcessingException, FcmRegistrationTokenException {

        log.trace("Request received on create FCM registration controller with body {}",
            createFcmRegistrationTokenDTO);

        log.trace("Generating FCM registration token object");
        FcmRegistrationToken fcmRegistrationToken = generateFcmRegistrationTokenFromCreateFcmRegistrationTokenDTO(
            createFcmRegistrationTokenDTO);
        log.trace("FCM registration token generated successfully {}", fcmRegistrationToken);

        FcmRegistrationToken createFcmRegistrationToken = fcmRegistrationTokenFacade.save(
            fcmRegistrationToken);

        log.trace("Generating FcmRegistrationTokenDTO from save. {}", createFcmRegistrationToken);
        ResponseFcmRegistrationTokenDTO mappedResponseFcmRegistrationTokenDTO =
            generateResponseFcmRegistrationTokenDTOFromFcmRegistrationToken(
                createFcmRegistrationToken);
        log.trace("ResponseFcmRegistrationTokenDTO generated successfully in update method. {}",
            mappedResponseFcmRegistrationTokenDTO);

        log.trace("Creating ApiResponse from userController to create FCM registration token.");
        ResponseEntity<ApiResponseDTO<ResponseFcmRegistrationTokenDTO>> response = ResponseEntity.status(
            HttpStatus.CREATED).body(ApiResponseDTO.<ResponseFcmRegistrationTokenDTO>builder()
            .statusCode(HttpStatus.CREATED.value())
            .message("FCM registration token saved successfully")
            .body(mappedResponseFcmRegistrationTokenDTO).build());
        log.trace("Api response to FCM registration token saved successfully {}", response);

        return response;
    }

    private ResponseFcmRegistrationTokenDTO generateResponseFcmRegistrationTokenDTOFromFcmRegistrationToken(
        FcmRegistrationToken fcmRegistrationToken) {
        log.trace("Mapping FcmRegistrationToken {}", fcmRegistrationToken);
        ResponseFcmRegistrationTokenDTO mappedResponseFcmRegistrationTokenDTO =
            ResponseFcmRegistrationTokenDTO.builder()
            .id(fcmRegistrationToken.getId())
            .firebaseId(fcmRegistrationToken.getFirebaseId())
            .token(fcmRegistrationToken.getToken())
            .platform(fcmRegistrationToken.getPlatform())
            .status(fcmRegistrationToken.getStatus())
            .build();

        log.trace("Map ResponseFcmRegistrationTokenDTO {}", mappedResponseFcmRegistrationTokenDTO);
        return mappedResponseFcmRegistrationTokenDTO;

    }

    private FcmRegistrationToken generateFcmRegistrationTokenFromCreateFcmRegistrationTokenDTO(
        CreateFcmRegistrationTokenDTO createFcmRegistrationTokenDTO) {
        FcmRegistrationToken mappedFcmRegistrationToken = modelMapper.map(
            createFcmRegistrationTokenDTO, FcmRegistrationToken.class);
        log.trace("Map FcmRegistrationToken {}", mappedFcmRegistrationToken);
        return mappedFcmRegistrationToken;
    }

}
