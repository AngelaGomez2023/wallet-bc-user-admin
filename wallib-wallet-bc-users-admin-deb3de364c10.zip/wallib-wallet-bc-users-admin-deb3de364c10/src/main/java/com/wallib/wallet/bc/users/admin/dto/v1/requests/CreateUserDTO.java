package com.wallib.wallet.bc.users.admin.dto.v1.requests;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateUserDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = -2856539471681067654L;

    @NotNull
    @Schema(example = "1")
    @JsonProperty(value = "firebase_id")
    private Long firebaseId;

    @NotBlank
    @NotNull
    @Schema(example = "nickname")
    @JsonProperty(value = "nickname")
    private String nickname;

    @NotBlank
    @NotNull
    @Schema(example = "name")
    @JsonProperty(value = "firstname")
    private String firstname;

    @NotBlank
    @NotNull
    @Schema(example = "lastname")
    @JsonProperty(value = "lastname")
    private String lastname;

    @NotBlank
    @NotNull
    @Schema(example = "email@example.com")
    @JsonProperty(value = "email")
    private String email;

    @Schema(example = "123456789")
    @JsonProperty(value = "phone")
    private String phone;

    @Schema(example = "1")
    @JsonProperty(value = "document_id")
    private String documentId;

    @Schema(example = "1")
    @JsonProperty(value = "document_type")
    private Integer documentType;

    @Schema(example = "2017-01-13T17:09:42.411")
    @JsonProperty(value = "document_date_expiration")
    private LocalDate documentDateExpiration;

    @Schema(example = "Baker St.")
    @JsonProperty(value = "address")
    private String address;

    @Schema(example = "BOG")
    @JsonProperty(value = "city")
    private String city;

    @Schema(example = "CUN")
    @JsonProperty(value = "state")
    private String state;

    @NotNull
    @Schema(example = "1")
    @JsonProperty(value = "country_id")
    private Long countryId;

    @Schema(example = "1")
    @JsonProperty(value = "language_id")
    private Long languageId;

    @NotNull
    @Schema(example = "user")
    @JsonProperty(value = "type")
    private UserTypeEnum type;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;

}
