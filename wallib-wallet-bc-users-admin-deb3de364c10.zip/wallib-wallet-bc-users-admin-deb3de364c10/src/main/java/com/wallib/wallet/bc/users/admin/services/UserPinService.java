package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;

public interface UserPinService {
    
    UserPin findByUserId(Long userId) throws JsonProcessingException;

    UserPin create(UserPin user) throws JsonProcessingException, UserPinServiceException;

    UserPin update(Long id, String currentPin, UserPin userPin)
        throws JsonProcessingException, UserPinServiceException;

    void delete(Long id) throws JsonProcessingException;
}
