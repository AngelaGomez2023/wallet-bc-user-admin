package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.UserPinRedisService;
import org.springframework.data.redis.core.ValueOperations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UserPinRedisServiceImpl implements UserPinRedisService {
    
    private final ValueOperations<String, String> valueOperations;

    public UserPinRedisServiceImpl(ValueOperations<String, String> valueOperations) {
        this.valueOperations = valueOperations;
    }

    @Override
    public UserPin get(Long userId) throws UserPinServiceException {

        log.trace("Starting process to get user pin for user with id {} from Redis Cache", Long.toString(userId));
        String userPinString = valueOperations.get(Long.toString(userId));
        return UserPin.builder()
            .pin(userPinString)
            .userId(userId)
            .build();
    }

    @Override
    public void cache(UserPin userPin) {

        log.trace("Set value in Redis with: key={}, value={}.",
            userPin.getUserId(), userPin.getPin());
        valueOperations.set(Long.toString(userPin.getUserId()), userPin.getPin());
        log.trace("Pin value {} successfully set in Redis", userPin.getPin());
    }

}
