package com.wallib.wallet.bc.users.admin.consumers;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.USER_PIN_ENTITY;

import com.wallib.wallet.bc.users.admin.facades.UserPinRedisFacade;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserPinMessageConsumer {
    
    private final UserPinRedisFacade userPinRedisFacade;

    @Value("${activemq.wallet.bc.users.admin.queue}")
    private String sourceQueue;

    public UserPinMessageConsumer(@NotNull final UserPinRedisFacade userPinRedisFacade) {
        this.userPinRedisFacade = userPinRedisFacade;
    }

    @BasicLog
    @JmsListener(destination = "${activemq.wallet.bc.users.admin.queue}",
        selector = "(action = '" + EVENT_INSERT 
                + "' OR action = '" + EVENT_UPDATE 
                + "' OR action = '" + EVENT_DELETE 
                + "') AND entity = '" + USER_PIN_ENTITY + "'")
    public void receiveUserPinMessage(@Payload @NotNull IndexEventDTO indexEvent)
        throws JsonProcessingException, UserPinServiceException {
        try {
            log.info("User: message received from the ActiveMQ queue {} to create/update index. {}",
                sourceQueue, indexEvent);
            userPinRedisFacade.indexByUserPin(indexEvent.getEntityId());
        } catch (EntityNotFoundException ex) {
            log.error(ex.getMessage());
            throw ex;
        } catch (RuntimeException | JsonProcessingException ex) {
            log.error("Document not indexed by UserPin, object has errors: " + ex.getMessage(), ex);
            throw ex;
        } catch (UserPinServiceException ex) {
            log.error(ex.getMessage());
            throw new UserPinServiceException(ex.getMessage());
        }
    }
}
