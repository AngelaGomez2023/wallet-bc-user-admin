package com.wallib.wallet.bc.users.admin.repositories.am;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import java.io.IOException;
import java.io.InputStream;

public interface AmazonS3Repository {

    String uploadPublicKeyInputStreamToS3Bucket(long userId, InputStream inputStream)
        throws IOException;

    String uploadPrivateKeyInputStreamToS3Bucket(long userId, InputStream inputStream)
        throws IOException;

    @BasicLog
    String uploadFileToS3Bucket(String fileName, InputStream inputStream, int length);

    String getPrivateKeyFromS3Bucket(long userId) throws IOException;

    String getPublicKeyFromS3Bucket(long userId) throws IOException;

    String getPassphraseFromS3Bucket(String filename) throws IOException;

    String getSeedWordsFromS3Bucket(String filename) throws IOException;
}
