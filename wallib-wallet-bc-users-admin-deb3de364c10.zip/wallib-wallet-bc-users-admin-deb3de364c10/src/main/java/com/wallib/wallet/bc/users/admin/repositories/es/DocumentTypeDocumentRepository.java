package com.wallib.wallet.bc.users.admin.repositories.es;

import com.wallib.wallet.bc.users.admin.documents.DocumentTypeDocument;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentTypeDocumentRepository extends 
    ElasticsearchRepository<DocumentTypeDocument, Long> {
    
}
