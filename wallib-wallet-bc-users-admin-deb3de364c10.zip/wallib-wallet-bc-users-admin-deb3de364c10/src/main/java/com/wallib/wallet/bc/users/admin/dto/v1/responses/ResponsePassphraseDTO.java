package com.wallib.wallet.bc.users.admin.dto.v1.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponsePassphraseDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(example = "dd7b9cc2-c82e-4b4a-b782-101bed7ad631")
    @JsonProperty(value = "wallet")
    private String wallet;

    @Schema(example = "pass")
    @JsonProperty(value = "passphrase")
    private String passphrase;

}
