package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.models.wt.Language;
import com.wallib.wallet.bc.users.admin.repositories.wt.LanguageRepository;
import com.wallib.wallet.bc.users.admin.services.LanguageService;
import java.util.List;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class LanguageServiceImpl implements LanguageService {

    private final LanguageRepository languageRepository;

    public LanguageServiceImpl(@NotNull final LanguageRepository languageRepository) {
        this.languageRepository = languageRepository;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public List<Language> list() {
        return languageRepository.findAll();
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public Language findById(Long id){
        log.trace("Starting process to get language object {}", id);

        log.trace("Checking if language with id {} exists", id);
        Language language = getLanguage(id);
        log.trace("language with id {} found. {}", language.getId(), id);

        return language;
    }

    @BasicLog
    @Override
    @Transactional(readOnly = true)
    public Language findByIsoCode(String isoCode){
        log.trace("Starting process to get language object by isoCode {}", isoCode);

        log.trace("Checking if language with isoCode {} exists", isoCode);
        Language language = getLanguageByIsoCode(isoCode);
        log.trace("Language with iso code {} found. {}", language.getIsoCode(), language);

        return language;
    }

    private Language getLanguage(@NotNull Long id) {
        return languageRepository.findById(id).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("Language with id: %1$s not found", id)));
    }

    private Language getLanguageByIsoCode(@NotNull String isoCode) {
        return languageRepository.findByIsoCodeAndDeletedAtIsNull(isoCode).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("Language with iso code: %1$s not found", isoCode)));
    }

}
