package com.wallib.wallet.bc.users.admin.consumers;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.COUNTRY_ENTITY;

import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.facades.CountryElasticFacade;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Payload;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CountryMessageConsumer {
    
    private final CountryElasticFacade countryElasticFacade;

    @Value("${activemq.wallet.bc.users.admin.queue}")
    private String sourceQueue;

    public CountryMessageConsumer(@NotNull final CountryElasticFacade countryElasticFacade){
        this.countryElasticFacade = countryElasticFacade;
    }

    @BasicLog
    @JmsListener(destination = "${activemq.wallet.bc.users.admin.queue}",
        selector = "(action = '" + EVENT_INSERT 
            + "' OR action = '" + EVENT_UPDATE 
            + "' OR action = '" + EVENT_DELETE 
            + "') AND entity = '" + COUNTRY_ENTITY + "'")
    public void receiveCountryMessage(@Payload @NotNull IndexEventDTO indexEvent)
        throws JsonProcessingException, CountryServiceException{
        try{
            log.info("Country: message received from the ActiveMQ queue {} to create/update index. {}",
                sourceQueue, indexEvent);
            countryElasticFacade.indexByCountry(indexEvent.getEntityId());
        }
        catch (EntityNotFoundException ex){
            log.error(ex.getMessage());
            throw ex;
        }
        catch (RuntimeException | JsonProcessingException ex) {
            log.error("Document not indexed by Country, object has errors: " + ex.getMessage(), ex);
            throw ex;
        }
        catch (CountryServiceException ex) {
            log.error(ex.getMessage());
            throw new CountryServiceException(ex.getMessage());
        }
    }
}
