package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.documents.FcmRegistrationTokenDocument;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import java.util.Optional;

public interface FcmRegistrationTokenElasticService {

    Optional<FcmRegistrationTokenDocument> findByFirebaseId(Long firebaseId)
        throws FcmRegistrationTokenException;

    void index(FcmRegistrationToken fcmRegistrationToken) throws FcmRegistrationTokenException;

}
