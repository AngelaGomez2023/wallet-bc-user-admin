package com.wallib.wallet.bc.users.admin.dto.v1.model;

import java.io.Serial;
import java.time.LocalDate;
import javax.validation.constraints.Email;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.dto.v1.AbstractFoundationDTO;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import io.swagger.v3.oas.annotations.media.Schema;

public class UserDTO extends AbstractFoundationDTO {

    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(example = "1")
    @JsonProperty(value = "firebase_id")
    private String firebaseId;

    @Schema(example = "nickname")
    @JsonProperty(value = "nickname")
    private String nickname;

    @Schema(example = "name")
    @JsonProperty(value = "firstname")
    private String firstname;

    @Schema(example = "lastname")
    @JsonProperty(value = "lastname")
    private String lastname;

    @Schema(example = "email@example.com")
    @JsonProperty(value = "email")
    @Email
    private String email;

    @Schema(example = "123456789")
    @JsonProperty(value = "phone")
    private String phone;

    @Schema(example = "1")
    @JsonProperty(value = "document_id")
    private String documentId;

    @Schema(example = "1")
    @JsonProperty(value = "document_type")
    private Integer documentType;

    @Schema(example = "2017-01-13T17:09:42.411")
    @JsonProperty(value = "document_date_expiration")
    private LocalDate documentDateExpiration;

    @Schema(example = "Baker St.")
    @JsonProperty(value = "address")
    private String address;

    @Schema(example = "Bog")
    @JsonProperty(value = "city")
    private String city;

    @Schema(example = "Cun")
    @JsonProperty(value = "state")
    private String state;

    @Schema(example = "CO")
    @JsonProperty(value = "country_id")
    private Long countryId;

    @Schema(example = "")
    @JsonProperty(value = "type")
    private UserTypeEnum type;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;
}
