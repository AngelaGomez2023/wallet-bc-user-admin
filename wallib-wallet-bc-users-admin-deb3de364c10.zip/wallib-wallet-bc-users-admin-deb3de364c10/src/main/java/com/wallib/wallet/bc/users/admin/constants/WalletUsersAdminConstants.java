package com.wallib.wallet.bc.users.admin.constants;

public final class WalletUsersAdminConstants {

    public static final String AUDIENCE_SERVICE = "SERVICE";
    public static final String AUDIENCE_PUBLIC = "PUBLIC";
    public static final String AUDIENCE_ADMIN = "ADMIN";

    public static final String UNAUTHORIZED_REQUEST = "Unauthorized request.";
    public static final String BEARER = "Bearer ";
    public static final String BEARER_AUTH = "bearerAuth";

    public static final long DEFAULT_LANGUAGE = 1;

    public static final int MIN_CHARACTERS_TO_SEARCH = 3;
    public static final String UNSORTED = "UNSORTED";

    // RSA keys
    public static final String ALGORITHM = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING";
    public static final String SHA_256 = "SHA-256";
    public static final String MGF1 = "MGF1";

    public static final String FORMAT_INT = "%d.%s";
    public static final String FORMAT_STRING = "%s.%s";

    // status
    public static final int ACTIVE = 1;
    public static final int PENDING = 2;
    public static final int INACTIVE = 0;

    // mod to jwt token
    public static final String PUBLIC = "PUBLIC";

    // role with admin audience to jwt token
    public static final String LIST_USERS_BY_COUNTRY_ID = "WALLET_USERS_ADMIN_LIST_USERS_BY_COUNTRY_ID";
    public static final String FIND_BY_USER_ID = "WALLET_USERS_ADMIN_FIND_BY_USER_ID";
    public static final String FIND_BY_FIREBASE_ID = "WALLET_USERS_ADMIN_FIND_BY_FIREBASE_ID";
    public static final String CREATE_USER = "WALLET_USERS_ADMIN_CREATE_USER";
    public static final String UPDATE_USER = "WALLET_USERS_ADMIN_UPDATE_USER";
    public static final String DELETE_USER = "WALLET_USERS_ADMIN_DELETE_USER";
    public static final String FIND_BY_NICKNAME = "WALLET_USERS_ADMIN_FIND_BY_NICKNAME";

    public static final String LIST_COUNTRIES = "WALLET_USERS_ADMIN_LIST_COUNTRIES";
    public static final String FIND_BY_COUNTRY_ID = "WALLET_USERS_ADMIN_FIND_BY_COUNTRY_ID";
    public static final String FIND_BY_COUNTRY_ISO_CODE = "WALLET_USERS_ADMIN_FIND_BY_COUNTRY_ISO_CODE";
    public static final String CREATE_COUNTRY = "WALLET_USERS_ADMIN_CREATE_COUNTRY";
    public static final String UPDATE_COUNTRY = "WALLET_USERS_ADMIN_UPDATE_COUNTRY";
    public static final String DELETE_COUNTRY = "WALLET_USERS_ADMIN_DELETE_COUNTRY";

    public static final String LIST_LANGUAGES = "WALLET_USERS_ADMIN_LIST_LANGUAGES";
    public static final String FIND_BY_LANGUAGE_ID = "WALLET_USERS_ADMIN_FIND_BY_LANGUAGE_ID";
    public static final String FIND_BY_LANGUAGE_ISO_CODE = "WALLET_USERS_ADMIN_FIND_BY_LANGUAGE_ISO_CODE";

    public static final String LIST_DOCUMENT_TYPES = "WALLET_USERS_ADMIN_LIST_DOCUMENT_TYPES";
    public static final String FIND_BY_DOCUMENT_TYPE_ID = "WALLET_USERS_ADMIN_FIND_BY_DOCUMENT_TYPE_ID";
    public static final String CREATE_DOCUMENT_TYPE = "WALLET_USERS_ADMIN_CREATE_DOCUMENT_TYPE";
    public static final String UPDATE_DOCUMENT_TYPE = "WALLET_USERS_ADMIN_UPDATE_DOCUMENT_TYPE";
    public static final String DELETE_DOCUMENT_TYPE = "WALLET_USERS_ADMIN_DELETE_DOCUMENT_TYPE";

    public static final String FIND_BY_USER_PIN_ID = "WALLET_USERS_ADMIN_FIND_BY_USER_PIN_ID";
    public static final String CREATE_USER_PIN = "WALLET_USERS_ADMIN_CREATE_USER_PIN";
    public static final String UPDATE_USER_PIN = "WALLET_USERS_ADMIN_UPDATE_USER_PIN";
    public static final String DELETE_USER_PIN = "WALLET_USERS_ADMIN_DELETE_USER_PIN";

    public static final String CREATE_KEY_PAIR = "WALLET_USERS_ADMIN_CREATE_KEY_PAIR";

    public static final String GET_WALLET_PASSPHRASE = "WALLET_USERS_ADMIN_GET_WALLET_PASSPHRASE";

    public static final String GET_WALLET_SEED_WORDS = "WALLET_USERS_ADMIN_GET_WALLET_SEED_WORDS";

    public static final String SAVE_FCM_TOKEN = "WALLET_USERS_ADMIN_CREATE_FCM_TOKEN";
    public static final String FIND_FCM_BY_FIREBASE_ID = "WALLET_USERS_ADMIN_FIND_FCM_BY_FIREBASE_ID";


    //Events
    public static final String EVENT_INSERT = "INSERT";
    public static final String EVENT_UPDATE = "UPDATE";
    public static final String EVENT_DELETE = "DELETE";
    //Entities
    public static final String USER_ENTITY = "USER";
    public static final String COUNTRY_ENTITY = "COUNTRY";
    public static final String USER_PIN_ENTITY = "USER_PIN";
    public static final String DOCUMENT_TYPE_ENTITY = "DOCUMENT_TYPE";
    public static final String FCM_REGISTRATION_TOKEN_ENTITY = "FCM_REGISTRATION_TOKEN";



    private WalletUsersAdminConstants() {
    }

}
