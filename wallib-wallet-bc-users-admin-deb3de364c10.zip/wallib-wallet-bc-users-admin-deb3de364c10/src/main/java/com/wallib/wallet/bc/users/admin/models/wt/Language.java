package com.wallib.wallet.bc.users.admin.models.wt;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.serializers.wt.CountrySerializer;
import java.io.Serial;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "languages", schema = "wallet")
@JsonSerialize(using = CountrySerializer.class)
public class Language extends AbstractFoundationEntity {

    @Serial
    private static final long serialVersionUID = 1L;

    @Column(name = "name", columnDefinition = "json")
    @JsonRawValue
    private String name;

    @Column(name = "iso_code", nullable = false)
    private String isoCode;

    @Column(name = "status", nullable = false)
    private Integer status;

    public Language(Long id) {
        super(id);
    }
}
