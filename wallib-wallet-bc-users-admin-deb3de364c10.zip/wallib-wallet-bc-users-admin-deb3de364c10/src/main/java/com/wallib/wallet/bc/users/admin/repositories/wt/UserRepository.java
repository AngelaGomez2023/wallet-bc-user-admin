package com.wallib.wallet.bc.users.admin.repositories.wt;

import java.util.Optional;

import com.wallib.wallet.bc.users.admin.models.wt.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends WallibRepository<User, Long> {

    @Query("SELECT u "
        + "FROM User u "
        + "WHERE u.countryId = :countryId "
        + "AND (:firstname is not null or u.firstname like '%'||:firstname||'%') "
        + "AND u.deletedAt IS NULL")
    Page<User> findByIdInCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull (
        Long countryId, String firstname, Pageable pageable
    );

    @Query("SELECT u "
        + "FROM User u "
        + "INNER JOIN FirebaseAccount f "
        + "ON u.firebaseId = f.id "
        + "WHERE f.firebaseId = :firebaseId "
        + "AND u.deletedAt IS NULL "
        + "AND f.deletedAt IS NULL")
    Optional<User> findByFirebaseIdAndDeletedAtIsNull (String firebaseId);

    Boolean existsByFirebaseIdAndDeletedAtIsNull(Long firebaseId);
    
    Boolean existsByFirebaseIdAndIdAndDeletedAtIsNull(Long firebaseId, long id);

    Boolean existsByDocumentIdAndDocumentTypeAndDeletedAtIsNull(String documentId,
        Integer documentType);

    Boolean existsByDocumentIdAndDocumentTypeAndIdNotAndDeletedAtIsNull(String documentId,
        Integer documentType, Long id);

    @Query("SELECT count(*) "
        + "FROM User u "
        + "WHERE u.countryId = :countryId "
        + "AND (:firstname is null or u.firstname like '%'||:firstname||'%') "
        + "AND u.deletedAt IS NULL")
    Integer countByIdInAndCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull
        (Long countryId, String firstname);

    Optional<User> findByNicknameAndStatusAndDeletedAtIsNull(String nickname, Integer status);
}
