package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.services.KeyPairService;
import com.wallib.wallet.bc.users.admin.utils.KeyPairUtils;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import org.springframework.transaction.annotation.Transactional;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.KeyPairServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.am.AmazonS3Repository;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class KeyPairServiceImpl implements KeyPairService {

    private final AmazonS3Repository amazonS3Repository;
    private final UserRepository userRepository;

    public KeyPairServiceImpl(UserRepository userRepository,
        AmazonS3Repository amazonS3Repository) {
        this.amazonS3Repository = amazonS3Repository;
        this.userRepository = userRepository;
    }

    @BasicLog
    @Override
    public com.wallib.wallet.bc.users.admin.domain.PublicKey create(Long userId)
        throws KeyPairServiceException {

        log.trace("Validate if user id exists {} ", userId);
        User user = getUserById(userId);
        log.trace("User id exists. {}", user);

        try {
            log.trace("Starting process to create key pairs for user with id {}", userId);
            String keyPairAlgorithm = "RSA";
            KeyPair keyPair = KeyPairUtils.generateRSAKeyPair(keyPairAlgorithm);
            log.trace("Successfully generated key pairs for user with id {}", userId);

            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();

            log.trace("Starting process to upload public and private keys {}", userId);

            InputStream publicKeyInputStream = KeyPairUtils.generatePublicKeyInputStream(userId,
                publicKey);
            InputStream privateKeyInputStream = KeyPairUtils.generatePrivateKeyInputStream(userId,
                privateKey);

            amazonS3Repository.uploadPublicKeyInputStreamToS3Bucket(userId, publicKeyInputStream);
            log.trace("Upload public key successful {}", userId);
            amazonS3Repository.uploadPrivateKeyInputStreamToS3Bucket(userId, privateKeyInputStream);
            log.trace("Upload private key successful {}", userId);

            String publicKeyString = KeyPairUtils.generatePublicKeyString(userId, publicKey);

            return com.wallib.wallet.bc.users.admin.domain.PublicKey.builder()
                .userId(userId)
                .algorithm(keyPairAlgorithm)
                .publicKey(publicKeyString)
                .build();
        } catch (RSAKeyPairException e) {
            throw new KeyPairServiceException("Failed to generate keys.", e);
        } catch (IOException e) {
            throw new KeyPairServiceException("Failed to upload keys to S3.", e);
        }
    }

    private User getUserById(@NotNull Long userId) {
        return userRepository.findById(userId).orElseThrow(
            () -> new EntityNotFoundException(
                String.format("User with id: %1$s not found", userId)));
    }
}
