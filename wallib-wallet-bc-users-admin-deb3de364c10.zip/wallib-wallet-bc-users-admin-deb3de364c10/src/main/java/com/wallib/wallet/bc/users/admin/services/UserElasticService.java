package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.User;

public interface UserElasticService {

    void index(User user) throws UserServiceException;

}
