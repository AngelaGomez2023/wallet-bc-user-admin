package com.wallib.wallet.bc.users.admin.documents;

import java.io.Serial;
import java.io.Serializable;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@NoArgsConstructor
public class SimpleField implements Serializable {

    @Serial
    private static final long serialVersionUID = 1648976513453048256L;

    @Field(type = FieldType.Long)
    private Long id;

    @Field(type = FieldType.Keyword)
    private String name;

    @Builder
    public SimpleField(Long id, String name) {
        this.id = id;
        this.name = name;
    }

}