package com.wallib.wallet.bc.users.admin.facades;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;

public interface CountryElasticFacade {
    
    void indexByCountry(Long countryId) throws JsonProcessingException, CountryServiceException;
}
