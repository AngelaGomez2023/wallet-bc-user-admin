package com.wallib.wallet.bc.users.admin.facades.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.UserPinRedisService;
import com.wallib.wallet.bc.users.admin.services.UserPinService;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.wallib.wallet.bc.users.admin.facades.UserPinRedisFacade;

@Slf4j
@Component
public class UserPinRedisFacadeImpl implements UserPinRedisFacade {
    
    private final UserPinService userPinService;
    private final UserPinRedisService usePinRedisService;

    public UserPinRedisFacadeImpl(@NotNull final UserPinService userPinService,
        @NotNull final UserPinRedisService usePinRedisService) {
        this.userPinService = userPinService;
        this.usePinRedisService = usePinRedisService;
    }

    @BasicLog
    @Override
    public void indexByUserPin(Long userPinId) throws JsonProcessingException, UserPinServiceException {
        log.trace("User pin ID received to index: {}.", userPinId);
        UserPin userPin = userPinService.findByUserId(userPinId);
        log.trace("User pin found to index: {}.", userPin);
        usePinRedisService.cache(userPin);
    }
}
