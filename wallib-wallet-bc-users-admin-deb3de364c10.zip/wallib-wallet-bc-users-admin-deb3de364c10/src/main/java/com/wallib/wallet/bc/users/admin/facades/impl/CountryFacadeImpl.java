package com.wallib.wallet.bc.users.admin.facades.impl;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_INSERT;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_UPDATE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.EVENT_DELETE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.COUNTRY_ENTITY;

import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.facades.CountryFacade;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import com.wallib.wallet.bc.users.admin.services.EventService;
import org.springframework.stereotype.Component;

@Component
public class CountryFacadeImpl implements CountryFacade {
    
    private final CountryService countryService;
    private final EventService eventService;

    public CountryFacadeImpl(CountryService countryService,
        EventService eventService){
        this.countryService = countryService;
        this.eventService = eventService;
    }

    @BasicLog
    @Override
    public Country create(@NotNull final Country createCountry)
        throws CountryServiceException, JsonProcessingException{
        Country country = countryService.create(createCountry);
        eventService.sendEventToQueue(EVENT_INSERT, COUNTRY_ENTITY, country.getId());
        return country;
    }

    @BasicLog
    @Override
    public Country update(@NotNull final Long id,
        @NotNull final Country createCountry)
        throws CountryServiceException, JsonProcessingException{
        Country country = countryService.update(id, createCountry);
        eventService.sendEventToQueue(EVENT_UPDATE, COUNTRY_ENTITY, country.getId());
        return country;
    }

    @BasicLog
    @Override
    public void delete(@NotNull final Long id)
        throws CountryServiceException, JsonProcessingException{
        countryService.delete(id);
        eventService.sendEventToQueue(EVENT_DELETE, COUNTRY_ENTITY, id);
    }
}
