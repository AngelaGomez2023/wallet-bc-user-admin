package com.wallib.wallet.bc.users.admin.consumers;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.SaveWalletCustodialInfoDTO;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.services.WalletService;
import java.io.IOException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CustodialWalletConsumer {

    @Value("${activemq.wallet.bc.bridge.gateway.transactions.topic}")
    private String walletBridgeGatewayTransactionTopic;

    private final WalletService walletService;

    public CustodialWalletConsumer(WalletService walletService) {
        this.walletService = walletService;
    }

    @BasicLog
    @JmsListener(destination = "${activemq.wallet.bc.bridge.gateway.transactions.topic}",
            selector = "action = 'CUSTODIAL'")
    public void processCustodialKeys(@Payload @NotNull SaveWalletCustodialInfoDTO
        saveWalletCustodialInfoDTO) throws IOException, RSAKeyPairException {

        log.info("Receiving message to process crypto wallet custodial keys {} "
                + "with object {}.",
            walletBridgeGatewayTransactionTopic, saveWalletCustodialInfoDTO);

        boolean processCustodialKeys =
            walletService.processCustodialKeys(saveWalletCustodialInfoDTO);

        log.info("Crypto wallet custodial processed: {}", processCustodialKeys);
    }

}
