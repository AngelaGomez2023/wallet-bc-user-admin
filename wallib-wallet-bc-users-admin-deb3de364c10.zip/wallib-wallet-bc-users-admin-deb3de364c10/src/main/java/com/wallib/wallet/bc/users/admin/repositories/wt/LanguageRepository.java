package com.wallib.wallet.bc.users.admin.repositories.wt;

import com.wallib.wallet.bc.users.admin.models.wt.Language;
import java.util.Optional;
import org.springframework.stereotype.Repository;

@Repository
public interface LanguageRepository extends WallibRepository<Language, Long> {

    Optional<Language> findByIsoCodeAndDeletedAtIsNull(String isoCode);

}
