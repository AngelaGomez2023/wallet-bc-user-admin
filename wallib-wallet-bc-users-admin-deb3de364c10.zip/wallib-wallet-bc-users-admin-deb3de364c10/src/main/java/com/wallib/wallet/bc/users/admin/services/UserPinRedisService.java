package com.wallib.wallet.bc.users.admin.services;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;

public interface UserPinRedisService {
    
    UserPin get(Long userId) throws UserPinServiceException;

    void cache(UserPin user) throws UserPinServiceException;
}
