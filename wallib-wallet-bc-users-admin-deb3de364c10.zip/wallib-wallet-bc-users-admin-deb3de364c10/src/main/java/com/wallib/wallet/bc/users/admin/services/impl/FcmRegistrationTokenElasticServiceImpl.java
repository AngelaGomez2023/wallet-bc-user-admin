package com.wallib.wallet.bc.users.admin.services.impl;

import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.documents.FcmRegistrationTokenDocument;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.repositories.es.FcmRegistrationTokenDocumentRepository;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenElasticService;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FcmRegistrationTokenElasticServiceImpl implements FcmRegistrationTokenElasticService {

    private final FcmRegistrationTokenDocumentRepository fcmRegistrationTokenDocumentRepository;

    public FcmRegistrationTokenElasticServiceImpl(FcmRegistrationTokenDocumentRepository 
        fcmRegistrationTokenDocumentRepository) {
        this.fcmRegistrationTokenDocumentRepository = fcmRegistrationTokenDocumentRepository;
    }

    @Override
    @BasicLog
    public Optional<FcmRegistrationTokenDocument> findByFirebaseId(Long firebaseId)
        throws FcmRegistrationTokenException {

        log.info("Find by FCM registration token document in ES {}.", firebaseId);
        Optional<FcmRegistrationTokenDocument> fcmRegistrationTokenDocument =
            fcmRegistrationTokenDocumentRepository.findByFirebaseIdAndStatus(firebaseId, 1);
        log.info("FcmRegistrationTokenDocument founded successfully in ES {}.",
            fcmRegistrationTokenDocument);

        return fcmRegistrationTokenDocument;

    }

    @Override
    @BasicLog
    public void index(FcmRegistrationToken fcmRegistrationToken) throws FcmRegistrationTokenException {
        log.trace("Creating FcmRegistrationTokenDocument to index in ES with user {}.",
            fcmRegistrationToken);
        FcmRegistrationTokenDocument fcmRegistrationTokenDocument =
            createFcmRegistrationTokenDocument(fcmRegistrationToken);
        log.trace("FcmRegistrationTokenDocument created and ready to be indexed in ES {}.",
            fcmRegistrationTokenDocument);

        log.info("Indexing FcmRegistrationTokenDocument in ES {}.", fcmRegistrationTokenDocument);
        fcmRegistrationTokenDocumentRepository.save(fcmRegistrationTokenDocument);
        log.info("FcmRegistrationTokenDocument indexed successfully in ES {}.", fcmRegistrationTokenDocument);

    }

    private FcmRegistrationTokenDocument createFcmRegistrationTokenDocument(
        FcmRegistrationToken fcmRegistrationToken) {

        return FcmRegistrationTokenDocument.builder()
            .id(fcmRegistrationToken.getId())
            .firebaseId(fcmRegistrationToken.getFirebaseId())
            .token(fcmRegistrationToken.getToken())
            .platform(fcmRegistrationToken.getPlatform().getValue())
            .status(fcmRegistrationToken.getStatus())
            .build();

    }
}
