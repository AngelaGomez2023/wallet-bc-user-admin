package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponsePassphraseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseSeedWordsDTO;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.IOException;
import org.springframework.http.ResponseEntity;

@Tag(name = "Wallets")
public interface WalletControllersDocs {

    @Operation(summary = "Get passphrase")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Get passphrase to wallet",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ResponsePassphraseDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponsePassphraseDTO>> getPassphrase(
        @Parameter(
            name = "walletNumber",
            description = "Wallet number to get passphrase.",
            required = true
        ) String walletNumber,
        @Parameter(
            name = "userId",
            description = "User id to get passphrase to wallet.",
            required = true
        ) Long userId) throws IOException, RSAKeyPairException;

    @Operation(summary = "Get seed words")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Get seed words to wallet",
            content = {
                @Content(mediaType = APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = ResponseSeedWordsDTO.class))
            }
        )
    })
    ResponseEntity<ApiResponseDTO<ResponseSeedWordsDTO>> getSeedWords(
        @Parameter(
            name = "walletNumber",
            description = "Wallet number to get seed words.",
            required = true
        ) String walletNumber,
        @Parameter(
            name = "userId",
            description = "User id to get seed words to wallet.",
            required = true
        ) Long userId) throws IOException, RSAKeyPairException;

}
