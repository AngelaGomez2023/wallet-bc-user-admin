package com.wallib.wallet.bc.users.admin.dto.v1.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponseFcmRegistrationTokenDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 638735679947032033L;

    @Schema(example = "1")
    @JsonProperty(value = "id")
    private Long id;

    @Schema(example = "1")
    @JsonProperty(value = "firebase_id")
    private Long firebaseId;

    @Schema(example = "dl0H754sRxaOpzKHfsjA32:APA91bEH6R73ixG0C_Xoxz8XXp4HBn_nKIYPGJPkvXnesWUdw6nd1PgHGMNS3GtVrVHb3kSq59FDpw-h69nawxkqCyNca8NoyWPoMAmp4O7Oa-CIev-adHSjjoAiXjVTWWjwXeUt4alA")
    @JsonProperty(value = "token")
    private String token;

    @Schema(example = "android")
    @JsonProperty(value = "platform")
    private PlatformEnum platform;

    @Schema(example = "1")
    @JsonProperty(value = "status")
    private Integer status;

}
