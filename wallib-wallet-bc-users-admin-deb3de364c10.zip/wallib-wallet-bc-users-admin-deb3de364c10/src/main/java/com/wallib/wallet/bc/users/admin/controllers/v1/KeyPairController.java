package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.AUDIENCE_SERVICE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_KEY_PAIR;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import javax.validation.constraints.NotNull;
import com.wallib.wallet.bc.users.admin.controllers.v1.docs.KeyPairControllerDocs;
import com.wallib.wallet.bc.users.admin.domain.PublicKey;
import org.springframework.web.bind.annotation.RestController;
import com.wallib.wallet.bc.users.admin.annotations.BasicLog;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponsePublicKeyDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.KeyPairServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.services.KeyPairService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.fasterxml.jackson.core.JsonProcessingException;

@Slf4j
@RequestMapping(value = "/v1/keys")
@RestController
public class KeyPairController implements KeyPairControllerDocs {

    private final KeyPairService keyPairService;

    public KeyPairController(KeyPairService keyPairService){
        this.keyPairService = keyPairService;
    }

    @BasicLog
    @PostMapping(value = "{userId}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('" + AUDIENCE_SERVICE + "') || hasRole('" + CREATE_KEY_PAIR + "')")
    public ResponseEntity<ApiResponseDTO<ResponsePublicKeyDTO>> create(@PathVariable Long userId)
        throws JsonProcessingException, KeyPairServiceException, RSAKeyPairException {

        log.trace("Request received to create key pair for user with id {}", userId);
        PublicKey publicKey = keyPairService.create(userId);
        log.trace("Key pair for user with id {} successfully created", userId);

        log.trace("Generating public key DTO from public key. {}", publicKey);
        ResponsePublicKeyDTO publicKeyDTO = generatePublicKeyDTOFromPublicKey(publicKey);
        log.trace("ResponsePublicKeyDTO generated successfully in create method. {}", publicKeyDTO);
        
        log.trace("Creating ApiResponse from KeyPaiController [CREATE]");
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponseDTO.<ResponsePublicKeyDTO>builder()
                .statusCode(HttpStatus.CREATED.value())
                .message("Key pair created successfully")
                .body(publicKeyDTO)
                .build());
    }

    private ResponsePublicKeyDTO generatePublicKeyDTOFromPublicKey(@NotNull PublicKey publicKey) {
        return ResponsePublicKeyDTO.builder()
            .userId(publicKey.getUserId())
            .algorithm(publicKey.getAlgorithm())
            .publicKey(publicKey.getPublicKey())
            .build();
    }
}