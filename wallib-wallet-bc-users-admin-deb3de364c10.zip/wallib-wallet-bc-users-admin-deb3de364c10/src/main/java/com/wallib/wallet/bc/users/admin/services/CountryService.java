package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import java.util.List;

public interface CountryService {

    List<Country> list();
    
    Country findById(Long id) throws JsonProcessingException;
    
    Country findByIsoCode(String isoCode) throws JsonProcessingException;

    Country create(Country user) throws JsonProcessingException, CountryServiceException;

    Country update(Long id, Country user)
        throws JsonProcessingException, CountryServiceException;

    void delete(Long id) throws JsonProcessingException;
}
