package com.wallib.wallet.bc.users.admin.controllers.v1.docs;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.model.UserPinDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateUserPinDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserPinDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponseUserPinDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Tag(name = "User Pins")
public interface UserPinControllerDocs {

	@Operation(summary = "Find User pin By UserId")
	@ApiResponses(value = {
		@ApiResponse(
			responseCode = "200",
			description = "Find User pin By UserId",
			content = {
				@Content(mediaType = APPLICATION_JSON_VALUE,
					schema = @Schema(implementation = UserPinDTO.class))
			}
		)
	})
	ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> findByUserId(
		@Parameter(
			name = "userId",
			description = "User pin id to find by.",
			required = true
		) Long userId) throws JsonProcessingException, UserPinServiceException;

	@Operation(summary = "Create User pin",
		description = "Allows to create a user pin only if user does not hace a valid pin.")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "User pin created successfully", content = {
		@Content(
			mediaType = APPLICATION_JSON_VALUE, 
			schema = @Schema(implementation = UserPinDTO.class
		)) 
	})})
	ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> create(
		@Parameter(
			name = "id",
			description = "User Id to be updated.",
			required = true
		) Long userId,
		@Parameter(
			name = "user pin", 
			description = "User to create.", 
			required = true
		) 
		CreateUserPinDTO createPinUserDTO)
		throws JsonProcessingException, UserPinServiceException;

	@Operation(summary = "Update a user pin",
		description = "Allows to update a user pin only if user pin id exists and privided pin matches current pin.")
	@ApiResponse(
		responseCode = "202",
		description = "User pin updated successfully.",
		content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
				schema = @Schema(implementation = UpdateUserPinDTO.class))
		}
	)
	ResponseEntity<ApiResponseDTO<ResponseUserPinDTO>> update(
		@Parameter(
			name = "id",
			description = "User Id to be updated.",
			required = true
		) Long userId,
		@Parameter(
			name = "User pin",
			description = "User pin to update.",
			required = true
		) UpdateUserPinDTO updateUserPinDTO
	) throws JsonProcessingException, UserPinServiceException;

	@Operation(summary = "Delete a user pin",
		description = "Allows to delete a user pin by userId.")
	@ApiResponse(
		responseCode = "200",
		description = "User pin deleted successfully.",
		content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
				schema = @Schema(implementation = ApiResponseDTO.class))
		}
	)
	ResponseEntity<ApiResponseDTO<String>> delete(
		@Parameter(
			name = "userId",
			description = "User pin to delete.",
			required = true
		) Long id
	) throws JsonProcessingException, UserPinServiceException;
}
