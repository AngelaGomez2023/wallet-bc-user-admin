package com.wallib.wallet.bc.users.admin.exceptions;

import java.io.Serial;

public class WalletUsersListExceptions {

    private WalletUsersListExceptions() {}

    public static class WalletUserRestException extends BaseException{
        
        @Serial
        private static final Long serialVersionUID = 1L;
    
        public WalletUserRestException(String msg, Throwable err){
            super(msg, err);
        }

        public WalletUserRestException(String msg){
            super(msg);
        }
    }

    public static class RSAKeyPairException extends BaseException{

        @Serial
        private static final Long serialVersionUID = 1L;
    
        public RSAKeyPairException(String msg, Throwable err){
            super(msg, err);
        }

        public RSAKeyPairException(String msg){
            super(msg);
        }
    }
}
