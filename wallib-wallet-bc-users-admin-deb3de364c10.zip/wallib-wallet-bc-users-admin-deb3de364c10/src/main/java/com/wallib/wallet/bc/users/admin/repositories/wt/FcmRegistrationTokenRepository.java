package com.wallib.wallet.bc.users.admin.repositories.wt;

import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import java.util.Optional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FcmRegistrationTokenRepository extends WallibRepository<FcmRegistrationToken, Long> {

    Optional<FcmRegistrationToken> findByFirebaseIdAndStatusAndDeletedAtIsNull(Long firebaseId,
        Integer status);

    Boolean existsByTokenAndFirebaseIdAndStatusAndDeletedAtIsNull(String token, Long firebaseId, Integer status);

    @Modifying
    @Query("UPDATE FcmRegistrationToken fcm SET fcm.status = 0 "
        + "WHERE fcm.firebaseId = :firebaseId "
        + "AND fcm.status = 1 "
        + "AND fcm.deletedAt IS NULL")
    void updateStatusByFirebaseIdAndDeletedAtIsNull (Long firebaseId);

}
