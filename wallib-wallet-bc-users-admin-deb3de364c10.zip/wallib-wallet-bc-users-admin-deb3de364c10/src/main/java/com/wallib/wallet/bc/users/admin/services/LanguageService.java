package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.models.wt.Language;
import java.util.List;

public interface LanguageService {

    List<Language> list();

    Language findById(Long id) throws JsonProcessingException;

    Language findByIsoCode(String isoCode) throws JsonProcessingException;

}
