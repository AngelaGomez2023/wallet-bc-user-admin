package com.wallib.wallet.bc.users.admin.services;

public interface EventService {

    void sendEventToQueue(String event, String entity, Long id);

}
