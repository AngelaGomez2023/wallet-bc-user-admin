package com.wallib.wallet.bc.users.admin.models.wt;

import java.io.Serial;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wallib.wallet.bc.users.admin.models.AbstractFoundationEntity;
import com.wallib.wallet.bc.users.admin.serializers.wt.DocumentTypeSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "document_types", schema = "wallet")
@JsonSerialize(using = DocumentTypeSerializer.class)
public class DocumentType extends AbstractFoundationEntity{
    
    @Serial
    private static final long serialVersionUID = 1L;

    @Column(name = "type")
    @JsonRawValue
    private String type;

    @Column(name = "country_id", nullable = false)
    private Long countryId;

    @Column(name = "status", nullable = false)
    private Integer status;

    public DocumentType(Long id) {
        super(id);
    }
}
