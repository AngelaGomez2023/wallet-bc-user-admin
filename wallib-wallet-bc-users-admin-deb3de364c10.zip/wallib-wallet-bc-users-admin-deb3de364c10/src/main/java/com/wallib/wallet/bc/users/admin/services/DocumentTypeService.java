
package com.wallib.wallet.bc.users.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import java.util.List;

public interface DocumentTypeService{

    List<DocumentType> list();
    
    DocumentType findById(Long id) throws JsonProcessingException;

    DocumentType create(DocumentType user) throws JsonProcessingException, DocumentTypeServiceException;

    DocumentType update(Long id, DocumentType user)
        throws JsonProcessingException, DocumentTypeServiceException;

    void delete(Long id) throws JsonProcessingException;
}