package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CountryServiceImplTest {
    
    @InjectMocks
    private CountryServiceImpl countryService;

    @Mock
    private CountryRepository countryRepository;

    @Mock
    private AuditLogServiceImpl auditLogService;

    @Test
    void test_ListMethod_Should_ListCountries_When_CallService() {
        Country country = getCountry();
        when(countryRepository.findAll()).thenReturn(Collections.singletonList(country));

        assertAll(() -> countryService.list());
        verify(countryRepository, times(1))
            .findAll();
    }

    @Test
    void test_FindByIdMethod_Should_GetCountry_When_ReceiveQueryParams() {
        Country country = getCountry();
        when(countryRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));

        assertAll(() -> countryService.findById(1L));
        verify(countryRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_FindByIsoCodeMethod_Should_GetCountry_When_ReceiveQueryParams() {
        Country country = getCountry();
        when(countryRepository.findByIsoCodeAndDeletedAtIsNull(anyString())).thenReturn(java.util.Optional.of(country));

        assertAll(() -> countryService.findByIsoCode("CO"));
        
        verify(countryRepository, times(1))
            .findByIsoCodeAndDeletedAtIsNull(anyString());
    }

    @Test
    void test_CreateMethod_Should_CreateCountry_When_ReceiveValidObject() throws JsonProcessingException {
        Country country = getCountry();

        when(countryRepository.existsByIsoCodeAndDeletedAtIsNull(anyString())).thenReturn(false);
        when(countryRepository.save(any(Country.class))).thenReturn(country);
        doNothing().when(auditLogService).createAuditLog(any(Country.class));

        assertAll(() -> countryService.create(country));
        verify(countryRepository, times(1))
            .existsByIsoCodeAndDeletedAtIsNull(anyString());
        verify(countryRepository, times(1)).save(any(Country.class));
        verify(auditLogService, times(1)).createAuditLog(any(Country.class));
    }

    @Test
    void test_CreateMethod_Should_ThrowCountryServiceException_When_IsoCodeDuplicated() {
        Country country = getCountry();

        when(countryRepository.existsByIsoCodeAndDeletedAtIsNull(anyString())).thenReturn(true);

        assertThrows(CountryServiceException.class,
            () -> countryService.create(country));
    }

    @Test
    void test_UpdateMethod_Should_UpdateCountry_When_ReceiveValidObject() throws JsonProcessingException {
        Country country = getCountry();

        when(countryRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));
        when(countryRepository.existsByIsoCodeAndIdNotAndDeletedAtIsNull(anyString(), anyLong()))
            .thenReturn(false);
        when(countryRepository.saveAndFlush(any(Country.class))).thenReturn(country);
        doNothing().when(auditLogService).updateAuditLog(any(Country.class), any(Country.class));

        assertAll(() -> countryService.update(1L, country));
        verify(countryRepository, times(1))
            .existsByIsoCodeAndIdNotAndDeletedAtIsNull(anyString(), anyLong());
        verify(countryRepository, times(1)).saveAndFlush(any(Country.class));
        verify(auditLogService, times(1))
            .updateAuditLog(any(Country.class), any(Country.class));

    }

    @Test
    void test_UpdateMethod_Should_ThrowEntityNotFoundException_When_CountryDoesNotExist() {
        Country country = getCountry();

        when(countryRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> countryService.update(1L, country));
    }

    @Test
    void test_UpdateMethod_Should_ThrowCountryServiceException_When_IsoCodeExist_InOtherRecord() {
        Country country = getCountry();

        when(countryRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));
        when(countryRepository.existsByIsoCodeAndIdNotAndDeletedAtIsNull(anyString(), anyLong()))
            .thenReturn(true);

        assertThrows(CountryServiceException.class,
            () -> countryService.update(1L, country));
    }

    @Test
    void test_UpdateMethod_Should_ThrowCountryServiceException_When_NameExist_InOtherRecord() {
        Country country = getCountry();

        when(countryRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));
        when(countryRepository.existsByNameAndIdNotAndDeletedAtIsNull(anyString(), anyLong()))
            .thenReturn(true);

        assertThrows(CountryServiceException.class,
            () -> countryService.update(1L, country));
    }

    @Test
    void test_DeleteMethod_Should_DeleteCountry_When_ReceiveValidId() {
        Country country = getCountry();
        when(countryRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));
        doNothing().when(countryRepository).delete(any(Country.class));

        assertAll(() -> countryService.delete(1L));
        verify(countryRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_DeleteMethod_Should_ThrowEntityNotFoundException_When_CountryDoesNotExist() {

        when(countryRepository.findById(anyLong())).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class,
            () -> countryService.delete(1L));
    }

    private Country getCountry() {
        Country country = Country.builder()
            .name("{}")
            .status(1)
            .isoCode("CO")
            .build();

        country.setId(1L);
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());

        return country;
    }
}
