package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.documents.FcmRegistrationTokenDocument;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenElasticService;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenService;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.mock.mockito.SpyBean;

@ExtendWith(MockitoExtension.class)
class FcmRegistrationTokenElasticFacadeImplTest {

    @InjectMocks
    private FcmRegistrationTokenElasticFacadeImpl fcmRegistrationTokenElasticFacade;

    @Mock
    private FcmRegistrationTokenService fcmRegistrationTokenService;

    @Mock
    private FcmRegistrationTokenElasticService fcmRegistrationTokenElasticService;

    @Mock
    private ModelMapper modelMapper;

    @Test
    void test_FindByFirebaseId_Should_ReturnFcmRegistrationTokenDocument_When_ReceivedUserValid()
        throws FcmRegistrationTokenException {

        FcmRegistrationTokenDocument fcmRegistrationTokenDocument = FcmRegistrationTokenDocument.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform("ios")
            .status(1)
            .build();

        when(fcmRegistrationTokenElasticService.findByFirebaseId(anyLong()))
            .thenReturn(Optional.of(fcmRegistrationTokenDocument));

        assertAll(() -> fcmRegistrationTokenElasticFacade.findByFirebaseId(1L));

        verify(fcmRegistrationTokenElasticService, times(1))
            .findByFirebaseId(anyLong());
    }


    @Test
    void test_FindByFirebaseId_Should_FindFcmRegistrationToken_When_ReceivedUserValid()
        throws FcmRegistrationTokenException {

        FcmRegistrationTokenDocument fcmRegistrationTokenDocument = FcmRegistrationTokenDocument.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform("ios")
            .status(1)
            .build();

        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenElasticService.findByFirebaseId(anyLong()))
            .thenReturn(Optional.empty());

        when(fcmRegistrationTokenService.findByFirebaseId(anyLong()))
            .thenReturn(fcmRegistrationToken);

        assertAll(() -> fcmRegistrationTokenElasticFacade.findByFirebaseId(1L));

        verify(fcmRegistrationTokenElasticService, times(1))
            .findByFirebaseId(anyLong());

        verify(fcmRegistrationTokenService, times(1))
            .findByFirebaseId(anyLong());
    }


    @Test
    void test_Save_Should_CreateFcmRegistrationToken_When_ReceivedFcmRegistrationTokenValid()
        throws JsonProcessingException, FcmRegistrationTokenException {

        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenService.findById(anyLong())).thenReturn(
            fcmRegistrationToken);

        doNothing().when(fcmRegistrationTokenElasticService).index(any(FcmRegistrationToken.class));

        assertAll(() -> fcmRegistrationTokenElasticFacade.indexByFcmRegistrationToken(1L));

        verify(fcmRegistrationTokenService, times(1)).findById(anyLong());

        verify(fcmRegistrationTokenElasticService, times(1))
            .index(any(FcmRegistrationToken.class));
    }

}
