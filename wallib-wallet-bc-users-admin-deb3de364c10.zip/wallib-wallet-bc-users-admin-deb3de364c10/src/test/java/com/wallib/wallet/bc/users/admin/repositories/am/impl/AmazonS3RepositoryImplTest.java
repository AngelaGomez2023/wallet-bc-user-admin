package com.wallib.wallet.bc.users.admin.repositories.am.impl;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AmazonS3RepositoryImplTest {

    @InjectMocks
    private AmazonS3RepositoryImpl amazonS3RepositoryImpl;

    @Mock
    private AmazonS3 amazonS3;
    
    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(amazonS3RepositoryImpl, "publicKeysBucketName", "wallib-develop-public");
        ReflectionTestUtils.setField(amazonS3RepositoryImpl, "privateKeysBucketName", "wallib-develop-private");
        ReflectionTestUtils.setField(amazonS3RepositoryImpl, "publicKeyExtension", ".pub");
        ReflectionTestUtils.setField(amazonS3RepositoryImpl, "privateKeyExtension", ".key");
    }

    @Test
    void test_UploadPublicKeyInputStreamToS3Bucket_Should_ReturnResult_When_ReceiveValidParam() throws IOException {

        PutObjectResult putObjectResult = null;

        lenient().when(amazonS3.putObject(any(PutObjectRequest.class))).thenReturn(putObjectResult);

        assertAll(() -> amazonS3RepositoryImpl.uploadPublicKeyInputStreamToS3Bucket(1L, getInputStream()));

        verify(amazonS3, times(1))
            .putObject(any(PutObjectRequest.class));
    }

    @Test
    void test_UploadPrivateKeyInputStreamToS3Bucket_Should_ReturnResult_When_ReceiveValidParam() throws IOException {

        PutObjectResult putObjectResult = null;

        lenient().when(amazonS3.putObject(any(PutObjectRequest.class))).thenReturn(putObjectResult);

        assertAll(() -> amazonS3RepositoryImpl.uploadPrivateKeyInputStreamToS3Bucket(1L, getInputStream()));

        verify(amazonS3, times(1))
            .putObject(any(PutObjectRequest.class));
    }

    public InputStream getInputStream(){
        return new ByteArrayInputStream("".getBytes());
    }
}
