package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.services.EventService;
import com.wallib.wallet.bc.users.admin.services.FcmRegistrationTokenService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FcmRegistrationTokenFacadeImplTest {

    @InjectMocks
    private FcmRegistrationTokenFacadeImpl fcmRegistrationTokenFacade;

    @Mock
    private FcmRegistrationTokenService fcmRegistrationTokenService;

    @Mock
    private EventService eventService;


    @Test
    void test_Save_Should_CreateFcmRegistrationToken_When_ReceivedFcmRegistrationTokenValid()
        throws JsonProcessingException, FcmRegistrationTokenException {

        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenService.save(any(FcmRegistrationToken.class)))
            .thenReturn(fcmRegistrationToken);

        assertAll(() -> fcmRegistrationTokenFacade.save(fcmRegistrationToken));

        verify(fcmRegistrationTokenService, times(1))
            .save(any(FcmRegistrationToken.class));
    }

}
