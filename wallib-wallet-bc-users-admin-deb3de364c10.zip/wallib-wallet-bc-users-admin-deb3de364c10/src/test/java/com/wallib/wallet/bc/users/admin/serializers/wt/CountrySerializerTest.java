package com.wallib.wallet.bc.users.admin.serializers.wt;

import static org.junit.jupiter.api.Assertions.assertAll;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CountrySerializerTest {

    @InjectMocks
    private CountrySerializer countrySerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Test
    void test_CountrySerializer_Should_Serialize_When_ReceiveValidCountry() {
        Country country = getCountry();
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());
        assertAll(() -> countrySerializer.serialize(country, jsonGenerator, serializerProvider));
    }

    @Test
    void test_CountrySerializer_Should_Serialize_When_ReceiveValidDeletedCountry() {
        Country country = getCountry();
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());
        country.setDeletedAt(LocalDateTime.now());
        assertAll(() -> countrySerializer.serialize(country, jsonGenerator, serializerProvider));
    }

    private Country getCountry() {
        Country country = Country.builder()
            .name("{}")
            .status(1)
            .isoCode("AA")
            .build();

        country.setId(1L);
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());

        return country;
    }
}
