package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserPinDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserPinRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import java.time.LocalDateTime;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserPinServiceImplTest {
    
    @InjectMocks
    private UserPinServiceImpl userPinService;

    @Mock
    private UserPinRepository userPinRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private AuditLogServiceImpl auditLogService;

    @Test
    void test_FindByUserIdMethod_Should_GetUserPin_When_ReceiveQueryParams() {
        UserPin userPin = getUserPin();
        when(userPinRepository.findByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(java.util.Optional.of(userPin));

        assertAll(() -> userPinService.findByUserId(1L));
        verify(userPinRepository, times(1))
            .findByUserIdAndDeletedAtIsNull(anyLong());
    }

    @Test
    void test_CreateMethod_Should_CreateUserPin_When_ReceiveValidObject() throws JsonProcessingException {
        UserPin userPin = getUserPin();

        when(userRepository.existsById(anyLong())).thenReturn(true);
        when(userPinRepository.existsByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(false);
        when(userPinRepository.save(any(UserPin.class))).thenReturn(userPin);
        doNothing().when(auditLogService).createAuditLog(any(UserPin.class));

        assertAll(() -> userPinService.create(userPin));

        verify(userRepository, times(1))
            .existsById(anyLong());
        verify(userPinRepository, times(1))
            .existsByUserIdAndDeletedAtIsNull(anyLong());
        verify(userPinRepository, times(1)).save(any(UserPin.class));
        verify(auditLogService, times(1)).createAuditLog(any(UserPin.class));
    }

    @Test
    void test_CreateMethod_Should_ThrowCountryServiceException_When_UserIdDoesNotExist() {
        UserPin userPin = getUserPin();

        when(userRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(UserPinServiceException.class,
            () -> userPinService.create(userPin));
    }

    @Test
    void test_CreateMethod_Should_ThrowCountryServiceException_When_UserDocumentIdDuplicated() {
        UserPin userPin = getUserPin();

        when(userRepository.existsById(anyLong())).thenReturn(true);
        when(userPinRepository.existsByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(true);

        assertThrows(UserPinServiceException.class,
            () -> userPinService.create(userPin));
    }

    @Test
    void test_UpdateMethod_Should_UpdateUserPin_When_ReceiveValidObject() throws JsonProcessingException {
        UserPin userPin = getUserPin();
        UpdateUserPinDTO updateUserPinDTO = getUpdateUserPinDTO();

        when(userPinRepository.findByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(java.util.Optional.of(userPin));
        when(userPinRepository.saveAndFlush(any(UserPin.class))).thenReturn(userPin);
        doNothing().when(auditLogService).updateAuditLog(any(UserPin.class), any(UserPin.class));

        assertAll(() -> userPinService.update(1L, updateUserPinDTO.getCurrentPin(), userPin));
        verify(userPinRepository, times(2))
            .findByUserIdAndDeletedAtIsNull(anyLong());
        verify(userPinRepository, times(1))
            .saveAndFlush(any(UserPin.class));
        verify(auditLogService, times(1))
            .updateAuditLog(any(UserPin.class), any(UserPin.class));
    }

    @Test
    void test_UpdateMethod_Should_ThrowEntityNotFoundException_When_UserDoesNotExist() {
        UserPin userPin = getUserPin();
        UpdateUserPinDTO updateUserPinDTO = getUpdateUserPinDTO();

        when(userPinRepository.findByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> userPinService.update(1L, updateUserPinDTO.getCurrentPin(), userPin));
    }

    @Test
    void test_UpdateMethod_Should_ThrowUserPinServiceException_When_UserAlreadyHasPin() {
        UserPin userPin = getUserPin();

        when(userPinRepository.findByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(java.util.Optional.of(userPin));

        assertThrows(UserPinServiceException.class,
            () -> userPinService.update(1L, "1236", userPin));
    }

    @Test
    void test_DeleteMethod_Should_DeleteUser_When_ReceiveValidId() {
        UserPin userPin = getUserPin();
        when(userPinRepository.findByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(java.util.Optional.of(userPin));
        doNothing().when(userPinRepository).delete(any(UserPin.class));

        assertAll(() -> userPinService.delete(1L));
        verify(userPinRepository, times(1))
            .findByUserIdAndDeletedAtIsNull(anyLong());
    }

    @Test
    void test_DeleteMethod_Should_ThrowEntityNotFoundException_When_UserDoesNotExist() {

        when(userPinRepository.findByUserIdAndDeletedAtIsNull(anyLong())).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class,
            () -> userPinService.delete(1L));
    }

    private UpdateUserPinDTO getUpdateUserPinDTO() {
        UpdateUserPinDTO updateUserPinDTO = UpdateUserPinDTO.builder()
            .userId(1L)
            .pin("1234")
            .currentPin("1234")
            .build();

        return updateUserPinDTO;
    }

    private UserPin getUserPin() {
        UserPin userPin = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        userPin.setId(1L);
        userPin.setCreatedAt(LocalDateTime.now());
        userPin.setUpdatedAt(LocalDateTime.now());

        return userPin;
    }
}
