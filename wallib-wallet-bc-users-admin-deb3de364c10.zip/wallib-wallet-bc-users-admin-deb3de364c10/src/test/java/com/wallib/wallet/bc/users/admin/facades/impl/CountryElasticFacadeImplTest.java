package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.services.CountryElasticService;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CountryElasticFacadeImplTest {
    
    @InjectMocks
    private CountryElasticFacadeImpl countryElasticFacade;

    @Mock
    private CountryService countryService;

    @Mock
    private CountryElasticService countryElasticService;

    @Test
    void test_IndexByCountry_Should_IndexCountry_When_ReceivedCountryValid()
        throws JsonProcessingException, CountryServiceException {
        when(countryService.findById(anyLong())).thenReturn(getCountry());

        assertAll(() -> countryElasticFacade.indexByCountry(1L));

        verify(countryService, times(1)).findById(anyLong());
    }

    private Country getCountry() {
        Country country = Country.builder()
            .name("{}")
            .status(1)
            .isoCode("AA")
            .build();

        country.setId(1L);
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());

        return country;
    }
}
