package com.wallib.wallet.bc.users.admin.serializers.wt;

import static org.junit.jupiter.api.Assertions.assertAll;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FcmRegistrationTokenSerializerTest {

    @InjectMocks
    private FcmRegistrationTokenSerializer fcmRegistrationTokenSerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Test
    void test_FcmRegistrationTokenSerializer_Should_Serialize_When_ReceiveValidFcmRegistrationToken() {
        FcmRegistrationToken fcmRegistrationToken = getFcmRegistrationToken();
        fcmRegistrationToken.setCreatedAt(LocalDateTime.now());
        fcmRegistrationToken.setUpdatedAt(LocalDateTime.now());
        assertAll(() -> fcmRegistrationTokenSerializer.serialize(fcmRegistrationToken, jsonGenerator, serializerProvider));
    }

    @Test
    void test_FcmRegistrationTokenSerializer_Should_Serialize_When_ReceiveDeleteFcmRegistrationToken() {
        FcmRegistrationToken fcmRegistrationToken = getFcmRegistrationToken();
        fcmRegistrationToken.setCreatedAt(LocalDateTime.now());
        fcmRegistrationToken.setUpdatedAt(LocalDateTime.now());
        fcmRegistrationToken.setDeletedAt(LocalDateTime.now());
        assertAll(() -> fcmRegistrationTokenSerializer.serialize(fcmRegistrationToken,
            jsonGenerator, serializerProvider));
    }

    private FcmRegistrationToken getFcmRegistrationToken() {
        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .token("TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        fcmRegistrationToken.setId(1L);
        fcmRegistrationToken.setCreatedAt(LocalDateTime.now());
        fcmRegistrationToken.setUpdatedAt(LocalDateTime.now());

        return fcmRegistrationToken;
    }
}
