package com.wallib.wallet.bc.users.admin.producers;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;

@ExtendWith(MockitoExtension.class)
class MessageProducerTest {

    @InjectMocks
    private MessageProducer messageProducer;

    @Mock
    private JmsTemplate jmsTemplate;

    @Test
    void test_SendToUserEvent_Should_ProduceMessage_When_ObjectIsReceived() {

        IndexEventDTO messageDTO = new IndexEventDTO();
        messageDTO.setAction("CREATED");
        messageDTO.setEntity("TEST");
        messageDTO.setEntityId(1L);

        doNothing().when(jmsTemplate)
            .convertAndSend(nullable(String.class), any(IndexEventDTO.class),
                any(MessagePostProcessor.class));

        messageProducer.sendToUserEvent(messageDTO);

        verify(jmsTemplate, times(1)).convertAndSend(nullable(String.class),
            any(IndexEventDTO.class), any(MessagePostProcessor.class));
    }

    @Test
    void test_SendToUserEvent_Should_ThrowError_When_JmsException() {

        IndexEventDTO messageDTO = new IndexEventDTO();
        messageDTO.setAction("CREATED");
        messageDTO.setEntity("TEST");
        messageDTO.setEntityId(1L);

        doThrow(new JmsException("test exception") {
        }).when(jmsTemplate)
            .convertAndSend(nullable(String.class), any(IndexEventDTO.class),
                any(MessagePostProcessor.class));

        assertThrows(JmsException.class,
            () -> messageProducer.sendToUserEvent(messageDTO));
    }

}

