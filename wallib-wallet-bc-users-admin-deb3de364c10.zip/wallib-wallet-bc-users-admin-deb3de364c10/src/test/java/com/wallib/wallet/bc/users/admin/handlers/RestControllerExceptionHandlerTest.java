package com.wallib.wallet.bc.users.admin.handlers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.wallib.wallet.bc.users.admin.dto.v1.ApiResponseDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.KeyPairServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.WalletUserRestException;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;

@ExtendWith(MockitoExtension.class)
class RestControllerExceptionHandlerTest {
    
    @InjectMocks
    private RestControllerExceptionHandler restControllerExceptionHandler;

    @Test
    void test_RestControllerExceptionHandler_Should_ConvertUserServiceException_When_Invoked() {
        //Arrange
        UserServiceException userServiceException = new UserServiceException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleUserService(userServiceException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getBody().getStatusCode());
        assertEquals("Bad Request", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_ConvertCountryServiceException_When_Invoked() {
        //Arrange
        CountryServiceException countryServiceException = new CountryServiceException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleCountryService(countryServiceException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getBody().getStatusCode());
        assertEquals("Bad Request", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_ConvertDocumentTypeServiceException_When_Invoked() {
        //Arrange
        DocumentTypeServiceException documentTypeServiceException = new DocumentTypeServiceException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleDocumentTypeService(documentTypeServiceException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getBody().getStatusCode());
        assertEquals("Bad Request", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_ConvertUserPinServiceException_When_Invoked() {
        //Arrange
        UserPinServiceException userPinServiceException = new UserPinServiceException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleUserPinServiceException(userPinServiceException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getBody().getStatusCode());
        assertEquals("Bad Request", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_KeyPairServiceException_When_Invoked() {
        //Arrange
        KeyPairServiceException keyPairServiceException = new KeyPairServiceException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleKeyPairServiceException(keyPairServiceException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getBody().getStatusCode());
        assertEquals("Bad Request", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_WalletUserRestException_When_Invoked() {
        //Arrange
        WalletUserRestException walletUserRestException = new WalletUserRestException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleWalletUserRestException(walletUserRestException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getBody().getStatusCode());
        assertEquals("Bad Request", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_RSAKeyPairException_When_Invoked() {
        //Arrange
        RSAKeyPairException rsaKeyPairException = new RSAKeyPairException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleKeyPairGenerationException(rsaKeyPairException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), exception.getBody().getStatusCode());
        assertEquals("Internal Server Error", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_AccessDeniedException_When_Invoked() {
        //Arrange
        AccessDeniedException accessDeniedException = new AccessDeniedException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleAccessDeniedException(
                accessDeniedException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.FORBIDDEN.value(), exception.getBody().getStatusCode());
        assertEquals("Forbidden", exception.getBody().getMessage());
    }

    @Test
    void test_RestControllerExceptionHandler_Should_EntityNotFoundException_When_Invoked() {
        //Arrange
        EntityNotFoundException entityNotFoundException = new EntityNotFoundException("Error");

        //Call
        ResponseEntity<ApiResponseDTO<Object>> exception =
            restControllerExceptionHandler.handleEntityNotFoundException(
                entityNotFoundException);

        //Asserts
        assertNotNull(exception.getBody());
        assertEquals(HttpStatus.NOT_FOUND.value(), exception.getBody().getStatusCode());
        assertEquals("Not Found", exception.getBody().getMessage());
    }
}
