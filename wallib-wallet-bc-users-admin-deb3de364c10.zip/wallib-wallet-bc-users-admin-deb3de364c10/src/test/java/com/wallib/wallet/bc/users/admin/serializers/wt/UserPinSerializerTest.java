package com.wallib.wallet.bc.users.admin.serializers.wt;

import static org.junit.jupiter.api.Assertions.assertAll;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserPinSerializerTest {
    
    @InjectMocks
    private UserPinSerializer userPinSerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Test
    void test_UserPinSerializer_Should_Serialize_When_ReceiveValidUserPin() {
        UserPin userPin = getUserPin();
        userPin.setCreatedAt(LocalDateTime.now());
        userPin.setUpdatedAt(LocalDateTime.now());
        assertAll(() -> userPinSerializer.serialize(userPin, jsonGenerator, serializerProvider));
    }

    @Test
    void test_UserSerializer_Should_Serialize_When_ReceiveValidDeletedUser() {
        UserPin userPin = getUserPin();
        userPin.setCreatedAt(LocalDateTime.now());
        userPin.setUpdatedAt(LocalDateTime.now());
        userPin.setDeletedAt(LocalDateTime.now());
        assertAll(() -> userPinSerializer.serialize(userPin, jsonGenerator, serializerProvider));
    }

    private UserPin getUserPin() {
        UserPin userPin = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        userPin.setId(1L);
        userPin.setCreatedAt(LocalDateTime.now());
        userPin.setUpdatedAt(LocalDateTime.now());

        return userPin;
    }
}
