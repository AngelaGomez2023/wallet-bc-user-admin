package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_COUNTRY_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_COUNTRY_ISO_CODE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_LANGUAGE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_LANGUAGE_ISO_CODE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_LANGUAGES;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.models.wt.Language;
import com.wallib.wallet.bc.users.admin.services.LanguageService;
import java.util.Collections;
import java.util.List;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = LanguageController.class)
class LanguageControllerTest extends CreateJWT {
    
    @MockBean
    private LanguageService languageService;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void test_List_Should_ReturnLanguageList_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(LIST_LANGUAGES);

        Language language = Language.builder()
            .id(1L)
            .name("{\"es\":\"Español\",\"en\":\"Spanish\",\"pt\":\"Spagnol\"}")
            .isoCode("TS")
            .status(1)
            .build();

        List<Language> languageList = Collections.singletonList(language);

        when(languageService.list()).thenReturn(languageList);

        this.mockMvc
            .perform(get("/v1/languages")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("status")));
    }

    @Test
    void test_FindById_Should_ReturnLanguage_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_LANGUAGE_ID);

        Language language = Language.builder()
            .id(1L)
            .name("{\"es\":\"Español\",\"en\":\"Spanish\",\"pt\":\"Spagnol\"}")
            .isoCode("TS")
            .status(1)
            .build();

        when(languageService.findById(anyLong())).thenReturn(language);

        this.mockMvc
            .perform(get("/v1/languages/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_FindByIsoCode_Should_ReturnLanguage_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_LANGUAGE_ISO_CODE);

        Language language = Language.builder()
            .id(1L)
            .name("{\"es\":\"Español\",\"en\":\"Spanish\",\"pt\":\"Spagnol\"}")
            .isoCode("es")
            .status(1)
            .build();

        when(languageService.findByIsoCode(anyString())).thenReturn(language);

        this.mockMvc
            .perform(get("/v1/languages?iso_code=es")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_Post_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(post("/v1/languages/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Put_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(put("/v1/languages/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }
}
