package com.wallib.wallet.bc.users.admin.controllers.v1;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_KEY_PAIR;

import com.wallib.wallet.bc.users.admin.domain.PublicKey;
import com.wallib.wallet.bc.users.admin.services.KeyPairService;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = KeyPairController.class)
class KeyPairsControllerTest extends CreateJWT {
    
    @MockBean
    private KeyPairService keyPairService;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Test
    void test_Create_Should_Return_CreatedUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(CREATE_KEY_PAIR);
        PublicKey publicKey = getPublicKey();

        when(keyPairService.create(anyLong())).thenReturn(publicKey);

        mockMvc
            .perform(post("/v1/keys/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isCreated())
        ;
    }

    @Test
    void test_Get_Should_Return405() throws Exception {

        String token = generateJWT(CREATE_KEY_PAIR);

        mockMvc
            .perform(get("/v1/keys/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isMethodNotAllowed())
        ;
    }

    @Test
    void test_Delete_Should_Return405() throws Exception {

        String token = generateJWT(CREATE_KEY_PAIR);

        mockMvc
            .perform(delete("/v1/keys/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isMethodNotAllowed())
        ;
    }
    
    @Test
    void test_Post_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(post("/v1/keys/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Put_Should_Return405_When_Token_IsNotValid() throws Exception {

        String token = generateJWT(CREATE_KEY_PAIR);

        this.mockMvc
            .perform(put("/v1/keys/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isMethodNotAllowed())
        ;
    }

    private PublicKey getPublicKey(){

        return PublicKey.builder()
            .userId(1L)
            .algorithm("RSA")
            .publicKey("public-key")
            .build();
    }
}
