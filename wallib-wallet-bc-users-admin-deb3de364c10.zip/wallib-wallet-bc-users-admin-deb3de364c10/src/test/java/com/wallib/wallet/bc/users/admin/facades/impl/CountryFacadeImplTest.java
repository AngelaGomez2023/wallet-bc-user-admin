package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import com.wallib.wallet.bc.users.admin.services.EventService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CountryFacadeImplTest {
    
    @InjectMocks
    private CountryFacadeImpl countryFacade;

    @Mock
    private CountryService countryService;

    @Mock
    private EventService eventService;

    @BeforeEach
    void setup() {
        doNothing().when(eventService).sendEventToQueue(anyString(), anyString(), anyLong());
    }

    @AfterEach
    void validate() {
        verify(eventService, times(1)).sendEventToQueue(anyString(), anyString(), anyLong());
    }

    @Test
    void test_Create_Should_CreateCountry_When_ReceivedCountryValid()
        throws JsonProcessingException, CountryServiceException {
        when(countryService.create(any(Country.class))).thenReturn(getCountry());

        assertAll(() -> countryFacade.create(getCountry()));

        verify(countryService, times(1)).create(any(Country.class));
    }

    @Test
    void test_Update_Should_UpdateCountry_When_ReceivedCountryValid()
        throws JsonProcessingException, CountryServiceException {

        Country country = getCountry();
        when(countryService.update(anyLong(), any(Country.class))).thenReturn(getCountry());

        assertAll(() -> countryFacade.update(country.getId(), country));

        verify(countryService, times(1)).update(anyLong(), any(Country.class));
    }

    @Test
    void test_Delete_Should_DeleteCountry_When_ReceivedIdValid()
        throws JsonProcessingException, CountryServiceException {

        doNothing().when(countryService).delete(anyLong());

        assertAll(() -> countryFacade.delete(1L));
        verify(countryService, times(1))
            .delete(anyLong());
    }


    private Country getCountry() {
        Country country = Country.builder()
            .name("{}")
            .status(1)
            .isoCode("AA")
            .build();

        country.setId(1L);
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());

        return country;
    }
}
