package com.wallib.wallet.bc.users.admin.serializers.wt;

import static org.junit.jupiter.api.Assertions.assertAll;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.wallib.wallet.bc.users.admin.models.wt.FirebaseAccount;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FirebaseAccountSerializerTest {

    @InjectMocks
    private FirebaseAccountSerializer firebaseAccountSerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Test
    void test_FirebaseAccountSerializer_Should_Serialize_When_ReceiveValidFirebaseAccount() {
        FirebaseAccount firebaseAccount = getFirebaseAccount();
        firebaseAccount.setCreatedAt(LocalDateTime.now());
        firebaseAccount.setUpdatedAt(LocalDateTime.now());
        assertAll(() -> firebaseAccountSerializer.serialize(firebaseAccount, jsonGenerator, serializerProvider));
    }

    @Test
    void test_FirebaseAccountSerializer_Should_Serialize_When_ReceiveDeleteFirebaseAccount() {
        FirebaseAccount firebaseAccount = getFirebaseAccount();
        firebaseAccount.setCreatedAt(LocalDateTime.now());
        firebaseAccount.setUpdatedAt(LocalDateTime.now());
        firebaseAccount.setDeletedAt(LocalDateTime.now());
        assertAll(() -> firebaseAccountSerializer.serialize(firebaseAccount, jsonGenerator,
            serializerProvider));
    }

    private FirebaseAccount getFirebaseAccount() {
        FirebaseAccount firebaseAccount = FirebaseAccount.builder()
            .firebaseId("id")
            .email("email@wallib.com")
            .firebaseCreatedAt(111L)
            .disabled(true)
            .displayName("Name")
            .emailVerified(true)
            .lastLoginAt(111L)
            .mfaInfo("mfa")
            .phoneNumber("phone")
            .providerUserInfo("user")
            .build();

        firebaseAccount.setId(1L);
        firebaseAccount.setCreatedAt(LocalDateTime.now());
        firebaseAccount.setUpdatedAt(LocalDateTime.now());

        return firebaseAccount;
    }
}
