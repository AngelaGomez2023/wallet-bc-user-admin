package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeElasticService;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentTypeElasticFacadeImplTest {
    
    @InjectMocks
    private DocumentTypeElasticFacadeImpl documentTypeElasticFacade;

    @Mock
    private DocumentTypeService documentTypeService;

    @Mock
    private DocumentTypeElasticService documentTypeElasticService;

    @Test
    void test_IndexByUser_Should_IndexUser_When_ReceivedUserValid()
        throws JsonProcessingException, DocumentTypeServiceException {
        when(documentTypeService.findById(anyLong())).thenReturn(getDocumentType());

        assertAll(() -> documentTypeElasticFacade.indexByDocumentType(1L));

        verify(documentTypeService, times(1)).findById(anyLong());
    }

    private DocumentType getDocumentType() {
        DocumentType documentType = DocumentType.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        documentType.setId(1L);
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());

        return documentType;
    }
}
