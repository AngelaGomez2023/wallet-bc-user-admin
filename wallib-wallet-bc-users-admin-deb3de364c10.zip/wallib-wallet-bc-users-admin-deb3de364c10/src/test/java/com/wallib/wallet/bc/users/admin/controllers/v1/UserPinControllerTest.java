package com.wallib.wallet.bc.users.admin.controllers.v1;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_USER_PIN;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_USER_PIN_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_USER_PIN;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_USER_PIN;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateUserPinDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserPinDTO;
import com.wallib.wallet.bc.users.admin.facades.UserPinFacade;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.UserPinService;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = UserPinController.class)
class UserPinControllerTest extends CreateJWT {
    
    @MockBean
    private UserPinService userPinService;

    @MockBean
    private UserPinFacade userPinFacade;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void test_FindById_Should_ReturnUserPin_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_USER_PIN_ID);

        UserPin userPin = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        when(userPinFacade.findByUserId(anyLong())).thenReturn(userPin);

        this.mockMvc
            .perform(get("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("pin")))
        ;
    }

    @Test
    void test_Create_Should_Return_CreatedUserPin_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(CREATE_USER_PIN);

        CreateUserPinDTO createUserPinDTO = CreateUserPinDTO.builder()
            .pin("1234")
            .build();

        String createUserPinJson = objectMapper.writeValueAsString(createUserPinDTO);

        UserPin userPin = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        when(userPinFacade.create(any(UserPin.class))).thenReturn(userPin);

        mockMvc
            .perform(post("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(createUserPinJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isCreated())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("pin")))
        ;
    }

    @Test
    void test_Update_Should_Return_UpdatedUserPin_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(UPDATE_USER_PIN);

        UpdateUserPinDTO updateUserPinDTO = UpdateUserPinDTO.builder()
            .userId(1L)
            .pin("1235")
            .currentPin("1234")
            .build();

        String updateUserPinJson = objectMapper.writeValueAsString(updateUserPinDTO);

        UserPin userPin = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        when(userPinFacade.update(anyLong(), anyString(), any(UserPin.class))).thenReturn(userPin);

        mockMvc
            .perform(put("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(updateUserPinJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isAccepted())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("pin")))
        ;
    }

    @Test
    void test_Delete_Should_Return_DeletedUserPin_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(DELETE_USER_PIN);

        doNothing().when(userPinFacade).delete(anyLong());

        mockMvc
            .perform(delete("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isNoContent())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
        ;
    }

    @Test
    void test_Get_Should_Return403_When_Permission_IsNotValid() throws Exception {

        String token = generateJWT("NONE");

        mockMvc
            .perform(get("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isForbidden())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(403))
            .andExpect(jsonPath("$.message").value("Forbidden"))
            .andExpect(jsonPath("$.error").value("Access is denied"))
        ;
    }

    @Test
    void test_Get_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(get("/v1/pins")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Post_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(post("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Put_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(put("/v1/pins/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }
}
