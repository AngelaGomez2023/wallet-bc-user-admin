package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.documents.CountryDocument;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.repositories.es.CountryDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CountryElasticServiceImplTest {
    
    @InjectMocks
    private CountryElasticServiceImpl countryElasticService;

    @Mock
    private CountryDocumentRepository countryDocumentRepository;

    @Mock
    private CountryRepository countryRepository;

    @Test
    void test_Index_Should_Return_IndexedCountry_When_ServiceIsCalled() throws Exception {

        when(countryDocumentRepository.save(any(CountryDocument.class))).thenAnswer(i -> i.getArgument(0));

        assertAll(() -> countryElasticService.index(getCountry()));

        verify(countryDocumentRepository, times(1)).save(any(CountryDocument.class));
    }

    private Country getCountry() {
        Country country = Country.builder()
            .name("{}")
            .status(1)
            .isoCode("AA")
            .build();

        country.setId(1L);
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());

        return country;
    }
}
