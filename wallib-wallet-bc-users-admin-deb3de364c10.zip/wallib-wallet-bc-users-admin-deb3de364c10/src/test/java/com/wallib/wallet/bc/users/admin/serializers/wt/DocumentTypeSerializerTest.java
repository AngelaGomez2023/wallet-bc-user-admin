package com.wallib.wallet.bc.users.admin.serializers.wt;

import static org.junit.jupiter.api.Assertions.assertAll;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentTypeSerializerTest {

    @InjectMocks
    private DocumentTypeSerializer documentTypeSerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Test
    void test_DocumentTypeSerializer_Should_Serialize_When_ReceiveValidDocumentType() {
        DocumentType documentType = getDocumentType();
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());
        assertAll(() -> documentTypeSerializer.serialize(documentType, jsonGenerator, serializerProvider));
    }

    @Test
    void test_DocumentTypeSerializer_Should_Serialize_When_ReceiveValidDeletedDocumentType() {
        DocumentType documentType = getDocumentType();
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());
        documentType.setDeletedAt(LocalDateTime.now());
        assertAll(() -> documentTypeSerializer.serialize(documentType, jsonGenerator, serializerProvider));
    }

    private DocumentType getDocumentType() {
        DocumentType documentType = DocumentType.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        documentType.setId(1L);
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());

        return documentType;
    }
}
