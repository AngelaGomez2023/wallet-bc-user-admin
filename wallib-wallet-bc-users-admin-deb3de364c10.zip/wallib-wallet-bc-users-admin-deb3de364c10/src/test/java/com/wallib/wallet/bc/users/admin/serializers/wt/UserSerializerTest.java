package com.wallib.wallet.bc.users.admin.serializers.wt;

import static org.junit.jupiter.api.Assertions.assertAll;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserSerializerTest {
    
    @InjectMocks
    private UserSerializer userSerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Test
    void test_UserSerializer_Should_Serialize_When_ReceiveValidUser() {
        User user = getUser();
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        assertAll(() -> userSerializer.serialize(user, jsonGenerator, serializerProvider));
    }

    @Test
    void test_UserSerializer_Should_Serialize_When_ReceiveValidDeletedUser() {
        User user = getUser();
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user.setDeletedAt(LocalDateTime.now());
        assertAll(() -> userSerializer.serialize(user, jsonGenerator, serializerProvider));
    }

    private User getUser() {
        User user = User.builder()
            .firebaseId(1L)
            .nickname("pedro")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }
}
