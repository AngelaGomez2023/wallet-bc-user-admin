package com.wallib.wallet.bc.users.admin.controllers.v1;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_DOCUMENT_TYPE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_DOCUMENT_TYPES;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_DOCUMENT_TYPE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_DOCUMENT_TYPE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_DOCUMENT_TYPE;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateDocumentTypeDTO;
import com.wallib.wallet.bc.users.admin.facades.DocumentTypeFacade;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;
import java.util.Collections;
import java.util.List;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = DocumentTypeController.class)
class DocumentTypeControllerTest extends CreateJWT {
    
    @MockBean
    private DocumentTypeService documentTypeService;

    @MockBean
    private DocumentTypeFacade documentTypeFacade;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void test_List_Should_ReturnDocuemntTypeList_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(LIST_DOCUMENT_TYPES);

        DocumentType documentType = DocumentType.builder()
            .id(1L)
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        List<DocumentType> documentTypeList = Collections.singletonList(documentType);

        when(documentTypeService.list()).thenReturn(documentTypeList);

        this.mockMvc
            .perform(get("/v1/documentTypes")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("status")));
    }

    @Test
    void test_FindById_Should_ReturnDocumentType_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_DOCUMENT_TYPE_ID);

        DocumentType documentType = DocumentType.builder()
            .id(1L)
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        when(documentTypeService.findById(anyLong())).thenReturn(documentType);

        this.mockMvc
            .perform(get("/v1/documentTypes/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("status")));
        ;
    }

    @Test
    void test_Create_Should_Return_CreatedCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(CREATE_DOCUMENT_TYPE);

        CreateDocumentTypeDTO createDocumentTypeDTO = CreateDocumentTypeDTO.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();
            
        String createDocumentTypeJson = objectMapper.writeValueAsString(createDocumentTypeDTO);

        DocumentType documentType = DocumentType.builder()
            .id(1L)
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        when(documentTypeFacade.create(any(DocumentType.class))).thenReturn(documentType);

        mockMvc
            .perform(post("/v1/documentTypes")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(createDocumentTypeJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isCreated())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("status")));
        ;
    }

    @Test
    void test_Update_Should_Return_UpdatedCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(UPDATE_DOCUMENT_TYPE);

        UpdateDocumentTypeDTO createDocumentTypeDTO = UpdateDocumentTypeDTO.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();
            
        String updateDocumentTypeJson = objectMapper.writeValueAsString(createDocumentTypeDTO);

        DocumentType documentType = DocumentType.builder()
            .id(1L)
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        when(documentTypeFacade.update(anyLong(), any(DocumentType.class))).thenReturn(documentType);

        mockMvc
            .perform(put("/v1/documentTypes/1")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(updateDocumentTypeJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isAccepted())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("status")));
        ;
    }

    @Test
    void test_Delete_Should_Return_DeletedDocumentType_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(DELETE_DOCUMENT_TYPE);

        doNothing().when(documentTypeFacade).delete(anyLong());

        mockMvc
            .perform(delete("/v1/documentTypes/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isNoContent())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
        ;
    }

    @Test
    void test_Get_Should_Return403_When_Permission_IsNotValid() throws Exception {

        String token = generateJWT("NONE");

        mockMvc
            .perform(get("/v1/documentTypes")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isForbidden())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(403))
            .andExpect(jsonPath("$.message").value("Forbidden"))
            .andExpect(jsonPath("$.error").value("Access is denied"))
        ;
    }

    @Test
    void test_Get_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(get("/v1/documentTypes")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Post_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(post("/v1/documentTypes/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Put_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(put("/v1/documentTypes/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }
}
