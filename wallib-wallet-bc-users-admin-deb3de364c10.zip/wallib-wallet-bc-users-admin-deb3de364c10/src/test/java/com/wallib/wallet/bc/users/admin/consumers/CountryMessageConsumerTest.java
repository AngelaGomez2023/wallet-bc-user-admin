package com.wallib.wallet.bc.users.admin.consumers;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import javax.persistence.EntityNotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.CountryServiceException;
import com.wallib.wallet.bc.users.admin.facades.CountryElasticFacade;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.junit.jupiter.api.Test;

@ExtendWith(MockitoExtension.class)
class CountryMessageConsumerTest {
    
    @InjectMocks
    private CountryMessageConsumer countryMessageConsumer;

    @Mock
    private CountryElasticFacade countryElasticFacade;

    @Test
    void test_ReceiveCountryMessage_Should_IndexCountryDocument_When_CountryExists()
        throws CountryServiceException, JsonProcessingException {
        doNothing().when(countryElasticFacade).indexByCountry(anyLong());

        assertAll(() -> countryMessageConsumer.receiveCountryMessage(getIndexEventDto()));

        verify(countryElasticFacade, times(1)).indexByCountry(anyLong());
    }

    @Test
    void test_ReceiveCountryMessage_Should_ThrowEntityNotFoundException_When_CountryDoesNotExist()
        throws CountryServiceException, JsonProcessingException {
        doThrow(new EntityNotFoundException()).when(countryElasticFacade).indexByCountry(anyLong());

        assertThrows(EntityNotFoundException.class,
            () -> countryMessageConsumer.receiveCountryMessage(getIndexEventDto()));

        verify(countryElasticFacade, times(1)).indexByCountry(anyLong());
    }

    @Test
    void test_ReceiveCountryMessage_Should_ThrowRuntimeException_When_IndexingFails()
        throws CountryServiceException, JsonProcessingException {
        doThrow(new RuntimeException()).when(countryElasticFacade).indexByCountry(anyLong());

        assertThrows(RuntimeException.class,
            () -> countryMessageConsumer.receiveCountryMessage(getIndexEventDto()));

        verify(countryElasticFacade, times(1)).indexByCountry(anyLong());
    }

    @Test
    void test_ReceiveCountryMessage_Should_ThrowCountryServiceException_When_IndexingFails()
        throws CountryServiceException, JsonProcessingException {
        doThrow(new CountryServiceException("")).when(countryElasticFacade).indexByCountry(anyLong());

        assertThrows(CountryServiceException.class,
            () -> countryMessageConsumer.receiveCountryMessage(getIndexEventDto()));

        verify(countryElasticFacade, times(1)).indexByCountry(anyLong());
    }

    private IndexEventDTO getIndexEventDto(){
        return IndexEventDTO.builder()
            .action("CREATE")
            .entity("USER")
            .entityId(1L)
            .build();
    }
}
