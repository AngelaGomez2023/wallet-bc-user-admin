package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mockStatic;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.KeyPairServiceException;
import com.wallib.wallet.bc.users.admin.exceptions.WalletUsersListExceptions.RSAKeyPairException;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.am.impl.AmazonS3RepositoryImpl;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import com.wallib.wallet.bc.users.admin.utils.KeyPairUtils;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import lombok.extern.slf4j.Slf4j;
import org.mockito.MockedStatic;

@Slf4j
@ExtendWith(MockitoExtension.class)
class KeyPairServiceImplTest {
    
    @InjectMocks
    private KeyPairServiceImpl keyPairService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private AmazonS3RepositoryImpl amazonS3RepositoryImpl;

    @Test
    void test_CreateMethod_Should_CreateKeyPair_When_ReceiveValidObject() throws JsonProcessingException {

        User user = getUser();

        try{

            when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
            when(amazonS3RepositoryImpl.uploadPrivateKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class))).thenReturn("");
            when(amazonS3RepositoryImpl.uploadPublicKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class))).thenReturn("");

            assertAll(() -> keyPairService.create(1L));

            verify(userRepository, times(1))
                .findById(anyLong());
            verify(amazonS3RepositoryImpl, times(1))
                .uploadPrivateKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class));
            verify(amazonS3RepositoryImpl, times(1))
                .uploadPublicKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class));
        }
        catch(IOException e){
            log.trace("Test failed due to unknown error");
            log.error(e.toString());
        }
    }

    @Test
    void test_CreateMethod_Should_ThrowEntityNotFoundException_When_UserIdDoesNotExist() {

        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> keyPairService.create(1L));
    }

    @Test
    void test_CreateMethod_Should_ThrowKeyPairServiceException_When_KeysNotGenerated() throws KeyPairServiceException {

        try(MockedStatic<KeyPairUtils> mocked = mockStatic(KeyPairUtils.class);){

            User user = getUser();
            when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
            mocked.when(() -> KeyPairUtils.generateRSAKeyPair(anyString())).thenThrow(RSAKeyPairException.class);

            assertThrows(KeyPairServiceException.class, () -> keyPairService.create(1L));
        }
    }

    @Test
    void test_CreateMethod_Should_ThrowKeyPairServiceException_When_PublicKeyInputStreamNotGenerated() throws KeyPairServiceException, RSAKeyPairException {
        
        User user = getUser();
        KeyPair keyPair = getKeyPair();

        try(MockedStatic<KeyPairUtils> mocked = mockStatic(KeyPairUtils.class);){

            when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
            mocked.when(() -> KeyPairUtils.generateRSAKeyPair(anyString())).thenReturn(keyPair);
            mocked.when(() -> KeyPairUtils.generatePublicKeyInputStream(anyLong(), any(PublicKey.class))).thenThrow(RSAKeyPairException.class);

            assertThrows(KeyPairServiceException.class, () -> keyPairService.create(1L));
        }
    }

    @Test
    void test_CreateMethod_Should_ThrowKeyPairServiceException_When_PrivateKeyInputStreamNotGenerated() throws KeyPairServiceException, RSAKeyPairException {
        
        User user = getUser();
        KeyPair keyPair = getKeyPair();
        InputStream publicKeyInputStream = getPublicKeyInputStream();

        try(MockedStatic<KeyPairUtils> mocked = mockStatic(KeyPairUtils.class);){

            when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
            mocked.when(() -> KeyPairUtils.generateRSAKeyPair(anyString())).thenReturn(keyPair);
            mocked.when(() -> KeyPairUtils.generatePublicKeyInputStream(anyLong(), any(PublicKey.class))).thenReturn(publicKeyInputStream);
            mocked.when(() -> KeyPairUtils.generatePrivateKeyInputStream(anyLong(), any(PrivateKey.class))).thenThrow(RSAKeyPairException.class);

            assertThrows(KeyPairServiceException.class, () -> keyPairService.create(1L));
        }
    }

    @Test
    void test_CreateMethod_Should_ThrowIOException_When_PublicKeyInputStreamNotUploaded() throws RSAKeyPairException, KeyPairServiceException, IOException {
        
        User user = getUser();
        KeyPair keyPair = getKeyPair();
        InputStream publicKeyInputStream = getPublicKeyInputStream();
        InputStream privateKeyInputStream = getPrivateKeyInputStream();

        try(MockedStatic<KeyPairUtils> mocked = mockStatic(KeyPairUtils.class);){

            when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
            mocked.when(() -> KeyPairUtils.generateRSAKeyPair(anyString())).thenReturn(keyPair);
            mocked.when(() -> KeyPairUtils.generatePublicKeyInputStream(anyLong(), any(PublicKey.class))).thenReturn(publicKeyInputStream);
            mocked.when(() -> KeyPairUtils.generatePrivateKeyInputStream(anyLong(), any(PrivateKey.class))).thenReturn(privateKeyInputStream);
            when(amazonS3RepositoryImpl.uploadPublicKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class))).thenThrow(IOException.class);
            // when(amazonS3RepositoryImpl.uploadPublicKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class))).thenReturn("Ok");
            
            assertThrows(KeyPairServiceException.class, () -> keyPairService.create(1L));
        }
    }

    @Test
    void test_CreateMethod_Should_ThrowIOException_When_PrivateKeyInputStreamNotUploaded() throws RSAKeyPairException, KeyPairServiceException, IOException {
        
        User user = getUser();
        KeyPair keyPair = getKeyPair();
        InputStream publicKeyInputStream = getPublicKeyInputStream();
        InputStream privateKeyInputStream = getPrivateKeyInputStream();

        try(MockedStatic<KeyPairUtils> mocked = mockStatic(KeyPairUtils.class);){

            when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
            mocked.when(() -> KeyPairUtils.generateRSAKeyPair(anyString())).thenReturn(keyPair);
            mocked.when(() -> KeyPairUtils.generatePublicKeyInputStream(anyLong(), any(PublicKey.class))).thenReturn(publicKeyInputStream);
            mocked.when(() -> KeyPairUtils.generatePrivateKeyInputStream(anyLong(), any(PrivateKey.class))).thenReturn(privateKeyInputStream);
            when(amazonS3RepositoryImpl.uploadPublicKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class))).thenReturn("Ok");
            when(amazonS3RepositoryImpl.uploadPrivateKeyInputStreamToS3Bucket(anyLong(), any(InputStream.class))).thenThrow(IOException.class);
            
            assertThrows(KeyPairServiceException.class, () -> keyPairService.create(1L));
        }
    }

    private User getUser() {
        User user = User.builder()
            .firebaseId(1L)
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }

    private KeyPair getKeyPair() throws RSAKeyPairException{
        return KeyPairUtils.generateRSAKeyPair("RSA");
    }

    private InputStream getPublicKeyInputStream() throws RSAKeyPairException{
        return KeyPairUtils.generatePublicKeyInputStream(1, getKeyPair().getPublic());
    }

    private InputStream getPrivateKeyInputStream() throws RSAKeyPairException{
        return KeyPairUtils.generatePrivateKeyInputStream(1, getKeyPair().getPrivate());
    }
}
