package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.models.wt.Language;
import com.wallib.wallet.bc.users.admin.repositories.wt.LanguageRepository;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LanguageServiceImplTest {
    
    @InjectMocks
    private LanguageServiceImpl languageService;

    @Mock
    private LanguageRepository languageRepository;

    @Test
    void test_ListMethod_Should_ListCountries_When_CallService() {
        Language language = getLanguage();
        when(languageRepository.findAll()).thenReturn(Collections.singletonList(language));

        assertAll(() -> languageService.list());
        verify(languageRepository, times(1)).findAll();
    }

    @Test
    void test_FindByIdMethod_Should_GetLanguage_When_ReceiveQueryParams() {
        Language language = getLanguage();
        when(languageRepository.findById(anyLong())).thenReturn(Optional.of(language));

        assertAll(() -> languageService.findById(1L));
        verify(languageRepository, times(1)).findById(anyLong());
    }

    @Test
    void test_FindByIsoCodeMethod_Should_GetLanguage_When_ReceiveQueryParams() {
        Language language = getLanguage();
        when(languageRepository.findByIsoCodeAndDeletedAtIsNull(anyString())).thenReturn(Optional.of(language));

        assertAll(() -> languageService.findByIsoCode("CO"));
        
        verify(languageRepository, times(1))
            .findByIsoCodeAndDeletedAtIsNull(anyString());
    }

    @Test
    void test_FindByIdMethod_Should_ThrowEntityNotFoundException_When_LanguageDoesNotExist() {

        when(languageRepository.findById(anyLong())).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class,
            () -> languageService.findById(1L));
    }

    @Test
    void test_FindByIsoCodeMethod_Should_ThrowEntityNotFoundException_When_LanguageDoesNotExist() {

        when(languageRepository.findByIsoCodeAndDeletedAtIsNull(anyString()))
            .thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class,
            () -> languageService.findByIsoCode("es"));
    }

    private Language getLanguage() {
        Language language = Language.builder()
            .name("{}")
            .status(1)
            .isoCode("es")
            .build();

        language.setId(1L);
        language.setCreatedAt(LocalDateTime.now());
        language.setUpdatedAt(LocalDateTime.now());

        return language;
    }
}
