package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.services.DocumentTypeService;
import com.wallib.wallet.bc.users.admin.services.EventService;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.time.LocalDateTime;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentTypeFacadeImplTest {
    
    @InjectMocks
    private DocumentTypeFacadeImpl documentTypeFacade;

    @Mock
    private DocumentTypeService documentTypeService;

    @Mock
    private EventService eventService;

    @BeforeEach
    void setup() {
        doNothing().when(eventService).sendEventToQueue(anyString(), anyString(), anyLong());
    }

    @AfterEach
    void validate() {
        verify(eventService, times(1)).sendEventToQueue(anyString(), anyString(), anyLong());
    }

    @Test
    void test_Create_Should_CreateDocumentType_When_ReceivedDocumentTypeValid()
        throws JsonProcessingException, DocumentTypeServiceException {
        when(documentTypeService.create(any(DocumentType.class))).thenReturn(getDocumentType());

        assertAll(() -> documentTypeFacade.create(getDocumentType()));

        verify(documentTypeService, times(1)).create(any(DocumentType.class));
    }

    @Test
    void test_Update_Should_UpdateDocumentType_When_ReceivedDocumentTypeValid()
        throws JsonProcessingException, DocumentTypeServiceException {

        DocumentType documentType = getDocumentType();
        when(documentTypeService.update(anyLong(), any(DocumentType.class))).thenReturn(getDocumentType());

        assertAll(() -> documentTypeFacade.update(documentType.getId(), documentType));

        verify(documentTypeService, times(1)).update(anyLong(), any(DocumentType.class));
    }

    @Test
    void test_Delete_Should_DeleteDocumentType_When_ReceivedIdValid()
        throws JsonProcessingException, DocumentTypeServiceException {

        doNothing().when(documentTypeService).delete(anyLong());

        assertAll(() -> documentTypeFacade.delete(1L));
        verify(documentTypeService, times(1))
            .delete(anyLong());
    }

    private DocumentType getDocumentType() {
        DocumentType documentType = DocumentType.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        documentType.setId(1L);
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());

        return documentType;
    }
}
