package com.wallib.wallet.bc.users.admin.consumers;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserPinRedisFacade;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserPinConsumerTest {
    
    @InjectMocks
    private UserPinMessageConsumer userPinMessageConsumer;

    @Mock
    private UserPinRedisFacade userPinRedisFacade;

    @Test
    void test_ReceiveUserPinMessage_Should_CacheUserPin_When_UserPinExists()
        throws UserPinServiceException, JsonProcessingException {
        doNothing().when(userPinRedisFacade).indexByUserPin(anyLong());

        assertAll(() -> userPinMessageConsumer.receiveUserPinMessage(getIndexEventDto()));

        verify(userPinRedisFacade, times(1)).indexByUserPin(anyLong());
    }

    @Test
    void test_ReceiveUserPinMessage_Should_ThrowEntityNotFoundException_When_UserPinDoesNotExist()
        throws UserPinServiceException, JsonProcessingException {
        doThrow(new EntityNotFoundException()).when(userPinRedisFacade).indexByUserPin(anyLong());

        assertThrows(EntityNotFoundException.class,
            () -> userPinMessageConsumer.receiveUserPinMessage(getIndexEventDto()));

        verify(userPinRedisFacade, times(1)).indexByUserPin(anyLong());
    }

    @Test
    void test_ReceiveUserPinMessage_Should_ThrowRuntimeException_When_CachingFails()
        throws UserPinServiceException, JsonProcessingException {
        doThrow(new RuntimeException()).when(userPinRedisFacade).indexByUserPin(anyLong());

        assertThrows(RuntimeException.class,
            () -> userPinMessageConsumer.receiveUserPinMessage(getIndexEventDto()));

        verify(userPinRedisFacade, times(1)).indexByUserPin(anyLong());
    }

    @Test
    void test_ReceiveUserPinMessage_Should_ThrowUserPinServiceException_When_IndexingFails()
        throws UserPinServiceException, JsonProcessingException {
        doThrow(new UserPinServiceException("")).when(userPinRedisFacade).indexByUserPin(anyLong());

        assertThrows(UserPinServiceException.class,
            () -> userPinMessageConsumer.receiveUserPinMessage(getIndexEventDto()));

        verify(userPinRedisFacade, times(1)).indexByUserPin(anyLong());
    }

    private IndexEventDTO getIndexEventDto(){
        return IndexEventDTO.builder()
            .action("CREATE")
            .entity("USER_PIN")
            .entityId(1L)
            .build();
    }
}
