package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.documents.DocumentTypeDocument;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.repositories.es.DocumentTypeDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentTypeElasticServiceImplTest {

    @InjectMocks
    private DocumentTypeElasticServiceImpl documentTypeElasticService;

    @Mock
    private DocumentTypeDocumentRepository documentTypeDocumentRepository;

    @Mock
    private CountryRepository countryRepository;

    @Test
    void test_Index_Should_Return_IndexedDocumentType_When_ServiceIsCalled() throws Exception {

        Country country = Country.builder()
            .name("Name")
            .id(1L)
            .build();

        when(countryRepository.findById(anyLong())).thenReturn(Optional.of(country));
        when(documentTypeDocumentRepository.save(any(DocumentTypeDocument.class))).thenAnswer(i -> i.getArgument(0));

        assertAll(() -> documentTypeElasticService.index(getDocumentType()));

        verify(countryRepository, times(1))
            .findById(anyLong());
        verify(documentTypeDocumentRepository, times(1)).save(any(DocumentTypeDocument.class));

    }

    @Test
    void test_Index_Should_Return_ThrowDocumentTypeServiceException_When_CountryIsNull() throws Exception {

        when(countryRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(DocumentTypeServiceException.class, () -> documentTypeElasticService.index(getDocumentType()));

        verify(countryRepository, times(1)).findById(anyLong());

    }
    
    private DocumentType getDocumentType() {
        DocumentType documentType = DocumentType.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        documentType.setId(1L);
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());

        return documentType;
    }
}
