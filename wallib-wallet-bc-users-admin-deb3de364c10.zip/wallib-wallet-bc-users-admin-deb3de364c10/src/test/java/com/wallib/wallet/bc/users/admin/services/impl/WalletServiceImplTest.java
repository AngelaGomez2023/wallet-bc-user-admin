package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.domain.WalletPassphrase;
import com.wallib.wallet.bc.users.admin.dto.v1.SaveWalletCustodialInfoDTO;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.am.AmazonS3Repository;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class WalletServiceImplTest {

    @InjectMocks
    private WalletServiceImpl walletService;

    @Mock
    private AmazonS3Repository amazonS3Repository;

    @Test
    void test_GetPassphraseMethod_Should_GetPassphrase_When_ReceivePathParams() throws IOException {

        String privateKey = """
                -----BEGIN PRIVATE KEY-----
                MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDebLHNwOniXEIO
                +HcoRIqMrsTvJXEvRaTm0aXxZsqHbt77cYSs4u3ezbajM+fIkvBVpL/s4OCBBrja
                +rb+OPnn+6A1BHXnjnF0v8y5M//+uSK274Pydi9WER13LhUR57rgs/AnP+ekhyRY
                yAPDXa/KbIioWHBiK6CQYffs1sgyLfmowNOxRdeLTmRW6VOQDQy0MXB6kr+3i518
                p5VRM8GXrv5b7+fNVGhtf8N+9TtSkj7/mQ1p5qyg1oEO/2P78Y0SslbMTSUQdXLB
                0A18q6rZ83gOS0056h8cbktZZBUi91FGoKUfAlE2Z7RgSvLJYRk+CuFIhIAN7Bqc
                qFTz4jjrAgMBAAECggEAPyiLNps0bp/27AxWvZr04qzP4/50TNGQWTCn18vx75Im
                hCzAWV1Y4T71wRMAmp5K227cRtW2Oj0f6aJuqvKf1+VGITfiiP2ULuw1pFNlOj30
                4xBRHdy8ZUqX3Ns7hWmRUbQWmfaV/syXIBSvqN6mB6tZBMCULPQpdEY1Yc29bC3F
                YSohtiiYl+XNvWqcMoKSWv6AR6pP4QicGtwUUsoWXQq9oKQUWbYTcXgRb8h3ZOVh
                KJp/osYwcCPgFGDi7i6VPUjAua7IBCer4soij6lqOtP2Wktsx/56HBPf6ujq5Xqf
                UPWJq9uaOstZPwkwsU8zC3g9EfbPh0U8ykGA8ur4XQKBgQDqxeEV6HCqokIq3wYi
                MdX4BHmZD3bALUglsDHvJCWTF7oj81GwtY1zGCTVrX1AHGEBkn7hxi+UGPTtv0R2
                pOW1eFoW7K20+7Qm7lPOQUFNMG1QC7acH6bydnwvLOcXel0lR7Ckd2sopdYIou96
                x9xUYgAz8j/Xbashdvuk8RF+BwKBgQDyiP8NenHGZcrWnlo7f3s5nVWsA74OFvGU
                vFdlcKteAX4HoKwtlw82NwWrAyM2OoWX8ZFFLK7xNd4zvDo9DPX9wFOH6rCTWLWM
                MyWsTXia8ZWaLYuQOdKsSxIya74U/avw6vVU1OL2RAxCtgaoRvZmIy3aCSF4Sq2p
                bcgZ7Db0/QKBgHnYOwpguWCFl6uiVg+XJ8JxqB48/Ved6KzOtgu0CeA+VzfjR0lb
                4E6UgEF5qeCFGf9z5XANqJHHJg7hzol46VL2ZGMzcK/WVlhCJrKMAXUrJgB+I8cB
                UmbSAX+GYWU493CqtU2WQMI2109iKMHjSkFtH0fWeTW4UDGtC8s95eMvAoGAYqd7
                J95gnVUWlwo+pekLFLp8+MVk75JBnkCmRCr6afitbSjcIIdLtr/W3GMgVZSkdtPa
                RYsRdih1RBISlnbJMPikgarjPGxfHLJJZrb0kgIm2logZQBAQ7kdo8jTvvIYmJza
                QjF+SLIRUql8N8L1w0IYCpKgPLATx9FSDclZ6XkCgYEAk759LTo+e6or9A29obe3
                usl4ze7c1PUq5ORVESjE2N7PlXznD2fJQtl8n8w4q6qM6oNYG1PmKNrkaSHh8fXy
                AbjVWgRxlQBe2/dn/NZRVWbNRgzTTnXGRCPnyzK2yREyoOKX+ntNy57qDRKaHKZL
                4lhYpIsIz0wuohXSVsv7z50=
                -----END PRIVATE KEY-----""";

        when(amazonS3Repository.getPrivateKeyFromS3Bucket(anyLong())).thenReturn(privateKey);

        when(amazonS3Repository.getPassphraseFromS3Bucket(anyString())).thenReturn("EIHgORJ+cWFQ37F3rWNWUOh00bi8OCcexNK88V3AZQ4V0VoSKeLfPImzgk85vCMoKnnY5cPAqArTeFsZqaEEDw+a8HGb2xW9BWe4sYLcVFgNdl52dElpW8OCFQnvIDEMfiwAcWMzw+U+y8dtOJU2AuAQFFz2afzRt3iaTO6IoPxH0155OIpfilO0JJtXh+yu7lrATru/gWF5/2Vx0eIJMWLycyyp2flqO/hu0iDYW3S4LKmqHWaBsrNrxoq+/WJFdIXVLr0SIUIe8iOWqyiibSOC99STrETYyGr4TnK0UyAFqkUMwQEccAMFUUud9LoqXbEo5Nupqs6YvCCeg8u9sw==");

        assertAll(() -> walletService.getPassphrase("wallet", 1L));

        verify(amazonS3Repository, times(1))
            .getPassphraseFromS3Bucket(anyString());

        verify(amazonS3Repository, times(1))
            .getPrivateKeyFromS3Bucket(anyLong());
    }

    @Test
    void test_ProcessCustodialKeys_Should_GetPassphrase_When_ReceiveBrokerMessage() throws IOException {

        SaveWalletCustodialInfoDTO saveWalletCustodialInfoDTO = SaveWalletCustodialInfoDTO.builder()
            .userId(1L)
            .walletNumber("wallet")
            .passphrase("passphrase")
            .phrase("a b c")
            .build();

        when(amazonS3Repository.getPublicKeyFromS3Bucket(anyLong())).thenReturn("-----BEGIN PUBLIC KEY-----\n"
            + "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmM4yTGkJDnoe7CDCyH67\n"
            + "JXPN7yGXfxWX6ciqEYMb1XWLO5KOQ/r/FvswgcrlOCXHB+R1hFEB3j7saz0txjKO\n"
            + "Res+ngTGC+onL07AKC0lgZaKlyvdlw8b+ZVIQvn6/ROFaX9IULj81D4ZmIPCec8M\n"
            + "XNmZ2OurRVqfIO/9NBehRWbxxGnmaV8Q/4P9sT5Hcp33hcy7Dt9ao4HHb6mqLUyl\n"
            + "rUGBySbDskVpHXdk+LHlw3gZYVwNv0PVffINfV+dJIa5+8EIDeDV/5sRVzu6sei3\n"
            + "RjQiVtVBk7qRVMIYTTARx3HgOA5fadpS5TfKR7tT7I3VwEaOpZA+A6crmIX7mviQ\n"
            + "SQIDAQAB\n"
            + "-----END PUBLIC KEY-----");

        when(amazonS3Repository.uploadFileToS3Bucket(anyString(), any(), anyInt())).thenReturn("filename");

        assertAll(() -> walletService.processCustodialKeys(saveWalletCustodialInfoDTO));

        verify(amazonS3Repository, times(1))
            .getPublicKeyFromS3Bucket(anyLong());

        verify(amazonS3Repository, times(2))
            .uploadFileToS3Bucket(anyString(), any(), anyInt());

    }

    @Test
    void test_GetSeedWordsMethod_Should_GetPSeedWords_When_ReceivePathParams() throws IOException {

        String privateKey = """
                -----BEGIN PRIVATE KEY-----
                MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDebLHNwOniXEIO
                +HcoRIqMrsTvJXEvRaTm0aXxZsqHbt77cYSs4u3ezbajM+fIkvBVpL/s4OCBBrja
                +rb+OPnn+6A1BHXnjnF0v8y5M//+uSK274Pydi9WER13LhUR57rgs/AnP+ekhyRY
                yAPDXa/KbIioWHBiK6CQYffs1sgyLfmowNOxRdeLTmRW6VOQDQy0MXB6kr+3i518
                p5VRM8GXrv5b7+fNVGhtf8N+9TtSkj7/mQ1p5qyg1oEO/2P78Y0SslbMTSUQdXLB
                0A18q6rZ83gOS0056h8cbktZZBUi91FGoKUfAlE2Z7RgSvLJYRk+CuFIhIAN7Bqc
                qFTz4jjrAgMBAAECggEAPyiLNps0bp/27AxWvZr04qzP4/50TNGQWTCn18vx75Im
                hCzAWV1Y4T71wRMAmp5K227cRtW2Oj0f6aJuqvKf1+VGITfiiP2ULuw1pFNlOj30
                4xBRHdy8ZUqX3Ns7hWmRUbQWmfaV/syXIBSvqN6mB6tZBMCULPQpdEY1Yc29bC3F
                YSohtiiYl+XNvWqcMoKSWv6AR6pP4QicGtwUUsoWXQq9oKQUWbYTcXgRb8h3ZOVh
                KJp/osYwcCPgFGDi7i6VPUjAua7IBCer4soij6lqOtP2Wktsx/56HBPf6ujq5Xqf
                UPWJq9uaOstZPwkwsU8zC3g9EfbPh0U8ykGA8ur4XQKBgQDqxeEV6HCqokIq3wYi
                MdX4BHmZD3bALUglsDHvJCWTF7oj81GwtY1zGCTVrX1AHGEBkn7hxi+UGPTtv0R2
                pOW1eFoW7K20+7Qm7lPOQUFNMG1QC7acH6bydnwvLOcXel0lR7Ckd2sopdYIou96
                x9xUYgAz8j/Xbashdvuk8RF+BwKBgQDyiP8NenHGZcrWnlo7f3s5nVWsA74OFvGU
                vFdlcKteAX4HoKwtlw82NwWrAyM2OoWX8ZFFLK7xNd4zvDo9DPX9wFOH6rCTWLWM
                MyWsTXia8ZWaLYuQOdKsSxIya74U/avw6vVU1OL2RAxCtgaoRvZmIy3aCSF4Sq2p
                bcgZ7Db0/QKBgHnYOwpguWCFl6uiVg+XJ8JxqB48/Ved6KzOtgu0CeA+VzfjR0lb
                4E6UgEF5qeCFGf9z5XANqJHHJg7hzol46VL2ZGMzcK/WVlhCJrKMAXUrJgB+I8cB
                UmbSAX+GYWU493CqtU2WQMI2109iKMHjSkFtH0fWeTW4UDGtC8s95eMvAoGAYqd7
                J95gnVUWlwo+pekLFLp8+MVk75JBnkCmRCr6afitbSjcIIdLtr/W3GMgVZSkdtPa
                RYsRdih1RBISlnbJMPikgarjPGxfHLJJZrb0kgIm2logZQBAQ7kdo8jTvvIYmJza
                QjF+SLIRUql8N8L1w0IYCpKgPLATx9FSDclZ6XkCgYEAk759LTo+e6or9A29obe3
                usl4ze7c1PUq5ORVESjE2N7PlXznD2fJQtl8n8w4q6qM6oNYG1PmKNrkaSHh8fXy
                AbjVWgRxlQBe2/dn/NZRVWbNRgzTTnXGRCPnyzK2yREyoOKX+ntNy57qDRKaHKZL
                4lhYpIsIz0wuohXSVsv7z50=
                -----END PRIVATE KEY-----""";

        when(amazonS3Repository.getPrivateKeyFromS3Bucket(anyLong())).thenReturn(privateKey);

        when(amazonS3Repository.getSeedWordsFromS3Bucket(anyString()))
            .thenReturn("EIHgORJ+cWFQ37F3rWNWUOh00bi8OCcexNK88V3AZQ4V0VoSKeLfPImzgk85vCMoKnnY5cPAqArTeFsZqaEEDw+a8HGb2xW9BWe4sYLcVFgNdl52dElpW8OCFQnvIDEMfiwAcWMzw+U+y8dtOJU2AuAQFFz2afzRt3iaTO6IoPxH0155OIpfilO0JJtXh+yu7lrATru/gWF5/2Vx0eIJMWLycyyp2flqO/hu0iDYW3S4LKmqHWaBsrNrxoq+/WJFdIXVLr0SIUIe8iOWqyiibSOC99STrETYyGr4TnK0UyAFqkUMwQEccAMFUUud9LoqXbEo5Nupqs6YvCCeg8u9sw==");

        assertAll(() -> walletService.getSeedWords("wallet", 1L));

        verify(amazonS3Repository, times(1))
            .getSeedWordsFromS3Bucket(anyString());

        verify(amazonS3Repository, times(1))
            .getPrivateKeyFromS3Bucket(anyLong());

    }

}
