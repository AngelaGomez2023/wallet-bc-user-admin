package com.wallib.wallet.bc.users.admin.services.impl;


import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.repositories.es.FcmRegistrationTokenDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.FcmRegistrationTokenRepository;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FcmRegistrationTokenServiceImplTest {

    @InjectMocks
    private FcmRegistrationTokenServiceImpl fcmRegistrationTokenService;

    @Mock
    private FcmRegistrationTokenRepository fcmRegistrationTokenRepository;

    @Mock
    private FcmRegistrationTokenDocumentRepository fcmRegistrationTokenDocumentRepository;

    @Mock
    private AuditLogServiceImpl auditLogService;

    @Test
    void test_FindByIdMethod_Should_GetFcmRegistrationToken_When_ReceiveQueryParams() {
        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenRepository.findById(anyLong()))
            .thenReturn(java.util.Optional.of(fcmRegistrationToken));

        assertAll(() -> fcmRegistrationTokenService.findById(1L));

        verify(fcmRegistrationTokenRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_FindByIdMethod_Should_ThrowEntityNotFoundException_When_FcmRegistrationTokenDoesNotExists() {

        when(fcmRegistrationTokenRepository.findById(anyLong()))
            .thenReturn(java.util.Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> fcmRegistrationTokenService.findById(1L));

        verify(fcmRegistrationTokenRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_FindByFirebaseIdMethod_Should_GetFcmRegistrationToken_When_ReceiveQueryParams() {
        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenRepository.findByFirebaseIdAndStatusAndDeletedAtIsNull(anyLong(), anyInt()))
            .thenReturn(java.util.Optional.of(fcmRegistrationToken));

        assertAll(() -> fcmRegistrationTokenService.findByFirebaseId(1L));

        verify(fcmRegistrationTokenRepository, times(1))
            .findByFirebaseIdAndStatusAndDeletedAtIsNull(anyLong(), anyInt());
    }

    @Test
    void test_FindByFirebaseIdMethod_Should_ThrowEntityNotFoundException_When_FcmRegistrationTokenDoesNotExists() {

        when(fcmRegistrationTokenRepository.findByFirebaseIdAndStatusAndDeletedAtIsNull(anyLong(), anyInt()))
            .thenReturn(java.util.Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> fcmRegistrationTokenService.findByFirebaseId(1L));

        verify(fcmRegistrationTokenRepository, times(1))
            .findByFirebaseIdAndStatusAndDeletedAtIsNull(anyLong(), anyInt());
    }

    @Test
    void test_SaveMethod_Should_SaveFcmRegistrationToken_When_ReceiveValidObject() {
        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenRepository.existsByTokenAndFirebaseIdAndStatusAndDeletedAtIsNull(
            anyString(), anyLong(), anyInt())).thenReturn(false);

        doNothing().when(fcmRegistrationTokenRepository)
            .updateStatusByFirebaseIdAndDeletedAtIsNull(anyLong());

        doNothing().when(fcmRegistrationTokenDocumentRepository)
            .deleteAllByFirebaseIdAndStatus(anyLong(), anyInt());

        when(fcmRegistrationTokenRepository.save(any(FcmRegistrationToken.class)))
            .thenReturn(fcmRegistrationToken);

        assertAll(() -> fcmRegistrationTokenService.save(fcmRegistrationToken));

        verify(fcmRegistrationTokenRepository, times(1))
            .existsByTokenAndFirebaseIdAndStatusAndDeletedAtIsNull(anyString(), anyLong(), anyInt());

        verify(fcmRegistrationTokenRepository, times(1))
            .updateStatusByFirebaseIdAndDeletedAtIsNull(anyLong());

        verify(fcmRegistrationTokenDocumentRepository, times(1))
            .deleteAllByFirebaseIdAndStatus(anyLong(), anyInt());

        verify(fcmRegistrationTokenRepository, times(1))
            .save(any(FcmRegistrationToken.class));
    }

    @Test
    void test_SaveMethod_Should_SaveFcmRegistrationToken_When_ReceiveValidObjectAndTokenAlreadyExists() {
        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenRepository.existsByTokenAndFirebaseIdAndStatusAndDeletedAtIsNull(
            anyString(), anyLong(), anyInt())).thenReturn(true);

        assertThrows(FcmRegistrationTokenException.class,
            () -> fcmRegistrationTokenService.save(fcmRegistrationToken));

        verify(fcmRegistrationTokenRepository, times(1))
            .existsByTokenAndFirebaseIdAndStatusAndDeletedAtIsNull(anyString(), anyLong(), anyInt());
    }

}
