package com.wallib.wallet.bc.users.admin.consumers;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import javax.persistence.EntityNotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.facades.DocumentTypeElasticFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentTypeMessageConsumerTest {
    
    @InjectMocks
    private DocumentTypeMessageConsumer documentTypeMessageConsumer;

    @Mock
    private DocumentTypeElasticFacade documentTypeElasticFacade;

    @Test
    void test_ReceiveDocumentTypeMessage_Should_IndexDocumentTypeDocument_When_DocumentTypeExists()
        throws DocumentTypeServiceException, JsonProcessingException {
        doNothing().when(documentTypeElasticFacade).indexByDocumentType(anyLong());

        assertAll(() -> documentTypeMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(documentTypeElasticFacade, times(1)).indexByDocumentType(anyLong());
    }

    @Test
    void test_ReceiveDocumentTypeMessage_Should_ThrowEntityNotFoundException_When_DocumentTypeDoesNotExist()
        throws DocumentTypeServiceException, JsonProcessingException {
        doThrow(new EntityNotFoundException()).when(documentTypeElasticFacade).indexByDocumentType(anyLong());

        assertThrows(EntityNotFoundException.class,
            () -> documentTypeMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(documentTypeElasticFacade, times(1)).indexByDocumentType(anyLong());
    }

    @Test
    void test_ReceiveDocumentTypeMessage_Should_ThrowRuntimeException_When_IndexingFails()
        throws DocumentTypeServiceException, JsonProcessingException {
        doThrow(new RuntimeException()).when(documentTypeElasticFacade).indexByDocumentType(anyLong());

        assertThrows(RuntimeException.class,
            () -> documentTypeMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(documentTypeElasticFacade, times(1)).indexByDocumentType(anyLong());
    }

    @Test
    void test_ReceiveDocumentTypeMessage_Should_ThrowDocumentTypeServiceException_When_IndexingFails()
        throws DocumentTypeServiceException, JsonProcessingException {
        doThrow(new DocumentTypeServiceException("")).when(documentTypeElasticFacade).indexByDocumentType(anyLong());

        assertThrows(DocumentTypeServiceException.class,
            () -> documentTypeMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(documentTypeElasticFacade, times(1)).indexByDocumentType(anyLong());
    }

    private IndexEventDTO getIndexEventDto(){
        return IndexEventDTO.builder()
            .action("CREATE")
            .entity("USER")
            .entityId(1L)
            .build();
    }
}
