package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.components.AuthenticationComponent;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.models.wt.AuditLog;
import com.wallib.wallet.bc.users.admin.repositories.wt.AuditLogRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;

@ExtendWith(MockitoExtension.class)
class AuditLogsServiceImplTest {
    

    @InjectMocks
    private AuditLogServiceImpl auditLogService;

    @Mock
    private AuditLogRepository auditLogRepository;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private Authentication authentication;

    @Mock
    private AuthenticationComponent authenticationComponent;

    @Test
    void test_Create_Should_CreateAuditLog_When_ReceiveValidParameters() {
        Country country = getCountry();
        com.wallib.wallet.bc.users.admin.security.User applicationUser = new com.wallib.wallet.bc.users.admin.security.User("123456", "", "", new HashSet<>());

        when(authentication.getPrincipal()).thenReturn(applicationUser);
        when(authenticationComponent.getAuthentication()).thenReturn(authentication);
        when(auditLogRepository.save(any(AuditLog.class)))
            .thenReturn(mock(AuditLog.class));

        assertAll(() -> auditLogService.createAuditLog(country));
        verify(auditLogRepository,
            times(1)).save(any(AuditLog.class));
        verify(authenticationComponent, times(1)).getAuthentication();
    }

    @Test
    void test_Update_Should_UpdateAuditLog_When_ReceiveValidParameters() {
        com.wallib.wallet.bc.users.admin.models.wt.User user = getUser();
        com.wallib.wallet.bc.users.admin.security.User applicationUser = new com.wallib.wallet.bc.users.admin.security.User("123456", "", "", new HashSet<>());

        when(authentication.getPrincipal()).thenReturn(applicationUser);
        when(authenticationComponent.getAuthentication()).thenReturn(authentication);

        when(auditLogRepository.save(any(AuditLog.class)))
            .thenReturn(mock(AuditLog.class));

        assertAll(() -> auditLogService.updateAuditLog(user, user));
        verify(auditLogRepository,
            times(1)).save(any(AuditLog.class));
        verify(authenticationComponent, times(1)).getAuthentication();
    }

    @Test
    void test_Delete_Should_DeleteAuditLog_When_ReceiveValidParameters() {
        DocumentType documentType = getDocumentType();
        com.wallib.wallet.bc.users.admin.security.User applicationUser = new com.wallib.wallet.bc.users.admin.security.User("123456", "", "", new HashSet<>());

        when(authentication.getPrincipal()).thenReturn(applicationUser);
        when(authenticationComponent.getAuthentication()).thenReturn(authentication);

        when(auditLogRepository.save(any(AuditLog.class)))
            .thenReturn(mock(AuditLog.class));

        assertAll(() -> auditLogService.deleteAuditLog(documentType));
        verify(auditLogRepository,
            times(1)).save(any(AuditLog.class));
        verify(authenticationComponent, times(1)).getAuthentication();
    }

    private Country getCountry() {
        Country country = Country.builder()
            .name("{}")
            .status(1)
            .isoCode("AA")
            .build();

        country.setId(1L);
        country.setCreatedAt(LocalDateTime.now());
        country.setUpdatedAt(LocalDateTime.now());

        return country;
    }

    private com.wallib.wallet.bc.users.admin.models.wt.User getUser() {
        com.wallib.wallet.bc.users.admin.models.wt.User user = com.wallib.wallet.bc.users.admin.models.wt.User.builder()
            .firebaseId(1L)
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }

    private DocumentType getDocumentType() {
        DocumentType documentType = DocumentType.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        documentType.setId(1L);
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());

        return documentType;
    }
}
