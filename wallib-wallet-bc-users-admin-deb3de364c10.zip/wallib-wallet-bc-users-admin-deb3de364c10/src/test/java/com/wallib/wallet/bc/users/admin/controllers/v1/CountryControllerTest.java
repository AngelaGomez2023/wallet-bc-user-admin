package com.wallib.wallet.bc.users.admin.controllers.v1;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_COUNTRY;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_COUNTRIES;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_COUNTRY_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_COUNTRY_ISO_CODE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_COUNTRY;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_COUNTRY;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CountryLanguageDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateCountryDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateCountryDTO;
import com.wallib.wallet.bc.users.admin.facades.CountryFacade;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.services.CountryService;
import java.util.Collections;
import java.util.List;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = CountryController.class)
class CountryControllerTest extends CreateJWT {
    
    @MockBean
    private CountryService countryService;

    @MockBean
    private CountryFacade countryFacade;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void test_List_Should_ReturnCountryList_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(LIST_COUNTRIES);

        Country country = Country.builder()
            .id(1L)
            .name("{\"es\":\"Colombia\",\"en\":\"Colombia\",\"pt\":\"Colombia\"}")
            .isoCode("TS")
            .phoneCode(57)
            .status(1)
            .build();

        List<Country> countryList = Collections.singletonList(country);

        when(countryService.list()).thenReturn(countryList);

        this.mockMvc
            .perform(get("/v1/countries")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("phone_code")))
            .andExpect(content().string(Matchers.containsString("status")));
    }

    @Test
    void test_FindById_Should_ReturnCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_COUNTRY_ID);

        Country country = Country.builder()
            .id(1L)
            .name("{\"es\":\"Colombia\",\"en\":\"Colombia\",\"pt\":\"Colombia\"}")
            .isoCode("TS")
            .phoneCode(57)
            .status(1)
            .build();

        when(countryService.findById(anyLong())).thenReturn(country);

        this.mockMvc
            .perform(get("/v1/countries/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("phone_code")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_FindByIsoCode_Should_ReturnCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_COUNTRY_ISO_CODE);

        Country country = Country.builder()
            .id(1L)
            .name("{\"es\":\"Colombia\",\"en\":\"Colombia\",\"pt\":\"Colombia\"}")
            .isoCode("CO")
            .phoneCode(57)
            .status(1)
            .build();

        when(countryService.findByIsoCode(anyString())).thenReturn(country);

        this.mockMvc
            .perform(get("/v1/countries?iso_code=CO")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("phone_code")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_Create_Should_Return_CreatedCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(CREATE_COUNTRY);

        CountryLanguageDTO countryLanguageDTO = CountryLanguageDTO.builder()
            .en("English")
            .es("Spanish")
            .pt("Portuguese")
            .build();

        CreateCountryDTO createCountryDTO = CreateCountryDTO.builder()
            .name(countryLanguageDTO)
            .isoCode("TS")
            .phoneCode(57)
            .status(1)
            .build();

        String createCountryJson = objectMapper.writeValueAsString(createCountryDTO);
        String countryLanguageJson = objectMapper.writeValueAsString(countryLanguageDTO);

        Country country = Country.builder()
            .id(1L)
            .name(countryLanguageJson)
            .isoCode("TEST")
            .phoneCode(57)
            .status(1)
            .build();

        when(countryFacade.create(any(Country.class))).thenReturn(country);

        mockMvc
            .perform(post("/v1/countries")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(createCountryJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isCreated())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("phone_code")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_Update_Should_Return_UpdatedCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(UPDATE_COUNTRY);

        CountryLanguageDTO countryLanguageDTO = CountryLanguageDTO.builder()
            .en("English")
            .es("Spanish")
            .pt("Portuguese")
            .build();

        UpdateCountryDTO updateCountryDTO = UpdateCountryDTO.builder()
            .name(countryLanguageDTO)
            .isoCode("TS")
            .phoneCode(57)
            .status(1)
            .build();

        String updateCountryJson = objectMapper.writeValueAsString(updateCountryDTO);
        String countryLanguageJson = objectMapper.writeValueAsString(countryLanguageDTO);

        Country country = Country.builder()
            .id(1L)
            .name(countryLanguageJson)
            .isoCode("TS")
            .phoneCode(57)
            .status(1)
            .build();

        when(countryFacade.update(anyLong(), any(Country.class))).thenReturn(country);

        mockMvc
            .perform(put("/v1/countries/1")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(updateCountryJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isAccepted())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("name")))
            .andExpect(content().string(Matchers.containsString("phone_code")))
            .andExpect(content().string(Matchers.containsString("iso_code")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_Delete_Should_Return_DeletedCountry_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(DELETE_COUNTRY);

        doNothing().when(countryFacade).delete(anyLong());

        mockMvc
            .perform(delete("/v1/countries/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isNoContent())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
        ;
    }

    @Test
    void test_Get_Should_Return403_When_Permission_IsNotValid() throws Exception {

        String token = generateJWT("NONE");

        mockMvc
            .perform(get("/v1/countries")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isForbidden())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(403))
            .andExpect(jsonPath("$.message").value("Forbidden"))
            .andExpect(jsonPath("$.error").value("Access is denied"))
        ;
    }

    @Test
    void test_Get_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(get("/v1/countries")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Post_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(post("/v1/countries/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Put_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(put("/v1/countries/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }
}
