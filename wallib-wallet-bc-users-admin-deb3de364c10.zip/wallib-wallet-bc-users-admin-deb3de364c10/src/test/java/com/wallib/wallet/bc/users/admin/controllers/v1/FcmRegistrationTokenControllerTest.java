package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_FCM_BY_FIREBASE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.SAVE_FCM_TOKEN;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateFcmRegistrationTokenDTO;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenElasticFacade;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenFacade;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = FcmRegistrationTokenController.class)
class FcmRegistrationTokenControllerTest extends CreateJWT {

    @MockBean
    private FcmRegistrationTokenFacade fcmRegistrationTokenFacade;

    @MockBean
    private FcmRegistrationTokenElasticFacade fcmRegistrationTokenElasticFacade;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void test_FindByFirebaseId_Should_ReturnFcmRegistrationToken_When_ServiceIsCalled()
        throws Exception {

        String token = generateJWT(FIND_FCM_BY_FIREBASE_ID);

        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenElasticFacade.findByFirebaseId(1L)).thenReturn(
            fcmRegistrationToken);

        this.mockMvc
            .perform(get("/v1/fcm/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("token")))
            .andExpect(content().string(Matchers.containsString("platform")))
            .andExpect(content().string(Matchers.containsString("status")));
    }

    @Test
    void test_Save_Should_ReturnFcmRegistrationToken_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(SAVE_FCM_TOKEN);

        CreateFcmRegistrationTokenDTO createFcmRegistrationTokenDTO = CreateFcmRegistrationTokenDTO.builder()
            .firebaseId(1L)
            .token("REGISTRATION_TOKEN")
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        String createFcmRegistrationTokenDTOJson = objectMapper.writeValueAsString(
            createFcmRegistrationTokenDTO);

        when(fcmRegistrationTokenFacade.save((any(FcmRegistrationToken.class))))
            .thenReturn(fcmRegistrationToken);

        mockMvc
            .perform(post("/v1/fcm")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(createFcmRegistrationTokenDTOJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isCreated())
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("token")))
            .andExpect(content().string(Matchers.containsString("platform")))
            .andExpect(content().string(Matchers.containsString("status")));

    }


}
