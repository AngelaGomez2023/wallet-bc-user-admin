package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.repositories.es.UserDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import org.springframework.data.redis.core.ValueOperations;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserPinRedisServiceImplTest {
    
    @InjectMocks
    private UserPinRedisServiceImpl userPinRedisService;

    @Mock
    private UserDocumentRepository userDocumentRepository;

    @Mock
    private CountryRepository countryRepository;

    @Mock
    private ValueOperations<String, String> valueOperations;

    @Test
    void test_Cache_Should_Return_CacheUserPin_When_ServiceIsCalled() throws Exception {

        doNothing().when(valueOperations).set(anyString(), anyString());

        assertAll(() -> userPinRedisService.cache(getUserPin()));

        verify(valueOperations, times(1))
            .set(anyString(), anyString());
    }

    @Test
    void test_Get_Should_Return_CachedUserPin_When_ServiceIsCalled() throws Exception {

        String userPinString = "";

        when(valueOperations.get(anyString())).thenReturn(userPinString);

        assertAll(() -> userPinRedisService.get(1L));

        verify(valueOperations, times(1))
            .get(anyString());
    }

    private UserPin getUserPin() {
        UserPin user = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }
}
