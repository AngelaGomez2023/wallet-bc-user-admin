package com.wallib.wallet.bc.users.admin.consumers;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FCM_REGISTRATION_TOKEN_ENTITY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.FcmRegistrationTokenException;
import com.wallib.wallet.bc.users.admin.facades.FcmRegistrationTokenElasticFacade;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FcmRegistrationTokenConsumerTest {

    @InjectMocks
    private FcmRegistrationTokenConsumer fcmRegistrationTokenConsumer;
    @Mock
    private FcmRegistrationTokenElasticFacade fcmRegistrationTokenElasticFacade;

    @Test
    void test_ReceiveFcmRegistrationToken_Should_IndexFcmRegistrationTokenDocument_When_FcmRegistrationTokenExists()
        throws FcmRegistrationTokenException, JsonProcessingException {
        doNothing().when(fcmRegistrationTokenElasticFacade).indexByFcmRegistrationToken(anyLong());

        assertAll(() -> fcmRegistrationTokenConsumer.receiveFcmRegistrationTokenMessage(
            getIndexEventDto()));

        verify(fcmRegistrationTokenElasticFacade, times(1)).indexByFcmRegistrationToken(anyLong());
    }

    @Test
    void test_ReceiveFcmRegistrationToken_Should_ThrowEntityNotFoundException_When_FcmRegistrationTokenDoesNotExist()
        throws FcmRegistrationTokenException, JsonProcessingException {
        doThrow(new EntityNotFoundException()).when(fcmRegistrationTokenElasticFacade)
            .indexByFcmRegistrationToken(anyLong());

        assertThrows(EntityNotFoundException.class,
            () -> fcmRegistrationTokenConsumer.receiveFcmRegistrationTokenMessage(
                getIndexEventDto()));

        verify(fcmRegistrationTokenElasticFacade, times(1)).indexByFcmRegistrationToken(anyLong());
    }

    @Test
    void test_ReceiveFcmRegistrationToken_Should_ThrowRuntimeException_When_IndexingFails()
        throws FcmRegistrationTokenException, JsonProcessingException {
        doThrow(new RuntimeException()).when(fcmRegistrationTokenElasticFacade)
            .indexByFcmRegistrationToken(anyLong());

        assertThrows(RuntimeException.class,
            () -> fcmRegistrationTokenConsumer.receiveFcmRegistrationTokenMessage(
                getIndexEventDto()));

        verify(fcmRegistrationTokenElasticFacade, times(1)).indexByFcmRegistrationToken(anyLong());
    }

    @Test
    void test_ReceiveFcmRegistrationToken_Should_ThrowFcmRegistrationTokenException_When_IndexingFails()
        throws JsonProcessingException, FcmRegistrationTokenException {
        doThrow(new FcmRegistrationTokenException("FcmRegistrationTokenException")).when(
                fcmRegistrationTokenElasticFacade)
            .indexByFcmRegistrationToken(anyLong());

        assertThrows(FcmRegistrationTokenException.class,
            () -> fcmRegistrationTokenConsumer.receiveFcmRegistrationTokenMessage(
                getIndexEventDto()));

        verify(fcmRegistrationTokenElasticFacade, times(1)).indexByFcmRegistrationToken(anyLong());
    }

    private IndexEventDTO getIndexEventDto() {
        return IndexEventDTO.builder()
            .action("CREATE")
            .entity(FCM_REGISTRATION_TOKEN_ENTITY)
            .entityId(1L)
            .build();
    }

}
