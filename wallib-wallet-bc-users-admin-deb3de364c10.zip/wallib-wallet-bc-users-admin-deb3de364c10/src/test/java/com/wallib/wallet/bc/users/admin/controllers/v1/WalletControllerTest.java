package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_USER_PIN_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.GET_WALLET_PASSPHRASE;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.GET_WALLET_SEED_WORDS;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.wallib.wallet.bc.users.admin.domain.WalletPassphrase;
import com.wallib.wallet.bc.users.admin.domain.WalletSeedWords;
import com.wallib.wallet.bc.users.admin.dto.v1.responses.ResponsePassphraseDTO;
import com.wallib.wallet.bc.users.admin.facades.UserPinFacade;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.WalletService;
import java.util.UUID;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = WalletController.class)
class WalletControllerTest extends CreateJWT {

    @MockBean
    private WalletService walletService;

    @MockBean
    private UserPinFacade userPinFacade;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void test_GetPassphrase_Should_ReturnPassphrase_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(GET_WALLET_PASSPHRASE);

        String wallet = UUID.randomUUID().toString();

        WalletPassphrase walletPassphrase = WalletPassphrase.builder()
            .wallet(wallet)
            .passphrase("pass")
            .build();

        when(walletService.getPassphrase(anyString(), anyLong())).thenReturn(walletPassphrase);

        this.mockMvc
            .perform(get("/v1/wallet/"+wallet+"/user/45")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("wallet")))
            .andExpect(content().string(Matchers.containsString("passphrase")));
    }

    @Test
    void test_GetSeedWords_Should_ReturnSeedWords_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(GET_WALLET_SEED_WORDS);

        String wallet = UUID.randomUUID().toString();

        WalletSeedWords walletSeedWords = WalletSeedWords.builder()
            .wallet(wallet)
            .seedWords("seed")
            .build();

        when(walletService.getSeedWords(anyString(), anyLong())).thenReturn(walletSeedWords);

        this.mockMvc
            .perform(get("/v1/wallet/"+wallet+"/user/45/seed")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("wallet")))
            .andExpect(content().string(Matchers.containsString("seed_words")));
    }

}
