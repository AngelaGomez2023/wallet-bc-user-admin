package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.UserRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {
    
    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private CountryRepository countryRepository;

    @Mock
    private AuditLogServiceImpl auditLogService;

    @Test
    void test_List_Should_ListUsers_When_ReceiveQueryParams_Valid() {
        User user = getUser();

        List<User> users = new ArrayList<>();
        users.add(user);

        when(userRepository.findByIdInCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull(
            anyLong(), anyString(), any())).thenReturn(
            new PageImpl<>(
                users, PageRequest.of(0, 10), 10)
        );

        assertAll(() -> userService.list(1L, "", PageRequest.of(0, 10))
        );
        verify(userRepository, times(1))
            .findByIdInCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull(
                anyLong(), anyString(), any()
            );
    }

    @Test
    void test_CountByFilter_Should_ReturnSize_When_Invoked() {
        when(userRepository.countByIdInAndCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull(
            anyLong(), anyString())).thenReturn(10);

        int storesCount = userService.countByCountryIdAndDeletedAtIsNull(1L, "");

        assertEquals(10, storesCount);
        verify(userRepository, times(1))
            .countByIdInAndCountryIdAndFirstNameContainingIgnoreCaseAndDeletedAtIsNull(anyLong(), anyString());
    }

    @Test
    void test_FindByIdMethod_Should_GetUser_When_ReceiveQueryParams() {
        User user = getUser();
        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));

        assertAll(() -> userService.findById(1L));
        verify(userRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_FindByFirebaseIdMethod_Should_GetUser_When_ReceiveQueryParams() {
        User user = getUser();
        when(userRepository.findByFirebaseIdAndDeletedAtIsNull(anyString())).thenReturn(java.util.Optional.of(user));

        assertAll(() -> userService.findByFirebaseId("fake-uuid"));
        verify(userRepository, times(1))
            .findByFirebaseIdAndDeletedAtIsNull(anyString());
    }

    @Test
    void test_FindByFirebaseIdMethod_Should_ThrowEntityNotFoundException_When_UserDoesNotExist() {

        when(userRepository.findByFirebaseIdAndDeletedAtIsNull(anyString()))
            .thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> userService.findByFirebaseId("fake-uuid"));
    }

    @Test
    void test_FindByNicknameMethod_Should_GetUser_When_ReceiveQueryParams() {
        User user = getUser();
        when(userRepository.findByNicknameAndStatusAndDeletedAtIsNull(anyString(), anyInt()))
            .thenReturn(java.util.Optional.of(user));

        assertAll(() -> userService.findByNickname("fulano1"));
        verify(userRepository, times(1))
            .findByNicknameAndStatusAndDeletedAtIsNull(anyString(), anyInt());
    }

    @Test
    void test_FindByNicknameMethod_Should_ThrowEntityNotFoundException_When_UserDoesNotExist() {

        when(userRepository.findByNicknameAndStatusAndDeletedAtIsNull(anyString(), anyInt()))
            .thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> userService.findByNickname("fulano1"));
    }

    @Test
    void test_CreateMethod_Should_CreateUser_When_ReceiveValidObject() throws JsonProcessingException {
        User user = getUser();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByDocumentIdAndDocumentTypeAndDeletedAtIsNull(anyString(), anyInt())).thenReturn(false);
        when(userRepository.existsByFirebaseIdAndDeletedAtIsNull(anyLong())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).createAuditLog(any(User.class));

        assertAll(() -> userService.create(user));

        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByDocumentIdAndDocumentTypeAndDeletedAtIsNull(anyString(), anyInt());
        verify(userRepository, times(1))
                .existsByFirebaseIdAndDeletedAtIsNull(anyLong());
        verify(userRepository, times(1)).save(any(User.class));
        verify(auditLogService, times(1)).createAuditLog(any(User.class));
    }

    @Test
    void test_CreateMethod_Should_CreateUser_When_ReceiveBasicData() throws JsonProcessingException {
        User user = getUserBasic();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByFirebaseIdAndDeletedAtIsNull(anyLong())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).createAuditLog(any(User.class));

        assertAll(() -> userService.create(user));

        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndDeletedAtIsNull(anyLong());
        verify(userRepository, times(1)).save(any(User.class));
        verify(auditLogService, times(1)).createAuditLog(any(User.class));
    }

    @Test
    void test_CreateMethod_Should_CreateUser_When_ReceiveStatusInactive() throws JsonProcessingException {
        User user = getUserInactive();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByFirebaseIdAndDeletedAtIsNull(anyLong())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).createAuditLog(any(User.class));

        assertAll(() -> userService.create(user));

        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndDeletedAtIsNull(anyLong());
        verify(userRepository, times(1)).save(any(User.class));
        verify(auditLogService, times(1)).createAuditLog(any(User.class));
    }

    @Test
    void test_CreateMethod_Should_CreateUser_When_ReceiveBasicDataAndDocumentIdIsNull() throws JsonProcessingException {
        User user = getUserBasic();
        user.setDocumentType(1);

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByFirebaseIdAndDeletedAtIsNull(anyLong())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).createAuditLog(any(User.class));

        assertAll(() -> userService.create(user));

        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndDeletedAtIsNull(anyLong());
        verify(userRepository, times(1)).save(any(User.class));
        verify(auditLogService, times(1)).createAuditLog(any(User.class));
    }

    @Test
    void test_CreateMethod_Should_CreateUser_When_ReceiveBasicDataAndDocumentTypeIsNull() throws JsonProcessingException {
        User user = getUserBasic();
        user.setDocumentId("test");

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByFirebaseIdAndDeletedAtIsNull(anyLong())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).createAuditLog(any(User.class));

        assertAll(() -> userService.create(user));

        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndDeletedAtIsNull(anyLong());
        verify(userRepository, times(1)).save(any(User.class));
        verify(auditLogService, times(1)).createAuditLog(any(User.class));
    }

    @Test
    void test_CreateMethod_Should_ThrowUserServiceException_When_CountryIdDoesNotExist() {
        User user = getUser();

        when(countryRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(UserServiceException.class,
            () -> userService.create(user));
    }

    @Test
    void test_CreateMethod_Should_ThrowUserServiceException_When_UserDocumentIdDuplicated() {
        User user = getUser();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByDocumentIdAndDocumentTypeAndDeletedAtIsNull(anyString(), anyInt())).thenReturn(true);

        assertThrows(UserServiceException.class,
            () -> userService.create(user));
    }

    @Test
    void test_CreateMethod_Should_ThrowUserServiceException_When_FirebaseIdDuplicated() {
        User user = getUser();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByDocumentIdAndDocumentTypeAndDeletedAtIsNull(anyString(), anyInt())).thenReturn(false);
        when(userRepository.existsByFirebaseIdAndDeletedAtIsNull(anyLong())).thenReturn(true);

        assertThrows(UserServiceException.class,
            () -> userService.create(user));
    }

    @Test
    void test_UpdateMethod_Should_UpdateUser_When_ReceiveValidObject() throws JsonProcessingException {
        User user = getUser();

        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByDocumentIdAndDocumentTypeAndIdNotAndDeletedAtIsNull(anyString(), anyInt(), anyLong())).thenReturn(false);
        when(userRepository.existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong())).thenReturn(true);
        when(userRepository.saveAndFlush(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).updateAuditLog(any(User.class), any(User.class));

        assertAll(() -> userService.update(1L, user));
        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByDocumentIdAndDocumentTypeAndIdNotAndDeletedAtIsNull(anyString(), anyInt(), anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong());
        verify(userRepository, times(1))
            .saveAndFlush(any(User.class));
        verify(auditLogService, times(1))
            .updateAuditLog(any(User.class), any(User.class));
    }

    @Test
    void test_UpdateMethod_Should_UpdateUser_When_ReceiveValidObject_And_DocumentIdIsNull() throws JsonProcessingException {
        User user = getUser();
        user.setDocumentId(null);

        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong())).thenReturn(true);
        when(userRepository.saveAndFlush(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).updateAuditLog(any(User.class), any(User.class));

        assertAll(() -> userService.update(1L, user));
        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong());
        verify(userRepository, times(1))
            .saveAndFlush(any(User.class));
        verify(auditLogService, times(1))
            .updateAuditLog(any(User.class), any(User.class));
    }

    @Test
    void test_UpdateMethod_Should_UpdateUser_When_ReceiveValidObject_And_DocumentTypeIsNull() throws JsonProcessingException {
        User user = getUser();
        user.setDocumentType(null);

        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong())).thenReturn(true);
        when(userRepository.saveAndFlush(any(User.class))).thenReturn(user);
        doNothing().when(auditLogService).updateAuditLog(any(User.class), any(User.class));

        assertAll(() -> userService.update(1L, user));
        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(countryRepository, times(1))
            .existsById(anyLong());
        verify(userRepository, times(1))
            .existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong());
        verify(userRepository, times(1))
            .saveAndFlush(any(User.class));
        verify(auditLogService, times(1))
            .updateAuditLog(any(User.class), any(User.class));
    }

    @Test
    void test_UpdateMethod_Should_ThrowEntityNotFoundException_When_UserDoesNotExist() {
        User user = getUser();

        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> userService.update(1L, user));
    }

    @Test
    void test_UpdateMethod_Should_ThrowUserServiceException_When_DocumentIdExist_InOtherRecord() {
        User user = getUser();

        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByDocumentIdAndDocumentTypeAndIdNotAndDeletedAtIsNull(
            anyString(), 
            anyInt(), 
            anyLong())
        ).thenReturn(true);

        assertThrows(UserServiceException.class,
            () -> userService.update(1L, user));
    }

    @Test
    void test_UpdateMethod_Should_ThrowUserServiceException_When_FirebaseIdExist_InOtherRecord() {
        User user = getUser();

        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(userRepository.existsByDocumentIdAndDocumentTypeAndIdNotAndDeletedAtIsNull(anyString(), anyInt(), anyLong())).thenReturn(false);
        when(userRepository.existsByFirebaseIdAndIdAndDeletedAtIsNull(anyLong(), anyLong())).thenReturn(false);

        assertThrows(UserServiceException.class,
            () -> userService.update(1L, user));
    }

    @Test
    void test_DeleteMethod_Should_DeleteUser_When_ReceiveValidId() {
        User user = getUser();
        when(userRepository.findById(anyLong())).thenReturn(java.util.Optional.of(user));
        doNothing().when(userRepository).delete(any(User.class));

        assertAll(() -> userService.delete(1L));
        verify(userRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_DeleteMethod_Should_ThrowEntityNotFoundException_When_UserDoesNotExist() {

        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class,
            () -> userService.delete(1L));
    }

    private User getUser() {
        User user = User.builder()
            .firebaseId(1L)
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }


    private User getUserBasic() {
        User user = User.builder()
            .firebaseId(1L)
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(2)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }

    private User getUserInactive() {
        User user = User.builder()
            .firebaseId(1L)
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(0)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }

}
