package com.wallib.wallet.bc.users.admin.services.impl;


import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.documents.FcmRegistrationTokenDocument;
import com.wallib.wallet.bc.users.admin.enums.PlatformEnum;
import com.wallib.wallet.bc.users.admin.models.wt.FcmRegistrationToken;
import com.wallib.wallet.bc.users.admin.repositories.es.FcmRegistrationTokenDocumentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FcmRegistrationTokenElasticServiceImplTest {

    @InjectMocks
    private FcmRegistrationTokenElasticServiceImpl fcmRegistrationTokenElasticService;

    @Mock
    private FcmRegistrationTokenDocumentRepository fcmRegistrationTokenDocumentRepository;

    @Test
    void test_FindByFirebaseIdMethod_Should_GetFcmRegistrationToken_When_ReceiveQueryParams() {
        FcmRegistrationTokenDocument fcmRegistrationToken = FcmRegistrationTokenDocument.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform("ios")
            .status(1)
            .build();

        when(fcmRegistrationTokenDocumentRepository.findByFirebaseIdAndStatus(anyLong(), anyInt()))
            .thenReturn(java.util.Optional.of(fcmRegistrationToken));

        assertAll(() -> fcmRegistrationTokenElasticService.findByFirebaseId(1L));

        verify(fcmRegistrationTokenDocumentRepository, times(1))
            .findByFirebaseIdAndStatus(anyLong(), anyInt());
    }

    @Test
    void test_IndexMethod_Should_SaveFcmRegistrationToken_When_ReceiveValidObject() {
        FcmRegistrationTokenDocument fcmRegistrationTokenDocument = FcmRegistrationTokenDocument.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform("ios")
            .status(1)
            .build();

        FcmRegistrationToken fcmRegistrationToken = FcmRegistrationToken.builder()
            .id(1L)
            .token("REGISTRATION_TOKEN")
            .firebaseId(1L)
            .platform(PlatformEnum.PLATFORM_IOS)
            .status(1)
            .build();

        when(fcmRegistrationTokenDocumentRepository.save(any(FcmRegistrationTokenDocument.class)))
            .thenReturn(fcmRegistrationTokenDocument);

        assertAll(() -> fcmRegistrationTokenElasticService.index(fcmRegistrationToken));

        verify(fcmRegistrationTokenDocumentRepository, times(1))
            .save(any(FcmRegistrationTokenDocument.class));
    }

}
