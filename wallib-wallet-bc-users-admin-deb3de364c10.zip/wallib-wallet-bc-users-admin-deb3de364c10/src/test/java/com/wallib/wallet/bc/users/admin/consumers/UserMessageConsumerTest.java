package com.wallib.wallet.bc.users.admin.consumers;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.facades.UserElasticFacade;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserMessageConsumerTest {

    @InjectMocks
    private UserMessageConsumer userMessageConsumer;

    @Mock
    private UserElasticFacade userElasticFacade;

    @Test
    void test_ReceiveUserMessage_Should_IndexUserDocument_When_UserExists()
        throws UserServiceException, JsonProcessingException {
        doNothing().when(userElasticFacade).indexByUser(anyLong());

        assertAll(() -> userMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(userElasticFacade, times(1)).indexByUser(anyLong());
    }

    @Test
    void test_ReceiveUserMessage_Should_ThrowEntityNotFoundException_When_UserDoesNotExist()
        throws UserServiceException, JsonProcessingException {
        doThrow(new EntityNotFoundException()).when(userElasticFacade).indexByUser(anyLong());

        assertThrows(EntityNotFoundException.class,
            () -> userMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(userElasticFacade, times(1)).indexByUser(anyLong());
    }

    @Test
    void test_ReceiveUserMessage_Should_ThrowRuntimeException_When_IndexingFails()
        throws UserServiceException, JsonProcessingException {
        doThrow(new RuntimeException()).when(userElasticFacade).indexByUser(anyLong());

        assertThrows(RuntimeException.class,
            () -> userMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(userElasticFacade, times(1)).indexByUser(anyLong());
    }

    @Test
    void test_ReceiveUserMessage_Should_ThrowUserServiceException_When_IndexingFails()
        throws UserServiceException, JsonProcessingException {
        doThrow(new UserServiceException("")).when(userElasticFacade).indexByUser(anyLong());

        assertThrows(UserServiceException.class,
            () -> userMessageConsumer.receiveUserMessage(getIndexEventDto()));

        verify(userElasticFacade, times(1)).indexByUser(anyLong());
    }

    private IndexEventDTO getIndexEventDto(){
        return IndexEventDTO.builder()
            .action("CREATE")
            .entity("USER")
            .entityId(1L)
            .build();
    }

}
