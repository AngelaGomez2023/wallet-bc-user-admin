package com.wallib.wallet.bc.users.admin.controllers.v1;

import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_NICKNAME;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.LIST_USERS_BY_COUNTRY_ID;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.CREATE_USER;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_USER_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.FIND_BY_FIREBASE_ID;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.DELETE_USER;
import static com.wallib.wallet.bc.users.admin.constants.WalletUsersAdminConstants.UPDATE_USER;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.CreateUserDTO;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserDTO;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import com.wallib.wallet.bc.users.admin.facades.UserFacade;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.services.UserService;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(controllers = UserController.class)
class UserControllerTest extends CreateJWT {
    
    @MockBean
    private UserService userService;

    @MockBean
    private UserFacade userFacade;

    @Autowired
    private MockMvc mockMvc;

    @SpyBean
    private ModelMapper modelMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void test_List_Should_Return200_When_ValidQueryParams() throws Exception {

        String token = generateJWT(LIST_USERS_BY_COUNTRY_ID);

        User user = User.builder()
            .id(1L)
            .firebaseId(1L)
            .nickname("pedroperez1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@wallib.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2021, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        List<User> userList = Collections.singletonList(user);

        //Mock
        when(userService.list(anyLong(), anyString(), any(Pageable.class))).thenReturn(
            new PageImpl<>(
                userList, PageRequest.of(0, 10), 10)
        );

        when(userService.countByCountryIdAndDeletedAtIsNull(anyLong(), anyString())).thenReturn(1);

        String sortByNameAsc = "/v1/users?country_id=1&page=0&size=1&sort=name%2Casc";
        executeGetRequest(token, sortByNameAsc);

        String sortByNameDesc = "/v1/users?country_id=1&page=0&size=1&sort=name%2Cdesc";
        executeGetRequest(token, sortByNameDesc);

        String filterByName = "/v1/users?country_id=1&filter=test&page=0&size=1&sort=name%2Cdesc";
        executeGetRequest(token, filterByName);

        String filterByMinCharacters = "/v1/users?country_id=1&filter=by&page=0&size=1&sort=name%2Cdesc";
        executeGetRequest(token, filterByMinCharacters);

        String filterWithEmptySort = "/v1/users?country_id=1&filter=sutano&page=0&size=1&sort=";
        executeGetRequest(token, filterWithEmptySort);

        String filterWithEmptySize = "/v1/users?country_id=1&filter=muy&page=0&size=&sort=";
        executeGetRequest(token, filterWithEmptySize);

        String allUsers = "/v1/users?country_id=1&sort=name%2Cdesc";
        executeGetRequest(token, allUsers);

    }

    @Test
    void test_List_Should_Return200_When_ValidQueryParams_And_SizeIsZero() throws Exception {

        String token = generateJWT(LIST_USERS_BY_COUNTRY_ID);

        List<User> userList = Collections.emptyList();

        //Mock
        when(userService.list(anyLong(), anyString(), any(Pageable.class))).thenReturn(
            new PageImpl<>(
                userList, PageRequest.of(0, 1), 0)
        );

        when(userService.countByCountryIdAndDeletedAtIsNull(anyLong(), anyString())).thenReturn(0);

        this.mockMvc.perform(get("/v1/users?country_id=1&filter=fulano&page=0&size=&sort=")
                .header(HttpHeaders.AUTHORIZATION, token)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status_code").value(200))
            .andExpect(jsonPath("$.error").isEmpty());


    }

    @Test
    void test_FindById_Should_ReturnUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_USER_ID);

        User user = User.builder()
            .id(1L)
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        when(userService.findById(anyLong())).thenReturn(user);

        this.mockMvc
            .perform(get("/v1/users/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("nickname")))
            .andExpect(content().string(Matchers.containsString("firstname")))
            .andExpect(content().string(Matchers.containsString("lastname")))
            .andExpect(content().string(Matchers.containsString("email")))
            .andExpect(content().string(Matchers.containsString("phone")))
            .andExpect(content().string(Matchers.containsString("document_id")))
            .andExpect(content().string(Matchers.containsString("document_type")))
            .andExpect(content().string(Matchers.containsString("document_date_expiration")))
            .andExpect(content().string(Matchers.containsString("address")))
            .andExpect(content().string(Matchers.containsString("city")))
            .andExpect(content().string(Matchers.containsString("state")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("language_id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_FindByFirebaseId_Should_ReturnUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_FIREBASE_ID);

        User user = User.builder()
            .id(1L)
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        when(userService.findByFirebaseId(anyString())).thenReturn(user);

        this.mockMvc
            .perform(get("/v1/users/firebase?firebase_id=ag1432zfasdf234")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("nickname")))
            .andExpect(content().string(Matchers.containsString("firstname")))
            .andExpect(content().string(Matchers.containsString("lastname")))
            .andExpect(content().string(Matchers.containsString("email")))
            .andExpect(content().string(Matchers.containsString("phone")))
            .andExpect(content().string(Matchers.containsString("document_id")))
            .andExpect(content().string(Matchers.containsString("document_type")))
            .andExpect(content().string(Matchers.containsString("document_date_expiration")))
            .andExpect(content().string(Matchers.containsString("address")))
            .andExpect(content().string(Matchers.containsString("city")))
            .andExpect(content().string(Matchers.containsString("state")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("language_id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("status")));
    }

    @Test
    void test_FindByNickname_Should_ReturnUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(FIND_BY_NICKNAME);

        User user = User.builder()
            .id(1L)
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        when(userService.findByNickname(anyString())).thenReturn(user);

        this.mockMvc
            .perform(get("/v1/users?nickname=pedro1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isOk())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("nickname")))
            .andExpect(content().string(Matchers.containsString("firstname")))
            .andExpect(content().string(Matchers.containsString("lastname")))
            .andExpect(content().string(Matchers.containsString("email")))
            .andExpect(content().string(Matchers.containsString("phone")))
            .andExpect(content().string(Matchers.containsString("document_id")))
            .andExpect(content().string(Matchers.containsString("document_type")))
            .andExpect(content().string(Matchers.containsString("document_date_expiration")))
            .andExpect(content().string(Matchers.containsString("address")))
            .andExpect(content().string(Matchers.containsString("city")))
            .andExpect(content().string(Matchers.containsString("state")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("language_id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("status")));
    }

    @Test
    void test_Create_Should_Return_CreatedUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(CREATE_USER);

        CreateUserDTO createUserDTO = CreateUserDTO.builder()
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .build();

        String createUserJson = objectMapper.writeValueAsString(createUserDTO);

        User user = User.builder()
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .build();

        when(userFacade.create(any(User.class))).thenReturn(user);

        mockMvc
            .perform(post("/v1/users")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(createUserJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isCreated())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("nickname")))
            .andExpect(content().string(Matchers.containsString("firstname")))
            .andExpect(content().string(Matchers.containsString("lastname")))
            .andExpect(content().string(Matchers.containsString("email")))
            .andExpect(content().string(Matchers.containsString("phone")))
            .andExpect(content().string(Matchers.containsString("document_id")))
            .andExpect(content().string(Matchers.containsString("document_type")))
            .andExpect(content().string(Matchers.containsString("document_date_expiration")))
            .andExpect(content().string(Matchers.containsString("address")))
            .andExpect(content().string(Matchers.containsString("city")))
            .andExpect(content().string(Matchers.containsString("state")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("language_id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_Update_Should_Return_UpdatedUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(UPDATE_USER);

        UpdateUserDTO updateUserDTO = UpdateUserDTO.builder()
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .build();

        String updateUserJson = objectMapper.writeValueAsString(updateUserDTO);

        User user = User.builder()
            .firebaseId(1L)
            .nickname("pedro1")
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .build();

        when(userFacade.update(anyLong(), any(User.class))).thenReturn(user);

        mockMvc
            .perform(put("/v1/users/1")
                .header(HttpHeaders.AUTHORIZATION, token)
                .content(updateUserJson)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON)
            )
            .andExpect(status().isAccepted())
            .andExpect(content().string(Matchers.containsString("id")))
            .andExpect(content().string(Matchers.containsString("firebase_id")))
            .andExpect(content().string(Matchers.containsString("nickname")))
            .andExpect(content().string(Matchers.containsString("firstname")))
            .andExpect(content().string(Matchers.containsString("lastname")))
            .andExpect(content().string(Matchers.containsString("email")))
            .andExpect(content().string(Matchers.containsString("phone")))
            .andExpect(content().string(Matchers.containsString("document_id")))
            .andExpect(content().string(Matchers.containsString("document_type")))
            .andExpect(content().string(Matchers.containsString("document_date_expiration")))
            .andExpect(content().string(Matchers.containsString("address")))
            .andExpect(content().string(Matchers.containsString("city")))
            .andExpect(content().string(Matchers.containsString("state")))
            .andExpect(content().string(Matchers.containsString("country_id")))
            .andExpect(content().string(Matchers.containsString("language_id")))
            .andExpect(content().string(Matchers.containsString("type")))
            .andExpect(content().string(Matchers.containsString("status")))
        ;
    }

    @Test
    void test_Delete_Should_Return_DeletedUser_When_ServiceIsCalled() throws Exception {

        String token = generateJWT(DELETE_USER);

        doNothing().when(userFacade).delete(anyLong());

        mockMvc
            .perform(delete("/v1/users/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isNoContent())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
        ;
    }

    @Test
    void test_Get_Should_Return403_When_Permission_IsNotValid() throws Exception {

        String token = generateJWT("NONE");

        mockMvc
            .perform(get("/v1/users/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isForbidden())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(403))
            .andExpect(jsonPath("$.message").value("Forbidden"))
            .andExpect(jsonPath("$.error").value("Access is denied"))
        ;
    }

    @Test
    void test_Get_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(get("/v1/users")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Post_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(post("/v1/users/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    @Test
    void test_Put_Should_Return401_When_Token_IsNotValid() throws Exception {

        String token = "NONE";

        this.mockMvc
            .perform(put("/v1/users/1")
                .header(HttpHeaders.AUTHORIZATION, token)
            )
            .andExpect(status().isUnauthorized())
            .andExpect(content().string(Matchers.containsString("status_code")))
            .andExpect(content().string(Matchers.containsString("message")))
            .andExpect(content().string(Matchers.containsString("error")))
            .andExpect(content().string(Matchers.containsString("body")))
            .andExpect(jsonPath("$.status_code").value(401))
            .andExpect(jsonPath("$.message").value("Unauthorized request."))
        ;
    }

    private void executeGetRequest(String token, String path) throws Exception {
        this.mockMvc.perform(get(path)
                .header(HttpHeaders.AUTHORIZATION, token)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("utf-8")
                .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status_code").value(200))
            .andExpect(jsonPath("$.error").isEmpty());
    }
}
