package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.wallib.wallet.bc.users.admin.documents.UserDocument;
import com.wallib.wallet.bc.users.admin.enums.UserTypeEnum;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.Country;
import com.wallib.wallet.bc.users.admin.models.wt.User;
import com.wallib.wallet.bc.users.admin.repositories.es.UserDocumentRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserElasticServiceImplTest {

    @InjectMocks
    private UserElasticServiceImpl userElasticService;

    @Mock
    private UserDocumentRepository userDocumentRepository;

    @Mock
    private CountryRepository countryRepository;

    @Test
    void test_Index_Should_Return_IndexedUser_When_ServiceIsCalled() throws Exception {

        Country country = Country.builder()
            .name("Name")
            .id(1L)
            .build();

        when(countryRepository.findById(anyLong())).thenReturn(Optional.of(country));
        when(userDocumentRepository.save(any(UserDocument.class))).thenAnswer(i -> i.getArgument(0));

        assertAll(() -> userElasticService.index(getUser()));

        verify(countryRepository, times(1))
            .findById(anyLong());
        verify(userDocumentRepository, times(1)).save(any(UserDocument.class));

    }

    @Test
    void test_Index_Should_Return_ThrowUserServiceException_When_CountryIsNull() throws Exception {

        when(countryRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(UserServiceException.class, () -> userElasticService.index(getUser()));

        verify(countryRepository, times(1)).findById(anyLong());

    }

    private User getUser() {
        User user = User.builder()
            .firebaseId(1L)
            .firstname("Pedro")
            .lastname("Perez")
            .email("pedroperez@hotmail.com")
            .phone("12345678")
            .documentId("1032456789")
            .documentType(1)
            .documentDateExpiration(LocalDate.of(2020, 1, 1))
            .address("Baker St.")
            .city("Bogota")
            .state("CUN")
            .countryId(1L)
            .languageId(1L)
            .type(UserTypeEnum.USER_TYPE_USER)
            .status(1)
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }

}
