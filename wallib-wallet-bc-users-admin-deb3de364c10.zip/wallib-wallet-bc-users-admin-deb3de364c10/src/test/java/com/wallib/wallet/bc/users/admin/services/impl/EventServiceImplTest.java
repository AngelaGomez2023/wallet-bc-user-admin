package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.wallib.wallet.bc.users.admin.dto.v1.IndexEventDTO;
import com.wallib.wallet.bc.users.admin.producers.MessageProducer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EventServiceImplTest {

    @InjectMocks
    private EventServiceImpl eventService;

    @Mock
    private MessageProducer messageProducer;

    @Test
    void test_SentEventToQueue_Should_SendEvent_When_IsValid() {

        doNothing().when(messageProducer).sendToUserEvent(any(IndexEventDTO.class));

        assertAll(() -> eventService.sendEventToQueue("TEST_EVENT", "TEST_ENTITY", 1L));

        verify(messageProducer, times(1)).
            sendToUserEvent(any(IndexEventDTO.class));

    }

}
