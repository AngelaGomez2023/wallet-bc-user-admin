package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.dto.v1.requests.UpdateUserPinDTO;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.EventService;
import com.wallib.wallet.bc.users.admin.services.UserPinRedisService;
import com.wallib.wallet.bc.users.admin.services.UserPinService;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserPinFacadeImplTest {
    
    @InjectMocks
    private UserPinFacadeImpl userPinFacade;

    @Mock
    private UserPinService userPinService;

    @Mock
    private UserPinRedisService userPinRedisService;

    @Mock
    private EventService eventService;

    @Test
    @Tag("SkipEventServie")
    void test_findByUserId_Should_ReturnCachedUserPin_When_ReceivedUserIdValid_And_UserPinInRedis()
        throws JsonProcessingException, UserPinServiceException {

        when(userPinRedisService.get(anyLong())).thenReturn(getUserPin());

        assertAll(() -> userPinFacade.findByUserId(anyLong()));

        verify(userPinRedisService, times(1)).get(anyLong());
    }

    @Test
    @Tag("SkipEventServie")
    void test_findByUserId_Should_ReturnNewUserPin_When_ReceivedUserIdValid_And_UserPinNotInRedis()
        throws JsonProcessingException, UserPinServiceException {

        UserPin userPin = getUserPin();
        userPin.setPin(null);
        when(userPinService.findByUserId(anyLong())).thenReturn(userPin);
        when(userPinRedisService.get(anyLong())).thenReturn(userPin);

        assertAll(() -> userPinFacade.findByUserId(anyLong()));

        verify(userPinService, times(1)).findByUserId(anyLong());
        verify(userPinRedisService, times(1)).get(anyLong());
    }

    @Test
    void test_Create_Should_CreateUserPin_When_ReceivedUserPinValid()
        throws JsonProcessingException, UserPinServiceException {
        doNothing().when(eventService).sendEventToQueue(anyString(), anyString(), anyLong());
        when(userPinService.create(any(UserPin.class))).thenReturn(getUserPin());

        assertAll(() -> userPinFacade.create(getUserPin()));

        verify(eventService, times(1)).sendEventToQueue(anyString(), anyString(), anyLong());
        verify(userPinService, times(1)).create(any(UserPin.class));
    }

    @Test
    void test_Update_Should_UpdateUser_When_ReceivedUserValid()
        throws JsonProcessingException, UserPinServiceException {

        UserPin userPin = getUserPin();
        UpdateUserPinDTO updateUserPinDTO = getUserPinUpdateDTO();
        doNothing().when(eventService).sendEventToQueue(anyString(), anyString(), anyLong());
        when(userPinService.update(anyLong(), anyString(), any(UserPin.class))).thenReturn(getUserPin());

        assertAll(() -> userPinFacade.update(updateUserPinDTO.getUserId(), updateUserPinDTO.getCurrentPin(), userPin));

        verify(eventService, times(1)).sendEventToQueue(anyString(), anyString(), anyLong());
        verify(userPinService, times(1)).update(anyLong(), anyString(), any(UserPin.class));
    }

    @Test
    void test_Delete_Should_DeleteUserPin_When_ReceivedIdValid()
        throws JsonProcessingException, UserPinServiceException {

        doNothing().when(eventService).sendEventToQueue(anyString(), anyString(), anyLong());
        doNothing().when(userPinService).delete(anyLong());

        assertAll(() -> userPinFacade.delete(1L));
        verify(eventService, times(1)).sendEventToQueue(anyString(), anyString(), anyLong());
        verify(userPinService, times(1)).delete(anyLong());
    }

    private UpdateUserPinDTO getUserPinUpdateDTO() {
        UpdateUserPinDTO userPin = UpdateUserPinDTO.builder()
            .userId(1L)
            .pin("1234")
            .currentPin("1234")
            .build();

        return userPin;
    }

    private UserPin getUserPin() {
        UserPin userPin = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        userPin.setId(1L);
        userPin.setCreatedAt(LocalDateTime.now());
        userPin.setUpdatedAt(LocalDateTime.now());

        return userPin;
    }
}
