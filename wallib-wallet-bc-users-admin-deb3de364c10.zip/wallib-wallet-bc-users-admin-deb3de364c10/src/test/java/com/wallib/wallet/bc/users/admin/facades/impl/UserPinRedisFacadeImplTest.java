package com.wallib.wallet.bc.users.admin.facades.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.UserPinServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.UserPin;
import com.wallib.wallet.bc.users.admin.services.UserPinRedisService;
import com.wallib.wallet.bc.users.admin.services.UserPinService;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserPinRedisFacadeImplTest {

    @InjectMocks
    private UserPinRedisFacadeImpl userPinRedisFacade;

    @Mock
    private UserPinService userPinService;

    @Mock
    private UserPinRedisService userRedisService;

    @Test
    void test_IndexByUserPin_Should_IndexUserPin_When_ReceivedUserPinValid()
        throws JsonProcessingException, UserPinServiceException {
        when(userPinService.findByUserId(anyLong())).thenReturn(getUserPin());

        assertAll(() -> userPinRedisFacade.indexByUserPin(1L));

        verify(userPinService, times(1)).findByUserId(anyLong());
    }

    private UserPin getUserPin() {
        UserPin user = UserPin.builder()
            .userId(1L)
            .pin("1234")
            .build();

        user.setId(1L);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }
}