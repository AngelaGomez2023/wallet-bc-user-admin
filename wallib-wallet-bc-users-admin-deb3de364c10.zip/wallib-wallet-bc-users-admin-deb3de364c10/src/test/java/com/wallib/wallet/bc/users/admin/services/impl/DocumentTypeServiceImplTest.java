package com.wallib.wallet.bc.users.admin.services.impl;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wallib.wallet.bc.users.admin.exceptions.BusinessRulesListExceptions.DocumentTypeServiceException;
import com.wallib.wallet.bc.users.admin.models.wt.DocumentType;
import com.wallib.wallet.bc.users.admin.repositories.wt.CountryRepository;
import com.wallib.wallet.bc.users.admin.repositories.wt.DocumentTypeRepository;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentTypeServiceImplTest {

    @InjectMocks
    private DocumentTypeServiceImpl documentTypeService;

    @Mock
    private DocumentTypeRepository documentTypeRepository;

    @Mock
    private CountryRepository countryRepository;

    @Mock
    private AuditLogServiceImpl auditLogService;

    @Test
    void test_ListMethod_Should_ListDocumentTypes_When_CallService() {
        DocumentType documentType = getDocumentType();
        when(documentTypeRepository.findAll()).thenReturn(Collections.singletonList(documentType));

        assertAll(() -> documentTypeService.list());
        verify(documentTypeRepository, times(1))
            .findAll();
    }

    @Test
    void test_FindByIdMethod_Should_GetDocumentType_When_ReceiveQueryParams() {
        DocumentType documentType = getDocumentType();
        when(documentTypeRepository.findById(anyLong())).thenReturn(java.util.Optional.of(documentType));

        assertAll(() -> documentTypeService.findById(1L));
        verify(documentTypeRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_CreateMethod_Should_CreateDocumentType_When_ReceiveValidObject() throws JsonProcessingException {
        DocumentType country = getDocumentType();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(documentTypeRepository.existsByTypeAndCountryIdAndDeletedAtIsNull(anyString(), anyLong())).thenReturn(false);
        when(documentTypeRepository.save(any(DocumentType.class))).thenReturn(country);
        doNothing().when(auditLogService).createAuditLog(any(DocumentType.class));

        assertAll(() -> documentTypeService.create(country));
        verify(countryRepository, times(1)).existsById(anyLong());
        verify(documentTypeRepository, times(1)).existsByTypeAndCountryIdAndDeletedAtIsNull(anyString(), anyLong());
        verify(documentTypeRepository, times(1)).save(any(DocumentType.class));
        verify(auditLogService, times(1)).createAuditLog(any(DocumentType.class));
    }

    @Test
    void test_CreateMethod_Should_ThrowDocumentTypeServiceException_When_CountryDoesNotExist() {
        DocumentType country = getDocumentType();

        when(countryRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(DocumentTypeServiceException.class,
            () -> documentTypeService.create(country));
    }

    @Test
    void test_CreateMethod_Should_ThrowDocumentTypeServiceException_When_DocumentTypeDuplicated() {
        DocumentType country = getDocumentType();

        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(documentTypeRepository.existsByTypeAndCountryIdAndDeletedAtIsNull(anyString(), anyLong())).thenReturn(true);

        assertThrows(DocumentTypeServiceException.class,
            () -> documentTypeService.create(country));
    }

    @Test
    void test_UpdateMethod_Should_UpdateDocumentType_When_ReceiveValidObject() throws JsonProcessingException {
        DocumentType country = getDocumentType();

        when(documentTypeRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(documentTypeRepository.existsByTypeAndCountryIdAndIdNotAndDeletedAtIsNull(
            anyString(), 
            anyLong(), 
            anyLong())
        ).thenReturn(false);
        when(documentTypeRepository.saveAndFlush(any(DocumentType.class))).thenReturn(country);

        doNothing().when(auditLogService).updateAuditLog(any(DocumentType.class), any(DocumentType.class));

        assertAll(() -> documentTypeService.update(1L, country));
        verify(documentTypeRepository, times(1)).findById(anyLong());
        verify(countryRepository, times(1)).existsById(anyLong());
        verify(documentTypeRepository, times(1)).existsByTypeAndCountryIdAndIdNotAndDeletedAtIsNull(
            anyString(),
            anyLong(),
            anyLong()
        );
        verify(documentTypeRepository, times(1)).saveAndFlush(any(DocumentType.class));
        verify(auditLogService, times(1))
            .updateAuditLog(any(DocumentType.class), any(DocumentType.class));

    }

    @Test
    void test_UpdateMethod_Should_ThrowEntityNotFoundException_When_DocumentTypeDoesNotExist() {
        DocumentType country = getDocumentType();

        when(documentTypeRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class,
            () -> documentTypeService.update(1L, country));
    }

    @Test
    void test_UpdateMethod_Should_ThrowCountryServiceException_When_DocumentTypeDuplicated() {
        DocumentType country = getDocumentType();

        when(documentTypeRepository.findById(anyLong())).thenReturn(java.util.Optional.of(country));
        when(countryRepository.existsById(anyLong())).thenReturn(true);
        when(documentTypeRepository.existsByTypeAndCountryIdAndIdNotAndDeletedAtIsNull(
            anyString(), 
            anyLong(),
            anyLong()
        ))
            .thenReturn(true);

        assertThrows(DocumentTypeServiceException.class,
            () -> documentTypeService.update(1L, country));
    }

    @Test
    void test_DeleteMethod_Should_DeleteDocumentType_When_ReceiveValidId() {
        DocumentType documentType = getDocumentType();
        when(documentTypeRepository.findById(anyLong())).thenReturn(java.util.Optional.of(documentType));
        doNothing().when(documentTypeRepository).delete(any(DocumentType.class));

        assertAll(() -> documentTypeService.delete(1L));
        verify(documentTypeRepository, times(1))
            .findById(anyLong());
    }

    @Test
    void test_DeleteMethod_Should_ThrowEntityNotFoundException_When_CountryDoesNotExist() {

        when(documentTypeRepository.findById(anyLong())).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class,
            () -> documentTypeService.delete(1L));
    }

    private DocumentType getDocumentType() {
        DocumentType documentType = DocumentType.builder()
            .type("CC")
            .countryId(1L)
            .status(1)
            .build();

        documentType.setId(1L);
        documentType.setCreatedAt(LocalDateTime.now());
        documentType.setUpdatedAt(LocalDateTime.now());

        return documentType;
    }
}
