import datetime
from dataclasses import dataclass


@dataclass
class AuditLog(object):
    id: int
    action: str
    userId: int
    modelId: int
    modelName: str
    modification: str
    createdAt: datetime.datetime
