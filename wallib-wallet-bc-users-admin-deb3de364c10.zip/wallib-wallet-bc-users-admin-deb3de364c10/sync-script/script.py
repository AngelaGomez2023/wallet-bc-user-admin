import json
import logging
import os
import pathlib
import re
import time

import mysql.connector
import schedule
from dotenv import load_dotenv
from elasticsearch import Elasticsearch

from audit_log import AuditLog

load_dotenv()

MYSQL_HOST = os.getenv('MYSQL_HOST')
MYSQL_PORT = os.getenv('MYSQL_PORT')
MYSQL_USER = os.getenv('MYSQL_USER')
MYSQL_PSSWD = os.getenv('MYSQL_PSSWD')
MYSQL_DB = os.getenv('MYSQL_DB')
MYSQL_MODEL = os.getenv('MYSQL_MODEL')

ELASTIC_URL = os.getenv('ELASTIC_URL')
ELASTIC_USERNAME = os.getenv('ELASTIC_USERNAME')
ELASTIC_PASSWORD = os.getenv('ELASTIC_PASSWORD')

LOG_FILE = f"{pathlib.Path(__file__).parent.resolve()}/{os.getenv('LOG_FILE')}"

BULK_SIZE = os.getenv('BULK_SIZE')

mydb = mysql.connector.connect(
    host=f"{MYSQL_HOST}",
    user=MYSQL_USER,
    password=MYSQL_PSSWD,
    database=MYSQL_DB
)

es = Elasticsearch([ELASTIC_URL],
                   http_auth=(ELASTIC_USERNAME, ELASTIC_PASSWORD),
                   scheme="https",
                   port=443)


def setup_logger():
    exists = True if os.path.isfile(f'{LOG_FILE}') else False
    logging.getLogger('elasticsearch').setLevel(logging.CRITICAL)
    logging.basicConfig(filename=LOG_FILE,
                        filemode="a+",
                        format='%(asctime)s %(message)s',
                        level=logging.INFO)

    if not exists:
        logging.info("BEGIN SYNC FILE")
        logging.info("Last index to process: 0")


modif_types = {
    "CREATED": 1,
    "UPDATED": 2,
    "DELETED": 3
}


def index_in_elastic(change, body):
    if change == 1 or change == 2:
        try:
            es.update(index="users", id=body.get('id'),
                      body={
                          'doc': body,
                          'doc_as_upsert': True,
                      })
        except Exception as e:
            logging.error(f"Failed to upsert user with id {body.get('id')}, with this error {e}")
    elif change == 3:
        try:
            es.delete(index="users", id=body.get('id'))
        except:
            logging.error(f"Failed to delete user with id {body.get('id')}")
    else:
        return


def to_camel_case(snake_str):
    components = snake_str.split('_')
    return components[0] + ''.join(x.title() for x in components[1:])


def alter_keys(dictionary, func):
    empty = {}
    for k, v in dictionary.items():
        if isinstance(v, dict):
            empty[func(k)] = alter_keys(v, func)
        if isinstance(k, str):
            empty[func(k)] = v
    return empty


def parse_auditlog_content_to_user(audit_log):
    raw_json = ""
    if modif_types.get(audit_log.action) == 1:
        raw_json = audit_log.modification[6:]
    elif modif_types.get(audit_log.action, None) is None:
        return None
    else:
        raw_json = audit_log.modification

    user = json.loads(raw_json)
    user.pop('created_at', None)
    user.pop('updated_at', None)
    user.pop('deleted_at', None)

    user = alter_keys(user, to_camel_case)

    return user


def add_country_to_user(user):
    if 'countryId' in user:
        country_id = user.get('countryId')
        country = fetch_country_from_db(country_id)
        user['country'] = {'id': country[0], 'name': country[1]}
        user.pop('countryId')
        return user

    return user


def fetch_country_from_db(country_id):
    cursor = mydb.cursor()
    cursor.execute(f"SELECT id, name from countries WHERE id = {country_id}")
    return cursor.fetchone()


def fetch_users_from_db(index, bulk_size):
    cursor = mydb.cursor()
    cursor.execute(f"""
        SELECT * FROM audit_logs where id > {index} and model_name = '{MYSQL_MODEL}' ORDER BY id ASC LIMIT {bulk_size}""")
    logs = cursor.fetchall()
    last_index = index

    try:
        for log in logs:
            change = AuditLog(*log)
            user = parse_auditlog_content_to_user(change)

            if user is None:
                continue

            user = add_country_to_user(user)
            index_in_elastic(modif_types.get(change.action), user)
            last_index = change.id

        logging.info(f"Finished synchronization with batch size {bulk_size}")
    except:
        logging.info("There was an error when syncing users")

    logging.info(f"Starting from index: {index}")
    logging.info(f"Last index to process: {last_index}")

    return last_index


def get_last_index():
    with open(LOG_FILE, "rb") as file:
        file.seek(-2, os.SEEK_END)
        while file.read(1) != b'\n':
            file.seek(-2, os.SEEK_CUR)

        last_line = file.readline().decode()

        index = re.findall('\d+', last_line)[-1]
        return index


def sync_mysqldb_to_es():
    print("Sync running...")
    index = get_last_index()
    fetch_users_from_db(index, BULK_SIZE)

    return


setup_logger()
schedule.every(5).seconds.do(sync_mysqldb_to_es)

while True:
    schedule.run_pending()
    time.sleep(1)
